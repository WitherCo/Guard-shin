#!/usr/bin/env node

/**
 * Start Guard-shin Discord Bot (ESM Version)
 * 
 * This script initializes and starts the Guard-shin Discord bot using ESM modules.
 */

import { createDiscordClient } from './bot/esmAdapter.js';

// Set default prefix
process.env.PREFIX = process.env.PREFIX || ';';

console.log('⚡ Starting Guard-shin Discord Bot (ESM Version)...');

// Create the Discord client
const client = createDiscordClient();

// Start the bot with the appropriate token
try {
  // Try Guard-shin token first, fall back to original token
  const guardShinToken = process.env.GUARD_SHIN_BOT_TOKEN;
  const originalToken = process.env.DISCORD_BOT_TOKEN;
  
  if (!guardShinToken && !originalToken) {
    console.error('❌ No bot token found in environment variables. Bot cannot start.');
    console.error('   Please set GUARD_SHIN_BOT_TOKEN or DISCORD_BOT_TOKEN in your environment.');
    process.exit(1);
  }
  
  if (guardShinToken) {
    console.log('🔑 Using GUARD_SHIN_BOT_TOKEN...');
    await client.login(guardShinToken);
  } else {
    console.log('🔑 Using DISCORD_BOT_TOKEN...');
    await client.login(originalToken);
  }
  
  console.log('✅ Bot startup successful!');
  
  // Keep the process running
  console.log('🔄 Bot is now running. Press Ctrl+C to stop.');
} catch (error) {
  console.error('❌ Error starting bot:', error);
  process.exit(1);
}