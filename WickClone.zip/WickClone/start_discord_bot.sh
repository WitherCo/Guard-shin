#!/bin/bash

echo "Starting Guard-shin Discord Bot..."
python run_bot.py