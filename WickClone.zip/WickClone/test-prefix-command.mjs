#!/usr/bin/env node

/**
 * Test Script for Discord Bot Prefix Commands (ESM version)
 * 
 * This script tests the prefix command handler using the ESM adapter.
 * To test:
 * 1. Run the script with: node test-prefix-command.mjs
 * 2. The script will simulate a Discord message and process it through the prefix command handler
 */

import { createDiscordClient } from './bot/esmAdapter.js';
import { prefixCommands, handlePrefixCommand } from './bot/commands/prefixCommandsESM.js';

// Set default environment variables for testing
process.env.PREFIX = process.env.PREFIX || ';';

// Mock Discord message
const createMockMessage = (content, guildId = '1233495879223345172') => {
  return {
    content,
    author: {
      id: '1259367203346841725', // Developer user ID
      bot: false,
      tag: 'TestUser#0001'
    },
    guild: guildId ? { 
      id: guildId,
      name: 'Test Guild',
      ownerId: '1259367203346841725', // Same as author for testing
      premiumTier: 0,
      createdTimestamp: Date.now() - 30 * 24 * 60 * 60 * 1000, // 30 days ago
      iconURL: () => null,
      premiumSubscriptionCount: 0,
      members: {
        fetch: async () => {},
        cache: {
          size: 1
        }
      },
      memberCount: 1
    } : null,
    reply: (content) => {
      console.log('\n✅ Bot replied:', typeof content === 'string' ? content : JSON.stringify(content, null, 2));
      return {
        createdTimestamp: Date.now(),
        edit: (newContent) => {
          console.log('\n✏️ Bot edited reply:', newContent);
        }
      };
    }
  };
};

// Available commands for testing
const availableCommands = Array.from(prefixCommands.keys());

// Main testing function
async function testPrefixCommands() {
  console.log('🤖 Discord Bot Prefix Command Tester (ESM Version)');
  console.log('==================================');
  console.log(`Available commands: ${availableCommands.join(', ')}`);
  console.log('==================================\n');
  
  // Set up test prefix
  const prefix = ';';
  
  // Test a series of commands
  const testCommands = [
    ';test',
    ';ping',
    ';help',
    ';serverinfo',
    ';premium',
    ';nonexistentcommand'
  ];
  
  // Process each command
  for (const cmdText of testCommands) {
    console.log(`\n🔹 Testing command: ${cmdText}`);
    console.log('--------------------------');
    
    const mockMessage = createMockMessage(cmdText);
    
    try {
      await handlePrefixCommand(mockMessage, prefix);
      console.log('✅ Command processed.');
    } catch (error) {
      console.error('❌ Error processing command:', error);
    }
    
    console.log('--------------------------');
  }
  
  console.log('\n✨ Testing complete!');
}

// Run the tests
testPrefixCommands().catch(error => {
  console.error('❌ Test failed with error:', error);
});