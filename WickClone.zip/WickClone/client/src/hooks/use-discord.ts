import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { useAuth } from './use-auth';

interface DiscordServer {
  id: string;
  name: string;
  icon: string;
  owner: boolean;
  permissions: number;
  features: string[];
}

interface PremiumStatus {
  isPremium: boolean;
  premiumTier: number;
  expiresAt?: string;
}

/**
 * Hook to fetch user's Discord servers
 */
export function useDiscordServers() {
  const { isAuthenticated } = useAuth();

  return useQuery<DiscordServer[]>({
    queryKey: ['/api/discord/guilds'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: isAuthenticated,
    retry: 1, // Only retry once
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
}

/**
 * Hook to check if a server has premium status
 * @param serverId Discord server ID to check
 */
export function usePremiumStatus(serverId?: string) {
  // If no serverId is provided, default to checking the user's premium status
  const endpoint = serverId ? `/api/premium/server/${serverId}` : '/api/premium/user';
  
  const { data, isLoading, error } = useQuery<PremiumStatus>({
    queryKey: [endpoint],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    retry: 1,
    refetchOnWindowFocus: false,
    // If checking support server specifically, we'll allow premium status
    // initialData is not set, so it will fetch from the API instead
  });

  return {
    isPremium: data?.isPremium || false,
    premiumTier: data?.premiumTier || 0,
    expiresAt: data?.expiresAt,
    isLoading,
    error,
  };
}

/**
 * Get the role of a user in a Discord server
 * @param serverId The Discord server ID
 */
export function useDiscordServerRole(serverId: string) {
  const { isAuthenticated } = useAuth();

  return useQuery<{ role: string }>({
    queryKey: ['/api/discord/guilds', serverId, 'role'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: isAuthenticated && !!serverId,
    retry: 1,
    refetchOnWindowFocus: false,
    // Mock data for now
    initialData: { role: 'ADMINISTRATOR' },
  });
}