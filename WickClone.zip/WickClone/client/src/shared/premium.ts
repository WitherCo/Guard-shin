// Premium utility functions for checking premium status

// Interface for server with premium-related properties
interface ServerWithPremium {
  id: string;
  premium?: boolean | null;
  premiumTier?: string | null;
  premiumExpiresAt?: Date | string | null;
}

/**
 * Check if a server has premium status
 * @param server Server object with premium properties
 * @returns boolean indicating whether the server has premium
 */
export function hasServerPremium(server: ServerWithPremium): boolean {
  if (!server) return false;
  
  // Check if premium flag is directly set
  if (server.premium === true) return true;
  
  // Check if premium tier is set
  if (server.premiumTier && server.premiumTier !== 'none') return true;
  
  // Check if premium expiration date exists and is in the future
  if (server.premiumExpiresAt) {
    const expiryDate = typeof server.premiumExpiresAt === 'string' 
      ? new Date(server.premiumExpiresAt)
      : server.premiumExpiresAt;
      
    if (expiryDate > new Date()) return true;
  }
  
  return false;
}

/**
 * Get the premium tier of a server
 * @param server Server object with premium properties
 * @returns Premium tier (basic, standard, premium) or null if not premium
 */
export function getServerPremiumTier(server: ServerWithPremium): string | null {
  if (!hasServerPremium(server)) return null;
  
  return server.premiumTier || 'basic';
}

/**
 * Check if a premium feature is available for the server
 * @param server Server object with premium properties
 * @param featureType Type of feature to check (basic, standard, premium)
 * @returns boolean indicating whether the feature is available
 */
export function isPremiumFeatureAvailable(
  server: ServerWithPremium, 
  featureType: 'basic' | 'standard' | 'premium' = 'basic'
): boolean {
  if (!hasServerPremium(server)) return false;
  
  const tier = server.premiumTier || 'basic';
  
  switch (featureType) {
    case 'basic':
      return ['basic', 'standard', 'premium'].includes(tier);
    case 'standard':
      return ['standard', 'premium'].includes(tier);
    case 'premium':
      return tier === 'premium';
    default:
      return false;
  }
}

/**
 * Format time remaining for premium subscription
 * @param expiresAt Premium expiration date
 * @returns Formatted string of time remaining
 */
export function formatPremiumTimeRemaining(expiresAt: Date | string | null): string {
  if (!expiresAt) return 'Not premium';
  
  const expiry = typeof expiresAt === 'string' ? new Date(expiresAt) : expiresAt;
  const now = new Date();
  
  if (expiry <= now) return 'Expired';
  
  const diffMs = expiry.getTime() - now.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  if (diffDays > 30) {
    const diffMonths = Math.floor(diffDays / 30);
    return `${diffMonths} month${diffMonths !== 1 ? 's' : ''} remaining`;
  }
  
  return `${diffDays} day${diffDays !== 1 ? 's' : ''} remaining`;
}