import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useDiscordServers, usePremiumStatus } from '@/hooks/use-discord';
import { getQueryFn } from '@/lib/queryClient';
import { Server as ServerBase, AutoModSetting, RaidProtectionSetting, Infraction, VerificationSetting } from '@shared/schema';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import StatCard from '@/components/dashboard/StatCard';
import InfractionTable from '@/components/dashboard/InfractionTable';
import FeatureToggle from '@/components/dashboard/FeatureToggle';
import { DataLoader } from '@/components/data-loader';
import { LoadingPage } from '@/components/loading-page';
import { SecurityLoader } from '@/components/ui/security-loader';
import BotCommandDebugger from '@/components/dashboard/BotCommandDebugger';

// Import Discord components
import DiscordServersList from '@/components/dashboard/DiscordServersList';

// Extended Server interface with additional properties
interface Server extends ServerBase {
  iconUrl?: string;
  premium: boolean | null;
}

// Interface for FeatureCard props
interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  isPremium?: boolean;
  enabled?: boolean;
  comingSoon?: boolean;
}
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { 
  Users, 
  ShieldAlert, 
  Workflow, 
  UserCheck,
  MessageSquareOff, 
  AlertCircle,
  Link as LinkIcon,
  Copy,
  ImageOff,
  Shield,
  AlertTriangle,
  Ban,
  Hash,
  BarChart,
  Zap,
  Clock,
  Settings,
  MoveRight,
  UserPlus,
  Bot,
  Check,
  X,
  Award,
  ExternalLink,
  BookOpen,
  TextQuote,
  Bell,
  ThumbsUp
} from 'lucide-react';

// Helper components
const PremiumBadge = () => (
  <Badge variant="outline" className="ml-2 bg-gradient-to-r from-yellow-400 to-yellow-600 text-white border-0">
    <Award className="h-3 w-3 mr-1" />
    Premium
  </Badge>
);

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, icon, isPremium = false, enabled = false, comingSoon = false }) => (
  <div className={`p-4 rounded-lg border ${enabled ? 'border-primary bg-primary bg-opacity-5' : 'border-gray-700'}`}>
    <div className="flex justify-between items-start">
      <div className="flex items-center">
        <div className={`p-2 rounded-lg ${enabled ? 'bg-primary bg-opacity-20' : 'bg-gray-800'}`}>
          {icon}
        </div>
        <div className="ml-3">
          <h3 className="font-medium text-white flex items-center">
            {title}
            {isPremium && <PremiumBadge />}
            {comingSoon && <Badge className="ml-2 bg-gray-700 text-white">Soon</Badge>}
          </h3>
          <p className="text-sm text-gray-400">{description}</p>
        </div>
      </div>
      <Switch checked={enabled} disabled={comingSoon} />
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const { toast } = useToast();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const [activeTab, setActiveTab] = useState<string>('overview');
  
  // Use Discord hooks
  const { data: discordGuilds, isLoading: loadingDiscordGuilds } = useDiscordServers();
  const { isPremium, premiumTier, isLoading: loadingPremium } = usePremiumStatus();
  
  // Placeholder for other Discord-related functions until we implement them
  const lockdownStatus = { lockdownActive: false };
  const toggleLockdown = {
    mutate: (params: any, callbacks: any) => {
      if (callbacks.onSuccess) callbacks.onSuccess({});
    }
  };
  const sendMessage = {
    mutate: (params: any, callbacks: any) => {
      if (callbacks.onSuccess) callbacks.onSuccess({});
    }
  };
  
  // Fetch servers
  const { data: servers, isLoading: loadingServers } = useQuery<Server[]>({ 
    queryKey: ['/api/servers'],
    queryFn: getQueryFn({ on401: 'returnNull' })
  });
  
  // Fetch server details
  const { data: server } = useQuery<Server>({ 
    queryKey: ['/api/servers', selectedServerId], 
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!selectedServerId,
  });
  
  // Fetch auto-mod settings
  const { data: autoModSettingsData } = useQuery<AutoModSetting>({ 
    queryKey: ['/api/servers', selectedServerId, 'automod'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!selectedServerId,
  });
  
  // Create extended auto-mod settings with enabled property
  const autoModSettings = autoModSettingsData ? {
    ...autoModSettingsData,
    enabled: autoModSettingsData.profanityFilterEnabled || autoModSettingsData.spamDetectionEnabled || false
  } : undefined;
  
  // Fetch raid protection settings
  const { data: raidSettings } = useQuery<RaidProtectionSetting>({ 
    queryKey: ['/api/servers', selectedServerId, 'raid-protection'], 
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!selectedServerId,
  });
  
  // Fetch verification settings
  const { data: verificationSettings } = useQuery<VerificationSetting>({ 
    queryKey: ['/api/servers', selectedServerId, 'verification'], 
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!selectedServerId,
  });
  
  // Fetch infractions
  const { data: infractions, isLoading: loadingInfractions } = useQuery<Infraction[]>({ 
    queryKey: ['/api/servers', selectedServerId, 'infractions'], 
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!selectedServerId,
  });
  
  const handleServerChange = (value: string) => {
    setSelectedServerId(value);
  };
  
  const handleViewInfractionDetails = (id: number) => {
    toast({
      title: "Viewing infraction details",
      description: `Viewing details for infraction #${id}`,
    });
  };
  
  const handleDeleteInfraction = (id: number) => {
    toast({
      title: "Delete infraction",
      description: `Infraction #${id} would be deleted`,
      variant: "destructive",
    });
  };
  
  const handleDisableLockdown = () => {
    // Use the Discord API to disable lockdown
    toggleLockdown.mutate(
      { guildId: selectedServerId, disable: true },
      {
        onSuccess: (data: any) => {
          toast({
            title: "Lockdown disabled",
            description: "Server lockdown has been disabled",
          });
        },
        onError: (error: any) => {
          toast({
            title: "Error disabling lockdown",
            description: error instanceof Error ? error.message : "An unknown error occurred",
            variant: "destructive",
          });
        }
      }
    );
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleEnableFeature = (feature: string) => {
    toast({
      title: `${feature} Enabled`,
      description: `${feature} has been enabled for this server`,
    });
  };
  
  return (
    <DashboardLayout title="Dashboard">
      {/* Server selection */}
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 min-w-0">
            <div className="relative rounded-md w-full sm:w-72">
              <Select 
                value={selectedServerId} 
                onValueChange={handleServerChange}
              >
                <SelectTrigger className="pl-10 w-full bg-discord-dark border-discord-darker">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Users className="h-5 w-5 text-gray-400" />
                  </div>
                  <SelectValue placeholder="Select a server" />
                </SelectTrigger>
                <SelectContent className="bg-discord-dark border-discord-darker">
                  {!loadingServers && servers?.map(server => (
                    <SelectItem key={server.id} value={server.id}>{server.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-2">
            <Button variant="outline" className="border-discord-light text-white hover:bg-discord-dark">
              <Bot className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button 
              variant="outline" 
              className="border-yellow-600/50 text-yellow-500 hover:bg-yellow-900/20"
              onClick={() => window.location.href = `/premium/${selectedServerId}`}
            >
              <Award className="mr-2 h-4 w-4" />
              Premium
            </Button>
            <Button 
              className="bg-primary hover:bg-opacity-90 text-white"
              onClick={() => window.open('https://discord.com/oauth2/authorize?client_id=1361873604882731008', '_blank')}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Add to Server
            </Button>
          </div>
        </div>
      </div>

      {/* Server info banner */}
      <div className="mb-6 bg-black/50 backdrop-blur-sm rounded-lg border border-gray-800 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center">
          <div className="w-14 h-14 rounded-md bg-gray-800 border border-gray-700 flex items-center justify-center overflow-hidden shadow-lg">
            {server?.iconUrl ? (
              <img src={server.iconUrl} alt={server?.name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xl font-bold text-white">{server?.name?.charAt(0) || 'G'}</span>
            )}
          </div>
          <div className="ml-4">
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center">
              {server?.name || 'Loading...'}
              {server?.premium && (
                <Badge variant="outline" className="ml-2 bg-gradient-to-r from-yellow-400 to-yellow-600 border-0 text-white py-0.5">
                  <Award className="h-3 w-3 mr-1" />
                  PREMIUM
                </Badge>
              )}
            </h1>
            <div className="flex items-center mt-1 text-sm text-gray-400">
              <UserCheck className="h-4 w-4 mr-1.5" />
              <span>{server?.memberCount || 0} members</span>
              <span className="mx-2 text-gray-600">•</span>
              <Shield className="h-4 w-4 mr-1.5 text-primary" />
              <span className="text-primary">Protected</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3 ml-auto">
          <Button variant="outline" size="sm" className="border-gray-800 bg-gray-900/50 text-gray-300 hover:bg-gray-800 hover:text-white">
            <Settings className="h-4 w-4 mr-1.5" />
            Settings
          </Button>
          <Button variant="outline" size="sm" className="border-gray-800 bg-gray-900/50 text-gray-300 hover:bg-gray-800 hover:text-white">
            <ExternalLink className="h-4 w-4 mr-1.5" />
            Open in Discord
          </Button>
        </div>
      </div>
      
      {/* Main tabs */}
      <Tabs defaultValue="overview" value={activeTab} onValueChange={handleTabChange} className="mb-6">
        <div className="border-b border-gray-800 mb-1">
          <TabsList className="bg-transparent h-auto">
            <TabsTrigger 
              value="overview" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent rounded-none px-4 py-3"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger 
              value="moderation" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent rounded-none px-4 py-3"
            >
              Moderation
            </TabsTrigger>
            <TabsTrigger 
              value="automod" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent rounded-none px-4 py-3"
            >
              AutoMod
            </TabsTrigger>
            <TabsTrigger 
              value="verification" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent rounded-none px-4 py-3"
            >
              Verification
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent rounded-none px-4 py-3"
            >
              Settings
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Overview Tab */}
        <TabsContent value="overview">
          {/* Stats cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard 
              title="Members" 
              value={server?.memberCount || 0}
              icon={<Users className="h-5 w-5 text-blue-500" />}
              iconBgColor="bg-blue-500"
              iconColor="text-blue-500"
              changePercentage={12}
              subtitle="Active users"
            />
            
            <StatCard 
              title="Infractions" 
              value={infractions?.length || 0}
              icon={<ShieldAlert className="h-5 w-5 text-red-500" />}
              iconBgColor="bg-red-500"
              iconColor="text-red-500"
              changePercentage={5}
              subtitle="Past 30 days"
            />
            
            <StatCard 
              title="Auto-Mod Actions" 
              value={autoModSettings?.enabled ? 82 : 0}
              icon={<Workflow className="h-5 w-5 text-yellow-500" />}
              iconBgColor="bg-yellow-500"
              iconColor="text-yellow-500"
              changePercentage={autoModSettings?.enabled ? -8 : 0}
              subtitle={autoModSettings?.enabled ? "Past 30 days" : "Feature disabled"}
            />
            
            <StatCard 
              title="Verifications" 
              value={verificationSettings?.enabled ? 126 : 0}
              icon={<UserCheck className="h-5 w-5 text-green-500" />}
              iconBgColor="bg-green-500"
              iconColor="text-green-500"
              changePercentage={verificationSettings?.enabled ? 24 : 0}
              subtitle={verificationSettings?.enabled ? "Past 30 days" : "Feature disabled"}
            />
          </div>
          
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Active modules section */}
            <div className="xl:col-span-2 bg-black/50 backdrop-blur-sm rounded-lg border border-gray-800 shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold text-white">Active Modules</h2>
                <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10 text-xs">
                  <Settings className="h-3.5 w-3.5 mr-1" />
                  Configure All
                </Button>
              </div>
              
              <div className="space-y-2">
                <FeatureToggle
                  icon={<Shield className="h-5 w-5" />}
                  title="Moderation"
                  description="Comprehensive mod commands to manage your server"
                  enabled={true}
                  onToggle={() => {}}
                />
                
                <FeatureToggle
                  icon={<MessageSquareOff className="h-5 w-5" />}
                  title="Auto-Moderation"
                  description="Automatically filter profanity, spam, and other unwanted content"
                  enabled={autoModSettings?.profanityFilterEnabled || false}
                  onToggle={() => handleEnableFeature('Auto-Moderation')}
                />
                
                <FeatureToggle
                  icon={<AlertTriangle className="h-5 w-5" />}
                  title="Raid Protection"
                  description="Intelligent detection and prevention of server raids"
                  enabled={raidSettings?.enabled || false}
                  onToggle={() => handleEnableFeature('Raid Protection')}
                />
                
                <FeatureToggle
                  icon={<UserCheck className="h-5 w-5" />}
                  title="Verification"
                  description="Ensure new members are real humans before giving them access"
                  enabled={verificationSettings?.enabled || false}
                  onToggle={() => handleEnableFeature('Verification')}
                />
                
                <FeatureToggle
                  icon={<Ban className="h-5 w-5" />}
                  title="Anti-Alt"
                  description="Detect and take action on alternate accounts to prevent ban evasions"
                  enabled={false}
                  onToggle={() => {}}
                  isPremium
                />
                
                <FeatureToggle
                  icon={<Hash className="h-5 w-5" />}
                  title="Custom Commands"
                  description="Create custom commands for your server members"
                  enabled={false}
                  onToggle={() => {}}
                  isPremium
                />
              </div>
            </div>
            
            {/* Server health section */}
            <div className="bg-black/50 backdrop-blur-sm rounded-lg border border-gray-800 shadow-lg p-6">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-lg font-bold text-white">Server Health</h2>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white h-7 w-7 p-0">
                        <BookOpen className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent className="bg-gray-800 border-gray-700">
                      <p className="text-sm">Server health measures how well your server is protected</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-white">Protection Score</span>
                    <span className="text-sm font-semibold text-primary">72/100</span>
                  </div>
                  <Progress value={72} className="h-2 bg-gray-800" />
                  <p className="text-xs text-gray-400 mt-1.5">Enable more security features to increase your score</p>
                </div>
                
                {raidSettings?.lockdownActive && (
                  <div className="px-4 py-4 bg-red-500/10 border border-red-500/20 rounded-md mb-4">
                    <div className="flex items-start">
                      <div className="h-8 w-8 rounded-md bg-red-500/20 flex items-center justify-center flex-shrink-0">
                        <AlertCircle className="h-5 w-5 text-red-500" />
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-semibold text-white">Anti-Raid Mode: <span className="text-red-500">Active</span></h3>
                        <p className="text-xs text-gray-400 mt-1">Raid detected 2 hours ago. New joins temporarily restricted.</p>
                        <Button 
                          size="sm" 
                          className="mt-3 px-3 bg-red-500 hover:bg-red-600 text-white text-xs font-medium rounded"
                          onClick={handleDisableLockdown}
                        >
                          Disable Lockdown
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-white flex items-center">
                    <Zap className="h-4 w-4 mr-1.5 text-yellow-500" />
                    Recommended Actions
                  </h3>
                  
                  <div className="flex items-start space-x-3 p-3 rounded-md bg-gray-800/50 border border-gray-700 hover:bg-gray-800/80 transition-colors">
                    <div className="p-2 rounded-md bg-yellow-500/20 text-yellow-500">
                      <AlertTriangle className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">Enable Raid Protection</p>
                      <p className="text-xs text-gray-400 mt-0.5">Protect against coordinated attacks</p>
                    </div>
                    <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border-0 text-xs h-8">
                      Enable
                    </Button>
                  </div>
                  
                  <div className="flex items-start space-x-3 p-3 rounded-md bg-gray-800/50 border border-gray-700 hover:bg-gray-800/80 transition-colors">
                    <div className="p-2 rounded-md bg-yellow-500/20 text-yellow-500">
                      <AlertTriangle className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">Configure Anti-Phishing</p>
                      <p className="text-xs text-gray-400 mt-0.5">Block Discord nitro scams automatically</p>
                    </div>
                    <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border-0 text-xs h-8">
                      Configure
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Recent infractions */}
          <div className="mt-6 bg-black/50 backdrop-blur-sm rounded-lg border border-gray-800 shadow-lg p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-white flex items-center">
                <ShieldAlert className="h-5 w-5 mr-2 text-red-500" />
                Recent Infractions
              </h2>
              <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10 text-xs">
                View All
              </Button>
            </div>
            
            {loadingInfractions ? (
              <div className="flex items-center justify-center p-8">
                <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-solid border-primary border-r-transparent"></div>
                <span className="ml-3 text-sm text-gray-400">Loading infractions...</span>
              </div>
            ) : (
              <InfractionTable 
                infractions={infractions || []}
                onViewDetails={handleViewInfractionDetails}
                onDelete={handleDeleteInfraction}
              />
            )}
          </div>
        </TabsContent>

        {/* Moderation Tab */}
        <TabsContent value="moderation">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card className="bg-discord-dark border-discord-darker">
                <CardHeader>
                  <CardTitle className="text-white">Moderation Actions</CardTitle>
                  <CardDescription>Manage users and perform moderation actions</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button className="bg-discord-light hover:bg-discord-light/80 text-white">
                      <Ban className="mr-2 h-4 w-4" />
                      Ban User
                    </Button>
                    <Button className="bg-discord-light hover:bg-discord-light/80 text-white">
                      <Clock className="mr-2 h-4 w-4" />
                      Timeout User
                    </Button>
                    <Button className="bg-discord-light hover:bg-discord-light/80 text-white">
                      <Users className="mr-2 h-4 w-4" />
                      Manage Roles
                    </Button>
                    <Button className="bg-discord-light hover:bg-discord-light/80 text-white">
                      <Shield className="mr-2 h-4 w-4" />
                      View Infractions
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-discord-dark border-discord-darker mt-6">
                <CardHeader>
                  <CardTitle className="text-white">Recent Activity</CardTitle>
                  <CardDescription>Latest moderation events in your server</CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Activity list */}
                  <div className="space-y-3">
                    <div className="border-l-4 border-green-500 pl-3 py-1">
                      <p className="text-sm text-white">User <span className="font-semibold">member#1234</span> was warned</p>
                      <p className="text-xs text-gray-400">Reason: Spamming in #general • 2 hours ago</p>
                    </div>
                    <div className="border-l-4 border-yellow-500 pl-3 py-1">
                      <p className="text-sm text-white"><span className="font-semibold">Automod</span> filtered message in #general</p>
                      <p className="text-xs text-gray-400">Reason: Profanity detected • 3 hours ago</p>
                    </div>
                    <div className="border-l-4 border-red-500 pl-3 py-1">
                      <p className="text-sm text-white">User <span className="font-semibold">troublemaker#5678</span> was banned</p>
                      <p className="text-xs text-gray-400">Reason: Posting NSFW content • 5 hours ago</p>
                    </div>
                    <div className="border-l-4 border-blue-500 pl-3 py-1">
                      <p className="text-sm text-white">User <span className="font-semibold">newmember#9012</span> verified</p>
                      <p className="text-xs text-gray-400">Completed verification challenge • 6 hours ago</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="border-t border-discord-darker pt-4">
                  <Button variant="outline" className="text-primary border-primary hover:bg-primary hover:bg-opacity-10 w-full">
                    View All Activity
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div>
              <Card className="bg-discord-dark border-discord-darker">
                <CardHeader>
                  <CardTitle className="text-white">Auto-Moderation</CardTitle>
                  <CardDescription>Configure automated moderation features</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <MessageSquareOff className="h-5 w-5 text-primary" />
                      <span className="text-sm text-white">Profanity Filter</span>
                    </div>
                    <Switch checked={autoModSettings?.profanityFilterEnabled || false} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <LinkIcon className="h-5 w-5 text-primary" />
                      <span className="text-sm text-white">Link Filter</span>
                    </div>
                    <Switch checked={autoModSettings?.linkFilterEnabled || false} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Copy className="h-5 w-5 text-primary" />
                      <span className="text-sm text-white">Spam Detection</span>
                    </div>
                    <Switch checked={autoModSettings?.spamDetectionEnabled || false} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Ban className="h-5 w-5 text-primary" />
                      <span className="text-sm text-white">Scam Detection</span>
                    </div>
                    <Switch checked={true} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TextQuote className="h-5 w-5 text-primary" />
                      <span className="text-sm text-white">Caps Filter</span>
                    </div>
                    <Switch checked={true} />
                  </div>
                </CardContent>
                <CardFooter className="border-t border-discord-darker pt-4">
                  <Button className="bg-primary hover:bg-primary/90 text-white w-full">
                    Configure AutoMod
                  </Button>
                </CardFooter>
              </Card>

              <Card className="bg-discord-dark border-discord-darker mt-6">
                <CardHeader>
                  <CardTitle className="text-white">Premium Features</CardTitle>
                  <CardDescription>Upgrade to access more features</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-white">Advanced raid protection</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-white">Custom verification flows</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-white">Auto-mute repeat offenders</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-white">Unlimited logging history</span>
                  </div>
                </CardContent>
                <CardFooter className="pt-2">
                  <Button className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-white border-0">
                    <Award className="mr-2 h-4 w-4" />
                    Upgrade to Premium
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* AutoMod Tab */}
        <TabsContent value="automod">
          <Card className="bg-discord-dark border-discord-darker mb-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-white">AutoMod Configuration</CardTitle>
                  <CardDescription>Configure automatic moderation settings for your server</CardDescription>
                </div>
                <Switch checked={autoModSettings?.enabled || false} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FeatureCard
                  title="Profanity Filter"
                  description="Filter offensive language and slurs"
                  icon={<MessageSquareOff className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Spam Detection"
                  description="Prevent message flooding and repetition"
                  icon={<Copy className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Link Filter"
                  description="Control which links can be posted"
                  icon={<LinkIcon className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Scam Protection"
                  description="Block Discord nitro scams and phishing"
                  icon={<Shield className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Zalgo Text Filter"
                  description="Prevent messages with glitchy text"
                  icon={<Ban className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Mention Spam"
                  description="Prevent mass mentioning users and roles"
                  icon={<Users className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Capitals Filter"
                  description="Limit excessive use of UPPERCASE text"
                  icon={<TextQuote className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Invite Filter"
                  description="Control Discord invites to other servers"
                  icon={<LinkIcon className="h-5 w-5 text-primary" />}
                  enabled={true}
                />
                
                <FeatureCard
                  title="Emoji Spam"
                  description="Limit excessive use of emojis"
                  icon={<ThumbsUp className="h-5 w-5 text-primary" />}
                  enabled={false}
                />
                
                <FeatureCard
                  title="Image Scanning"
                  description="AI-powered NSFW and inappropriate image detection"
                  icon={<ImageOff className="h-5 w-5 text-primary" />}
                  isPremium={true}
                  enabled={false}
                />
                
                <FeatureCard
                  title="Repeated Text"
                  description="Prevent repeated phrases and characters"
                  icon={<Copy className="h-5 w-5 text-primary" />}
                  enabled={false}
                />
                
                <FeatureCard
                  title="AI Content Filter"
                  description="Advanced content moderation with AI"
                  icon={<Zap className="h-5 w-5 text-primary" />}
                  isPremium={true}
                  comingSoon={true}
                  enabled={false}
                />
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-discord-dark border-discord-darker">
              <CardHeader>
                <CardTitle className="text-white">Punishment Settings</CardTitle>
                <CardDescription>Configure how violations are handled</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Default Action</label>
                  <Select defaultValue="warn">
                    <SelectTrigger className="w-full bg-discord-darker">
                      <SelectValue placeholder="Select action" />
                    </SelectTrigger>
                    <SelectContent className="bg-discord-dark border-discord-darker">
                      <SelectItem value="none">Log Only</SelectItem>
                      <SelectItem value="delete">Delete Message</SelectItem>
                      <SelectItem value="warn">Warn User</SelectItem>
                      <SelectItem value="timeout">Timeout User</SelectItem>
                      <SelectItem value="kick">Kick User</SelectItem>
                      <SelectItem value="ban">Ban User</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Warning Threshold</label>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-400 mr-3">After</span>
                    <Select defaultValue="3">
                      <SelectTrigger className="w-24 bg-discord-darker">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent className="bg-discord-dark border-discord-darker">
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                    <span className="text-sm text-gray-400 mx-3">warnings, escalate to</span>
                    <Select defaultValue="timeout">
                      <SelectTrigger className="w-32 bg-discord-darker">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent className="bg-discord-dark border-discord-darker">
                        <SelectItem value="timeout">Timeout</SelectItem>
                        <SelectItem value="kick">Kick</SelectItem>
                        <SelectItem value="ban">Ban</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Timeout Duration</label>
                  <Select defaultValue="300">
                    <SelectTrigger className="w-full bg-discord-darker">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent className="bg-discord-dark border-discord-darker">
                      <SelectItem value="60">1 minute</SelectItem>
                      <SelectItem value="300">5 minutes</SelectItem>
                      <SelectItem value="600">10 minutes</SelectItem>
                      <SelectItem value="3600">1 hour</SelectItem>
                      <SelectItem value="21600">6 hours</SelectItem>
                      <SelectItem value="86400">1 day</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-discord-dark border-discord-darker">
              <CardHeader>
                <CardTitle className="text-white">Exemptions</CardTitle>
                <CardDescription>Configure exceptions to auto-moderation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Exempt Roles</label>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-discord-light text-white">
                      @Moderator
                      <button className="ml-1 text-white hover:text-gray-300">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                    <Badge className="bg-discord-light text-white">
                      @Admin
                      <button className="ml-1 text-white hover:text-gray-300">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                    <Button variant="outline" size="sm" className="h-6 px-2 text-xs border-gray-700 text-gray-400 hover:bg-discord-darker">
                      + Add Role
                    </Button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Exempt Channels</label>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-discord-light text-white">
                      #moderator-chat
                      <button className="ml-1 text-white hover:text-gray-300">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                    <Button variant="outline" size="sm" className="h-6 px-2 text-xs border-gray-700 text-gray-400 hover:bg-discord-darker">
                      + Add Channel
                    </Button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Logging Channel</label>
                  <Select defaultValue="mod-logs">
                    <SelectTrigger className="w-full bg-discord-darker">
                      <SelectValue placeholder="Select channel" />
                    </SelectTrigger>
                    <SelectContent className="bg-discord-dark border-discord-darker">
                      <SelectItem value="mod-logs">#mod-logs</SelectItem>
                      <SelectItem value="bot-logs">#bot-logs</SelectItem>
                      <SelectItem value="server-logs">#server-logs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium text-white">Silent Mode</h3>
                    <p className="text-xs text-gray-400">Don't notify users when actions are taken</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Verification Tab */}
        <TabsContent value="verification">
          <Card className="bg-discord-dark border-discord-darker mb-6">
            <CardHeader>
              <CardTitle className="text-lg font-medium">Verification Settings</CardTitle>
              <CardDescription>
                Configure how new members are verified before gaining access to your server.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Verification System</label>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-300">Require verification for new members</p>
                    <p className="text-xs text-gray-500 mt-1">New members will need to verify before accessing your server.</p>
                  </div>
                  <Switch checked={verificationSettings?.enabled || false} />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Verification Type</label>
                <Select defaultValue="captcha">
                  <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                    <SelectValue placeholder="Select a verification method" />
                  </SelectTrigger>
                  <SelectContent className="bg-discord-dark border-discord-darker">
                    <SelectItem value="captcha">CAPTCHA</SelectItem>
                    <SelectItem value="reaction">Reaction Verification</SelectItem>
                    <SelectItem value="question">Custom Question</SelectItem>
                    <SelectItem value="role">Role-based</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">Choose how members will verify themselves.</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Verification Channel</label>
                <Select defaultValue="welcome">
                  <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                    <SelectValue placeholder="Select a channel" />
                  </SelectTrigger>
                  <SelectContent className="bg-discord-dark border-discord-darker">
                    <SelectItem value="welcome">#welcome</SelectItem>
                    <SelectItem value="verify">#verify</SelectItem>
                    <SelectItem value="verification">#verification</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">Channel where verification messages will be sent.</p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Verified Role</label>
                <Select defaultValue="member">
                  <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent className="bg-discord-dark border-discord-darker">
                    <SelectItem value="member">Member</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="user">User</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">Role to assign after verification.</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Welcome Message</label>
                <textarea 
                  className="w-full bg-discord-darker border-gray-700 rounded-md p-2 text-sm"
                  placeholder="Welcome to our server! Please follow the instructions to verify your account."
                  rows={3}
                  defaultValue={"Welcome to our server! Please follow the instructions to verify your account."}
                />
                <p className="text-xs text-gray-500 mt-1">Message shown to users during verification.</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-200">Verification Timeout</label>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-300">Kick unverified users</p>
                    <p className="text-xs text-gray-500 mt-1">Automatically kick users who don't verify within the time limit.</p>
                  </div>
                  <Switch checked={false} />
                </div>
                
                <div className="mt-2">
                  <Select defaultValue="86400">
                    <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                      <SelectValue placeholder="Select timeout duration" />
                    </SelectTrigger>
                    <SelectContent className="bg-discord-dark border-discord-darker">
                      <SelectItem value="3600">1 hour</SelectItem>
                      <SelectItem value="21600">6 hours</SelectItem>
                      <SelectItem value="43200">12 hours</SelectItem>
                      <SelectItem value="86400">1 day</SelectItem>
                      <SelectItem value="259200">3 days</SelectItem>
                      <SelectItem value="604800">1 week</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2 border-t border-gray-800 pt-4">
              <Button variant="outline" className="border-gray-700">Reset</Button>
              <Button>Save Changes</Button>
            </CardFooter>
          </Card>
          
          <Card className="bg-discord-dark border-discord-darker">
            <CardHeader>
              <CardTitle className="text-lg font-medium">Verification Analytics</CardTitle>
              <CardDescription>
                Track how your verification system is performing over time.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-black/30 p-4 rounded-lg border border-gray-800">
                  <div className="text-xs font-medium text-gray-500 uppercase">Attempted Verifications</div>
                  <div className="mt-2 flex items-baseline">
                    <div className="text-2xl font-bold text-white">178</div>
                    <div className="ml-2 text-xs text-green-500 flex items-center">
                      <MoveRight className="h-3 w-3 mr-1 rotate-45" />
                      +12%
                    </div>
                  </div>
                </div>
                
                <div className="bg-black/30 p-4 rounded-lg border border-gray-800">
                  <div className="text-xs font-medium text-gray-500 uppercase">Successful Verifications</div>
                  <div className="mt-2 flex items-baseline">
                    <div className="text-2xl font-bold text-white">126</div>
                    <div className="ml-2 text-xs text-green-500 flex items-center">
                      <MoveRight className="h-3 w-3 mr-1 rotate-45" />
                      +8%
                    </div>
                  </div>
                </div>
                
                <div className="bg-black/30 p-4 rounded-lg border border-gray-800">
                  <div className="text-xs font-medium text-gray-500 uppercase">Verification Success Rate</div>
                  <div className="mt-2 flex items-baseline">
                    <div className="text-2xl font-bold text-white">71%</div>
                    <div className="ml-2 text-xs text-red-500 flex items-center">
                      <MoveRight className="h-3 w-3 mr-1 rotate-[135deg]" />
                      -3%
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="h-64 bg-black/30 rounded-lg border border-gray-800 p-4 flex items-center justify-center">
                <div className="text-center">
                  <BarChart className="h-10 w-10 text-gray-500 mx-auto mb-2" />
                  <p className="text-gray-300">Verification activity chart will appear here</p>
                  <p className="text-xs text-gray-500 mt-1">Showing data from the last 30 days</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              <Card className="bg-discord-dark border-discord-darker">
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Bot Settings</CardTitle>
                  <CardDescription>
                    Configure Guard-shin's behavior for your server.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-200">Command Prefix</label>
                    <div className="flex space-x-2">
                      <div className="flex-1">
                        <input 
                          type="text" 
                          className="w-full bg-discord-darker border border-gray-700 rounded-md px-3 py-2"
                          defaultValue="!"
                          placeholder="Enter a prefix (e.g., !, /, >)"
                        />
                      </div>
                      <Button size="sm">Update</Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">The prefix used to trigger Guard-shin commands.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-200">Log Channel</label>
                    <Select defaultValue="mod-logs">
                      <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                        <SelectValue placeholder="Select a log channel" />
                      </SelectTrigger>
                      <SelectContent className="bg-discord-dark border-discord-darker">
                        <SelectItem value="mod-logs">#mod-logs</SelectItem>
                        <SelectItem value="bot-logs">#bot-logs</SelectItem>
                        <SelectItem value="admin-logs">#admin-logs</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">Channel where bot activity will be logged.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-200">Admin Roles</label>
                    <Select defaultValue="admin">
                      <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                        <SelectValue placeholder="Select admin roles" />
                      </SelectTrigger>
                      <SelectContent className="bg-discord-dark border-discord-darker">
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="moderator">Moderator</SelectItem>
                        <SelectItem value="staff">Staff</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">Roles that can use admin commands.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-200">Mute Role</label>
                    <Select defaultValue="muted">
                      <SelectTrigger className="w-full bg-discord-darker border-gray-700">
                        <SelectValue placeholder="Select a mute role" />
                      </SelectTrigger>
                      <SelectContent className="bg-discord-dark border-discord-darker">
                        <SelectItem value="muted">Muted</SelectItem>
                        <SelectItem value="timeout">Timeout</SelectItem>
                        <SelectItem value="silenced">Silenced</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">Role assigned to muted users.</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-200">Bot Features</label>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-300">Welcome Messages</p>
                        <p className="text-xs text-gray-500 mt-1">Send a welcome message when new members join.</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div>
                        <p className="text-sm text-gray-300">Level System</p>
                        <p className="text-xs text-gray-500 mt-1">Enable user levels and experience points.</p>
                      </div>
                      <Switch checked={false} />
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div>
                        <p className="text-sm text-gray-300">Custom Commands</p>
                        <p className="text-xs text-gray-500 mt-1">Allow admins to create custom commands.</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2 border-t border-gray-800 pt-4">
                  <Button variant="outline" className="border-gray-700">Reset</Button>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>
            </div>
            
            <div className="space-y-6">
              <Card className="bg-discord-dark border-discord-darker">
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Bot Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Bot Command Debugger (admin only) */}
                  {isPremium && (
                    <div className="mb-4 pb-4 border-b border-gray-800">
                      <h3 className="text-sm font-medium text-primary mb-2">Command Debugging</h3>
                      <BotCommandDebugger isAdmin={true} />
                    </div>
                  )}
                
                  <div>
                    <div className="text-sm text-gray-500">Bot Version</div>
                    <div className="text-white">v1.2.0</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Command Count</div>
                    <div className="text-white">48</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Last Updated</div>
                    <div className="text-white">April 16, 2025</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Status</div>
                    <div className="flex items-center">
                      <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                      <span className="text-white">Online</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="border-t border-gray-800 pt-4">
                  <Button variant="outline" className="w-full border-gray-700" onClick={() => window.open('https://discord.gg/g3rFbaW6gw', '_blank')}>
                    <BookOpen className="h-4 w-4 mr-2" />
                    Support Server
                  </Button>
                </CardFooter>
              </Card>
              
              <Card className="bg-discord-dark border-discord-darker">
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Danger Zone</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-300">Reset Bot Settings</p>
                      <p className="text-xs text-gray-500 mt-1">Restore default settings.</p>
                    </div>
                    <Button variant="outline" className="border-gray-700 text-gray-400 hover:text-white">
                      Reset
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-300">Clear Infractions</p>
                      <p className="text-xs text-gray-500 mt-1">Remove all infraction records.</p>
                    </div>
                    <Button variant="outline" className="border-gray-700 text-gray-400 hover:text-white">
                      Clear
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-red-400">Remove Bot</p>
                      <p className="text-xs text-gray-500 mt-1">Remove Guard-shin from your server.</p>
                    </div>
                    <Button variant="destructive" size="sm">
                      Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default Dashboard;
