import React, { useEffect } from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  SiDiscord 
} from 'react-icons/si';
import { 
  Users, 
  MessageSquare, 
  Shield, 
  Star, 
  Award, 
  Zap, 
  Info, 
  HelpCircle, 
  Globe, 
  Clock, 
  ArrowRight, 
  Terminal
} from 'lucide-react';

export default function SupportServerPage() {
  useEffect(() => {
    document.title = "Support Server - Guard-shin";
  }, []);

  // Discord invite link
  const discordInviteLink = "https://discord.gg/g3rFbaW6gw";

  // Handle redirect to Discord
  const handleJoinServer = () => {
    window.open(discordInviteLink, '_blank');
  };

  return (
    <DashboardLayout title="Support Server">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Support Server</h1>
            <p className="text-muted-foreground">
              Join our community for help, updates, and more
            </p>
          </div>
          
          <button
            onClick={handleJoinServer}
            className="flex items-center gap-2 px-4 py-2 rounded-md bg-[#5865F2] hover:bg-[#4752c4] transition-colors font-medium text-white"
          >
            <SiDiscord className="h-5 w-5" />
            <span>Join Discord Server</span>
          </button>
        </div>
        
        {/* Hero section */}
        <div className="relative rounded-lg overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary-foreground/20 backdrop-blur-sm z-0" />
          <div className="relative z-10 p-6 sm:p-8 flex flex-col items-center text-center">
            <SiDiscord className="h-16 w-16 text-[#5865F2] mb-4" />
            <h2 className="text-2xl font-bold mb-2">Guard-shin Community</h2>
            <p className="max-w-2xl text-muted-foreground mb-6">
              Our Discord server is the central hub for announcements, support, and connecting with other Guard-shin users. Get real-time help from our staff and community members.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-4">
              <div className="flex items-center gap-2 bg-secondary/20 rounded-full px-4 py-1.5">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm">Active Community</span>
              </div>
              <div className="flex items-center gap-2 bg-secondary/20 rounded-full px-4 py-1.5">
                <Shield className="h-4 w-4 text-primary" />
                <span className="text-sm">Dedicated Support</span>
              </div>
              <div className="flex items-center gap-2 bg-secondary/20 rounded-full px-4 py-1.5">
                <Terminal className="h-4 w-4 text-primary" />
                <span className="text-sm">Bot Updates</span>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              Server invite: <span className="font-mono bg-black/30 px-2 py-0.5 rounded">{discordInviteLink}</span>
            </div>
          </div>
        </div>
        
        {/* Features grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Live Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Get real-time assistance from our support team and community members. We're always ready to help with any issues or questions.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                Bot Updates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Be the first to know about new features, improvements, and fixes. Our announcement channel keeps you updated on all changes.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Community
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Connect with other server owners and moderators. Share tips, strategies, and build relationships with like-minded individuals.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Premium Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Premium members get access to dedicated support channels with priority assistance. Resolve issues faster with our specialized team.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" />
                Feature Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Suggest new features and improvements directly to our development team. Your input helps shape the future of Guard-shin.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5 text-primary" />
                Guides & Tutorials
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Access helpful guides, tutorials, and resources to get the most out of Guard-shin. Learn about advanced features and best practices.
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Support channels */}
        <Card>
          <CardHeader>
            <CardTitle>Support Channels</CardTitle>
            <CardDescription>
              Our server has dedicated channels for different types of support
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-[#5865F2]/10 p-2 mt-0.5">
                  <MessageSquare className="h-5 w-5 text-[#5865F2]" />
                </div>
                <div>
                  <h3 className="font-medium">#general-support</h3>
                  <p className="text-sm text-muted-foreground">
                    For general questions and issues related to Guard-shin Bot. Our support team and community members monitor this channel regularly.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-[#5865F2]/10 p-2 mt-0.5">
                  <Shield className="h-5 w-5 text-[#5865F2]" />
                </div>
                <div>
                  <h3 className="font-medium">#moderation-help</h3>
                  <p className="text-sm text-muted-foreground">
                    Get assistance with moderation features, auto-mod configuration, raid protection settings, and best practices for server security.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-[#5865F2]/10 p-2 mt-0.5">
                  <Terminal className="h-5 w-5 text-[#5865F2]" />
                </div>
                <div>
                  <h3 className="font-medium">#commands-help</h3>
                  <p className="text-sm text-muted-foreground">
                    Learn how to use Guard-shin's commands effectively. Get help with command syntax, permissions, and troubleshooting.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-[#5865F2]/10 p-2 mt-0.5">
                  <Star className="h-5 w-5 text-[#5865F2]" />
                </div>
                <div>
                  <h3 className="font-medium">#premium-support <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">Premium</span></h3>
                  <p className="text-sm text-muted-foreground">
                    Exclusive channel for premium subscribers. Get priority support directly from our staff with faster response times.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-border pt-4 flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Join our server to access these support channels
            </p>
            <button
              onClick={handleJoinServer}
              className="flex items-center gap-1 text-primary hover:underline text-sm font-medium"
            >
              <span>Join Now</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </CardFooter>
        </Card>
        
        {/* Support hours & Guidelines */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Support Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Our support team is available during the following hours:
              </p>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Weekdays</span>
                  <span className="text-sm text-muted-foreground">9:00 AM - 9:00 PM EST</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Weekends</span>
                  <span className="text-sm text-muted-foreground">11:00 AM - 6:00 PM EST</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Premium Support</span>
                  <span className="text-sm text-muted-foreground">24/7 (Response within 12 hours)</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5" />
                Server Guidelines
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Please follow these guidelines when interacting in our server:</p>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1 pl-2">
                  <li>Be respectful to all community members and staff</li>
                  <li>Stay on topic in each channel</li>
                  <li>Do not spam or self-promote</li>
                  <li>Use English for better communication</li>
                  <li>Follow Discord's Terms of Service</li>
                  <li>Report issues to moderators when needed</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* CTA Section */}
        <div className="rounded-lg border border-border bg-card overflow-hidden mt-2">
          <div className="p-6 sm:p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to join our community?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-6">
              Join thousands of servers using Guard-shin and connect with our community for the best moderation experience.
            </p>
            <button
              onClick={handleJoinServer}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-[#5865F2] hover:bg-[#4752c4] transition-colors font-medium text-white"
            >
              <SiDiscord className="h-5 w-5" />
              <span>Join Our Discord Server</span>
            </button>
            <p className="text-xs text-muted-foreground mt-4">
              By joining, you agree to follow our server guidelines and Discord's Terms of Service.
            </p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}