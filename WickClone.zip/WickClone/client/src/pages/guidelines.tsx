import React from 'react';
import { Link } from 'wouter';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Heart, Users, MessageSquare } from 'lucide-react';

export default function GuidelinesPage() {
  return (
    <div className="container max-w-4xl py-8 px-4 mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild className="gap-2">
          <Link href="/">
            <ChevronLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>
      
      <div className="flex items-center space-x-2 mb-6">
        <Heart className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Community Guidelines</h1>
      </div>
      
      <div className="bg-card rounded-lg border p-6 shadow-sm">
        <ScrollArea className="h-[60vh]">
          <div className="prose prose-invert max-w-none">
            <p className="text-muted-foreground text-sm mb-4">Last Updated: April 16, 2025</p>
            
            <p>
              At Guard-shin, we're committed to creating a safe, respectful, and positive environment for all users. These Community Guidelines outline the behaviors and practices we expect from everyone using our services, including the Guard-shin Discord bot, dashboard, and support server.
            </p>
            
            <h2>1. Respect Each Other</h2>
            <p>
              Treat everyone with respect. We do not tolerate:
            </p>
            <ul>
              <li>Harassment or bullying of any kind</li>
              <li>Hate speech, including content that promotes violence or hatred against people based on race, ethnicity, nationality, religion, disability, gender, age, veteran status, or sexual orientation</li>
              <li>Threats, incitement of violence, or encouragement of self-harm</li>
              <li>Excessive profanity or offensive language</li>
              <li>Personal attacks or derogatory comments</li>
            </ul>
            
            <h2>2. Use Guard-shin Responsibly</h2>
            <p>
              Guard-shin is designed to help moderate and protect Discord communities. We expect users to:
            </p>
            <ul>
              <li>Configure moderation tools appropriately for their community's needs</li>
              <li>Not use Guard-shin for spam, harassment, or to circumvent Discord's Terms of Service</li>
              <li>Not attempt to abuse, exploit, or bypass any of Guard-shin's security features</li>
              <li>Use anti-raid and verification features responsibly</li>
            </ul>
            
            <h2>3. Keep Communication Appropriate</h2>
            <p>
              When interacting in our support server or with our team:
            </p>
            <ul>
              <li>Stay on topic in support channels</li>
              <li>Do not spam or flood channels with messages</li>
              <li>Avoid sharing personal information publicly</li>
              <li>Use clear and constructive language when reporting issues or requesting help</li>
              <li>Do not impersonate Guard-shin staff or other users</li>
            </ul>
            
            <h2>4. Content Guidelines</h2>
            <p>
              When sharing content in Guard-shin-related spaces:
            </p>
            <ul>
              <li>Do not share NSFW or explicit content</li>
              <li>Do not share illegal content or content that facilitates illegal activities</li>
              <li>Do not share personally identifiable information about yourself or others</li>
              <li>Do not share malicious links, files, or code</li>
              <li>Respect copyright and intellectual property rights</li>
            </ul>
            
            <h2>5. Premium Features and Transactions</h2>
            <p>
              Regarding premium subscriptions and payments:
            </p>
            <ul>
              <li>Do not attempt to bypass payment systems or access premium features without proper payment</li>
              <li>Do not share premium access across multiple Discord servers beyond what your subscription allows</li>
              <li>Report billing issues through proper channels rather than public forums</li>
              <li>Do not engage in chargebacks unless you have a legitimate reason and have first attempted to resolve the issue with our support team</li>
            </ul>
            
            <h2>6. Feedback and Bug Reports</h2>
            <p>
              We welcome feedback and bug reports. When providing these:
            </p>
            <ul>
              <li>Be specific and provide clear details about any issues encountered</li>
              <li>Report bugs through designated channels rather than publicly exposing security vulnerabilities</li>
              <li>Be constructive in your criticism and suggestions</li>
              <li>Understand that not all feature requests can be implemented</li>
            </ul>
            
            <h2>7. Support Server Rules</h2>
            <p>
              In our <a href="https://discord.gg/g3rFbaW6gw" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Support Server</a>, additional rules apply:
            </p>
            <ul>
              <li>Follow channel-specific rules and topics</li>
              <li>Listen to and respect the staff members and moderators</li>
              <li>Do not advertise other services, Discord servers, or products</li>
              <li>Use the appropriate channels for your questions or concerns</li>
              <li>Be patient when waiting for support responses</li>
            </ul>
            
            <h2>8. Consequences of Violations</h2>
            <p>
              Violations of these guidelines may result in:
            </p>
            <ul>
              <li>Warnings from our staff</li>
              <li>Temporary or permanent removal from our support server</li>
              <li>Restrictions on bot usage or access to specific features</li>
              <li>Termination of premium subscriptions without refund in severe cases</li>
              <li>In cases of illegal activity, reporting to appropriate authorities</li>
            </ul>
            
            <h2>9. Reporting Violations</h2>
            <p>
              If you encounter violations of these guidelines:
            </p>
            <ol>
              <li>In our support server, alert a staff member using the appropriate channels</li>
              <li>For bot-related issues, email our team at <a href="mailto:support@witherco.org" className="text-primary hover:underline">support@witherco.org</a></li>
              <li>Include relevant information and evidence when possible</li>
            </ol>
            
            <h2>10. Changes to Guidelines</h2>
            <p>
              These guidelines may be updated periodically. Significant changes will be announced in our support server and on our website. Continued use of Guard-shin services after changes constitutes acceptance of the updated guidelines.
            </p>
            
            <p className="mt-8">
              Thank you for helping us maintain a positive and respectful community. By following these guidelines, you contribute to creating a better experience for everyone using Guard-shin.
            </p>
          </div>
        </ScrollArea>
      </div>
      
      <div className="mt-6 text-center text-sm text-muted-foreground">
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/terms-of-service" className="text-primary hover:underline">
            Terms of Service
          </Link>
          <Link href="/privacy-policy" className="text-primary hover:underline">
            Privacy Policy
          </Link>
          <Link href="/refund-policy" className="text-primary hover:underline">
            Refund Policy
          </Link>
          <Link href="/guidelines" className="text-primary hover:underline">
            Community Guidelines
          </Link>
        </div>
      </div>
    </div>
  );
}