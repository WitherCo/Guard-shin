import React from "react";
import { useLocation } from "wouter";
import { SiDiscord } from "react-icons/si";
import { Shield, AlertTriangle, Check, ChevronRight, Lock } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const DiscordSignup: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [agreedToTerms, setAgreedToTerms] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const handleSignupWithDiscord = () => {
    if (!agreedToTerms) {
      toast({
        title: "Terms of Service Required",
        description: "You must agree to the Terms of Service to continue.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    // Redirect to Discord OAuth flow
    window.location.href = "/api/auth/discord";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 flex flex-col items-center justify-center p-4">
      <div className="absolute top-0 left-0 w-full h-full bg-[url('/noise.png')] opacity-[0.02] pointer-events-none z-0"></div>
      
      <div className="w-full max-w-md z-10">
        <div className="text-center mb-6">
          <div className="flex justify-center mb-2">
            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-white">Guard-shin</h1>
          <p className="text-gray-400 mt-1">Discord security and moderation</p>
        </div>

        <Card className="bg-black/40 border-gray-800 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl text-white">Sign Up with Discord</CardTitle>
            <CardDescription>
              Connect your Discord account to access the dashboard
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3.5 w-3.5 text-green-500" />
                </div>
                <p className="text-gray-300">Access powerful moderation & security features</p>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3.5 w-3.5 text-green-500" />
                </div>
                <p className="text-gray-300">Manage all your Discord servers in one place</p>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3.5 w-3.5 text-green-500" />
                </div>
                <p className="text-gray-300">Configure advanced auto-moderation settings</p>
              </div>
            </div>

            <div className="border-t border-gray-800 my-4 pt-4">
              <div className="flex items-center space-x-2 mb-4">
                <Checkbox 
                  id="terms" 
                  checked={agreedToTerms}
                  onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
                />
                <Label htmlFor="terms" className="text-sm text-gray-300">
                  I agree to the <a href="/terms" className="text-primary hover:underline">Terms of Service</a> and <a href="/privacy" className="text-primary hover:underline">Privacy Policy</a>
                </Label>
              </div>
              
              <div className="flex flex-col space-y-3">
                <Button 
                  className="bg-[#5865F2] hover:bg-[#4752C4] text-white flex items-center justify-center"
                  disabled={loading}
                  onClick={handleSignupWithDiscord}
                >
                  <SiDiscord className="mr-2 h-5 w-5" />
                  {loading ? "Connecting..." : "Continue with Discord"}
                </Button>
                
                <div className="relative h-[1px] bg-gray-800 my-2">
                  <span className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black px-2 text-xs text-gray-500">OR</span>
                </div>
                
                <Button 
                  variant="outline" 
                  className="border-gray-800 text-gray-300 hover:bg-gray-900"
                  onClick={() => navigate("/login")}
                >
                  <Lock className="mr-2 h-4 w-4" />
                  Sign in with email
                </Button>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex flex-col space-y-4 px-6 pt-0 pb-6">
            <div className="flex items-start space-x-3 p-3 rounded bg-amber-500/10 border border-amber-500/20">
              <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-amber-300 font-medium">Discord Permissions</p>
                <p className="text-xs text-gray-400 mt-1">
                  We only request necessary permissions to manage your servers and provide moderation services.
                </p>
              </div>
            </div>
            
            <p className="text-xs text-gray-500 text-center mt-4">
              Need help? <a href="https://discord.gg/g3rFbaW6gw" className="text-primary hover:underline">Join our support server</a>
            </p>
          </CardFooter>
        </Card>
        
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            &copy; {new Date().getFullYear()} Guard-shin | <a href="https://witherco.org" className="hover:underline">witherco.org</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default DiscordSignup;