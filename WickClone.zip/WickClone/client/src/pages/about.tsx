import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Shield, 
  AlertTriangle, 
  MessageSquareText, 
  Bell, 
  Settings, 
  Zap, 
  Award, 
  HelpCircle,
  BookOpen
} from "lucide-react";
import { SiDiscord } from "react-icons/si";
import botImage from "@assets/Gemini_Generated_Image_conf40conf40conf.jpg";

export default function AboutPage() {
  return (
    <div className="bg-gradient-to-b from-black to-gray-900 min-h-screen text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="max-w-xs mx-auto mb-8">
            <img 
              src={botImage}
              alt="Guard-shin security bot" 
              className="rounded-lg shadow-glow mx-auto"
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">About Guard-shin</h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            An advanced Discord moderation bot designed to keep your server safe and secure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div>
            <h2 className="text-2xl font-semibold mb-6 border-l-4 border-primary pl-4">Our Mission</h2>
            <p className="text-gray-300 leading-relaxed mb-6">
              Guard-shin was developed with a singular focus: to provide Discord server administrators 
              with the most powerful and reliable moderation tools available. We understand the challenges 
              of managing online communities, especially as they grow in size and complexity.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Our mission is to help you create a safe, enjoyable environment for your members 
              through advanced security features, intelligent automation, and comprehensive 
              moderation tools. With Guard-shin at your side, you can focus on building your 
              community while we handle the security.
            </p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-8 border border-gray-700">
            <h2 className="text-2xl font-semibold mb-6 text-primary">What Makes Us Different</h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Shield className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-1" />
                <span>Advanced security algorithms that adapt to threats in real-time</span>
              </li>
              <li className="flex items-start">
                <AlertTriangle className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-1" />
                <span>Intelligent raid protection that identifies coordinated attacks</span>
              </li>
              <li className="flex items-start">
                <MessageSquareText className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-1" />
                <span>Content moderation that understands context, not just keywords</span>
              </li>
              <li className="flex items-start">
                <Bell className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-1" />
                <span>Customizable notifications for all moderation events</span>
              </li>
              <li className="flex items-start">
                <Settings className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-1" />
                <span>Intuitive dashboard for easy configuration and management</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-semibold mb-8 text-center">Premium Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 text-primary mr-2" />
                  Advanced Auto-Moderation
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Context-aware content filtering
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                Go beyond simple word filters with our AI-powered content moderation that understands
                context and can detect problematic content even when users try to bypass filters.
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="h-5 w-5 text-primary mr-2" />
                  Custom Welcome Messages
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Make new members feel at home
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                Create personalized welcome experiences with custom messages, role assignments,
                and interactive components to help new members navigate your server.
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="h-5 w-5 text-primary mr-2" />
                  Comprehensive Logs
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Complete visibility into server activity
                </CardDescription>
              </CardHeader>
              <CardContent className="text-gray-300">
                Access detailed, searchable logs of all moderation actions, member activities,
                and server events to maintain accountability and transparency.
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center mb-16">
          <h2 className="text-2xl font-semibold mb-6">Contact & Support</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Have questions or need assistance with Guard-shin? Our team is here to help!
            Reach out through our support channels or join our Discord community.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild variant="default" size="lg" className="gap-2">
              <Link href="/contact-public">
                <HelpCircle className="h-4 w-4" />
                Contact Support
              </Link>
            </Button>
            <Button asChild size="lg" className="gap-2 bg-blue-500 hover:bg-blue-600 text-white">
              <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer">
                <SiDiscord className="h-5 w-5" />
                Join Support Server
              </a>
            </Button>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-6">Ready to Secure Your Server?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Add Guard-shin to your Discord server today and experience the most advanced
            moderation tools available to keep your community safe.
          </p>
          <Button asChild size="lg" className="bg-gradient-to-r from-primary to-primary-foreground hover:opacity-90 transition-opacity">
            <a
              href="https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2"
            >
              <SiDiscord className="h-5 w-5" />
              Add to Discord
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
}