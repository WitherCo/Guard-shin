import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Shield, ChevronLeft, Bot, Lock } from 'lucide-react';
import { SiDiscord } from 'react-icons/si';
import RegistrationForm from '@/components/auth/RegistrationForm';

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-border py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Guard-shin</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild size="sm">
              <Link href="/">
                <ChevronLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <Button variant="outline" asChild size="sm">
              <Link href="/login">
                Log In
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8 bg-gradient-to-b from-background to-background/80">
        <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {/* Registration form */}
          <div className="flex flex-col items-center order-2 md:order-1">
            <RegistrationForm />
            
            <div className="mt-8 text-center max-w-sm space-y-4">
              <div className="relative py-2">
                <div className="absolute inset-0 flex items-center">
                  <Separator className="w-full" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-background px-2 text-muted-foreground">
                    Or continue with
                  </span>
                </div>
              </div>
              
              <Button variant="outline" className="w-full" asChild>
                <Link href="/api/auth/discord">
                  <SiDiscord className="mr-2 h-4 w-4" />
                  Sign up with Discord
                </Link>
              </Button>
              
              <p className="text-xs text-muted-foreground">
                By signing up, you agree to our{' '}
                <Link href="/terms-of-service" className="text-primary hover:underline">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link href="/privacy-policy" className="text-primary hover:underline">
                  Privacy Policy
                </Link>
              </p>
            </div>
          </div>
          
          {/* Information section */}
          <div className="bg-card border rounded-lg p-8 order-1 md:order-2">
            <div className="flex items-center gap-2 mb-6">
              <Bot className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">Join Guard-shin</h1>
            </div>
            
            <div className="space-y-6">
              <p className="text-muted-foreground">
                Create an account to manage your Discord servers with Guard-shin, the ultimate security and moderation bot.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Advanced Security</h3>
                    <p className="text-sm text-muted-foreground">
                      Protect your Discord server with AI-powered moderation and anti-raid features.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Easy Configuration</h3>
                    <p className="text-sm text-muted-foreground">
                      Customize Guard-shin to fit your server's needs with our intuitive dashboard.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Lock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Premium Features</h3>
                    <p className="text-sm text-muted-foreground">
                      Gain access to exclusive premium features like welcome messages, verification systems, and detailed analytics.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mt-6">
                <h3 className="font-medium mb-2 flex items-center gap-2">
                  <SiDiscord className="h-4 w-4" />
                  Join Our Community
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Get support, share feedback, and connect with other server owners in our Discord support server.
                </p>
                <Button size="lg" className="w-full bg-blue-500 hover:bg-blue-600 text-white" asChild>
                  <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="mr-2 h-5 w-5" />
                    Join Support Server
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="py-6 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-semibold">Guard-shin</span>
              <span className="text-sm text-muted-foreground">© 2025</span>
            </div>
            
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
              <Link href="/terms-of-service" className="hover:text-foreground transition-colors">
                Terms
              </Link>
              <Link href="/privacy-policy" className="hover:text-foreground transition-colors">
                Privacy
              </Link>
              <Link href="/refund-policy" className="hover:text-foreground transition-colors">
                Refunds
              </Link>
              <Link href="/guidelines" className="hover:text-foreground transition-colors">
                Guidelines
              </Link>
              <a 
                href="https://discord.gg/g3rFbaW6gw" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors"
              >
                Support
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}