import React from 'react';
import { ForgotPasswordForm } from '@/components/auth/ForgotPasswordForm';

export default function ForgotPasswordPage() {
  // Set document title directly
  React.useEffect(() => {
    document.title = "Forgot Password - Guard-shin";
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">Guard-shin</h1>
          <p className="text-gray-400">Reset your dashboard password</p>
        </div>
        <ForgotPasswordForm />
      </div>
    </div>
  );
}