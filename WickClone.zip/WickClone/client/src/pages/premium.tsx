import React from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PremiumPlans from '@/components/premium/PremiumPlans';
import { Loader2 } from 'lucide-react';

// Commands from the command list that are marked as premium
const premiumCommands = [
  { name: 'lockdown', description: 'Temporarily lock a channel, preventing messages from being sent' },
  { name: 'unlock', description: 'Unlock a previously locked channel' },
  { name: 'massban', description: 'Ban multiple users at once (Admin)' },
  { name: 'hackban', description: 'Ban a user that isn\'t in the server yet' },
  { name: 'welcome', description: 'Configure welcome messages for new members' },
  { name: 'goodbye', description: 'Configure goodbye messages for leaving members' },
  { name: 'reactionroles', description: 'Set up reaction roles for users to self-assign' },
  { name: 'autorole', description: 'Automatically assign roles to new members' },
  { name: 'welcomeimage', description: 'Generate custom welcome images for new members' },
  { name: 'autoresponse', description: 'Set up automated responses with regex patterns' },
  { name: 'starboard', description: 'Configure a starboard channel for popular messages' },
  { name: 'xp', description: 'Configure server XP system and level rewards' },
  { name: 'poll', description: 'Create interactive polls with custom options' },
  { name: 'verify', description: 'Configure verification system with custom requirements' },
  { name: 'logs', description: 'Configure advanced logging settings' },
  { name: 'antinuke', description: 'Protect against mass-administrative actions' },
  { name: 'automod', description: 'Configure advanced automoderation rules' },
  { name: 'antispam', description: 'Configure advanced anti-spam settings (regex, image, etc.)' },
  { name: 'antiraid', description: 'Configure advanced anti-raid protection systems' },
  { name: 'raffle', description: 'Create and manage server raffles/giveaways' },
  { name: 'stats', description: 'View detailed server statistics and analytics' },
  { name: 'role', description: 'Manage role assignments and permissions' },
  { name: 'mute', description: 'Advanced mute management with timed durations' },
  { name: 'backup', description: 'Create and restore server configuration backups' },
];

export default function PremiumPage() {
  // Check if user is authenticated
  const { data: user, isLoading: isUserLoading } = useQuery({
    queryKey: ['/api/auth/user'],
    retry: false,
    refetchOnWindowFocus: false
  });

  // Check if user has premium
  const { data: premiumStatus, isLoading: isPremiumLoading } = useQuery({
    queryKey: ['/api/discord/user/roles'],
    retry: false,
    refetchOnWindowFocus: false,
    enabled: !!user?.discordId
  });

  const isPremium = premiumStatus?.premium || false;
  const tierName = premiumStatus?.premiumTier || 'free';
  const isLifetime = tierName.includes('lifetime');

  const isLoading = isUserLoading || isPremiumLoading;

  return (
    <>
      <div className="min-h-screen bg-background">
        <div className="bg-gradient-to-b from-primary/5 to-background py-16">
          <div className="container">
            <div className="text-center space-y-4 mb-8">
              <h1 className="text-4xl font-bold tracking-tight">Guard-shin Premium</h1>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Unlock advanced moderation and security features for your Discord server with Guard-shin Premium.
                Protect your community with our most powerful tools.
              </p>
              {isLoading ? (
                <div className="flex justify-center mt-6">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : isPremium ? (
                <div className="flex flex-col items-center mt-6 gap-2">
                  <div className="bg-green-500/10 text-green-500 px-6 py-2 rounded-full font-medium inline-flex items-center gap-2">
                    <span className="size-2 bg-green-500 rounded-full"></span>
                    <span>Active Premium{tierName !== 'premium' ? ` (${tierName})` : ''}</span>
                  </div>
                  {isLifetime && (
                    <span className="text-sm text-muted-foreground">Lifetime plan - never expires</span>
                  )}
                </div>
              ) : (
                <Link href="#plans">
                  <Button size="lg" className="mt-6">
                    View Premium Plans
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>

        {/* Features Overview */}
        <div className="container py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Premium Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Guard-shin Premium unlocks our most powerful moderation and security tools to help you manage and protect your Discord community.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Advanced Raid Protection</h3>
              <p className="text-muted-foreground">
                Protect your server from coordinated raids with advanced detection and automatic lockdown options.
              </p>
            </div>

            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" x2="8" y1="13" y2="13"></line><line x1="16" x2="8" y1="17" y2="17"></line><line x1="10" x2="8" y1="9" y2="9"></line></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Custom Welcome Images</h3>
              <p className="text-muted-foreground">
                Create personalized welcome images for new members with customizable backgrounds and styles.
              </p>
            </div>

            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Advanced Auto-Moderation</h3>
              <p className="text-muted-foreground">
                Filter messages with regex patterns, set custom trigger thresholds, and create powerful auto-responses.
              </p>
            </div>

            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M12 20v-6M6 20V10M18 20V4"></path></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Detailed Analytics</h3>
              <p className="text-muted-foreground">
                Get insights into your server's activity with detailed member engagement statistics and reports.
              </p>
            </div>

            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M6 8c-2.646 0-4 1.354-4 4s1.354 4 4 4h12c2.646 0 4-1.354 4-4s-1.354-4-4-4H6Z"></path><path d="M15.5 6.5 14 8"></path><path d="M8.5 6.5 10 8"></path><path d="M15.5 17.5 14 16"></path><path d="M8.5 17.5 10 16"></path></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Reaction Roles</h3>
              <p className="text-muted-foreground">
                Let members self-assign roles by reacting to messages with custom emojis and role combinations.
              </p>
            </div>

            <div className="border rounded-lg p-6 bg-card">
              <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><line x1="12" x2="12" y1="8" y2="16"></line><line x1="8" x2="16" y1="12" y2="12"></line></svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Raffle System</h3>
              <p className="text-muted-foreground">
                Host giveaways and raffles with automatic winner selection and customizable entry requirements.
              </p>
            </div>
          </div>
        </div>

        {/* Premium Commands List */}
        <div className="bg-muted py-16">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Premium Commands</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Unlock these powerful commands with your premium subscription:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {premiumCommands.map((command) => (
                <div key={command.name} className="bg-card rounded-lg p-4 border">
                  <div className="font-mono text-sm text-primary mb-1">/{command.name}</div>
                  <div className="text-sm text-muted-foreground">{command.description}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Premium Plans Section */}
        <div id="plans" className="py-16">
          <PremiumPlans />
        </div>

        {/* FAQ Section */}
        <div className="bg-muted py-16">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Frequently Asked Questions</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Find answers to common questions about Guard-shin Premium:
              </p>
            </div>

            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-card rounded-lg p-6 border">
                <h3 className="text-xl font-medium mb-2">How do I activate premium after payment?</h3>
                <p className="text-muted-foreground">
                  After making a payment, join our support server and send your transaction details along with your Discord server ID. Our team will activate premium features for your server within 24 hours.
                </p>
              </div>

              <div className="bg-card rounded-lg p-6 border">
                <h3 className="text-xl font-medium mb-2">Can I transfer premium to another server?</h3>
                <p className="text-muted-foreground">
                  Yes, premium subscriptions can be transferred to a different server once every 30 days. Lifetime premium plans can be transferred once per year. Please contact our support team to request a transfer.
                </p>
              </div>

              <div className="bg-card rounded-lg p-6 border">
                <h3 className="text-xl font-medium mb-2">What's the difference between Premium and Premium+?</h3>
                <p className="text-muted-foreground">
                  Premium+ includes all Premium features plus advanced anti-raid protection, custom role management, and faster priority support. Premium+ is recommended for larger servers that need the highest level of moderation tools.
                </p>
              </div>

              <div className="bg-card rounded-lg p-6 border">
                <h3 className="text-xl font-medium mb-2">How does lifetime premium work?</h3>
                <p className="text-muted-foreground">
                  Lifetime premium is a one-time payment that provides permanent access to all premium features. It never expires and includes all future updates to premium features.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}