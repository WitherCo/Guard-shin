import React, { useState, useEffect } from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Terminal, 
  Shield, 
  AlertCircle, 
  User, 
  Settings, 
  Search, 
  Zap, 
  Info, 
  Clock, 
  Lock, 
  Star,
  Bell
} from 'lucide-react';

// Command interface
interface Command {
  name: string;
  description: string;
  usage: string;
  example: string;
  category: string;
  isPremium: boolean;
  isAdmin: boolean;
  aliases?: string[];
}

export default function CommandsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCommands, setFilteredCommands] = useState<Command[]>([]);
  const [activeCategory, setActiveCategory] = useState('all');
  
  useEffect(() => {
    document.title = "Commands - Guard-shin";
    setFilteredCommands(filterCommands(commands, searchTerm, activeCategory));
  }, [searchTerm, activeCategory]);

  // Filter commands based on search term and active category
  const filterCommands = (commands: Command[], searchTerm: string, category: string) => {
    return commands.filter(command => {
      const matchesSearch = 
        command.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        command.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (command.aliases && command.aliases.some(alias => 
          alias.toLowerCase().includes(searchTerm.toLowerCase())
        ));
        
      const matchesCategory = 
        category === 'all' || 
        command.category.toLowerCase() === category.toLowerCase() ||
        (category === 'premium' && command.isPremium) ||
        (category === 'admin' && command.isAdmin);
        
      return matchesSearch && matchesCategory;
    });
  };

  // Generate a premium upsell message
  const premiumUpsellMessage = () => {
    return (
      <div className="p-4 rounded-lg border border-primary/20 bg-primary/5 mt-4">
        <div className="flex items-start gap-3">
          <Star className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium text-primary">Premium Commands</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Premium commands require a Guard-shin Premium subscription. Upgrade today to unlock all premium features and commands.
            </p>
            <div className="mt-3">
              <a 
                href="/premium/123456789012345678" 
                className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
              >
                View Premium Plans
                <Zap className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <DashboardLayout title="Commands">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Commands</h1>
            <p className="text-muted-foreground">
              Complete list of Guard-shin commands
            </p>
          </div>
          
          <div className="relative w-full sm:w-64 lg:w-72">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search commands..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Commands section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Command List</CardTitle>
            <CardDescription>
              Browse all available commands for Guard-shin Bot
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs 
              defaultValue="all" 
              value={activeCategory}
              onValueChange={setActiveCategory}
              className="w-full"
            >
              <TabsList className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 mb-6">
                <TabsTrigger value="all" className="flex items-center gap-1.5">
                  <Terminal className="h-4 w-4" />
                  <span className="hidden sm:inline">All</span>
                </TabsTrigger>
                <TabsTrigger value="moderation" className="flex items-center gap-1.5">
                  <Shield className="h-4 w-4" />
                  <span className="hidden sm:inline">Moderation</span>
                </TabsTrigger>
                <TabsTrigger value="automod" className="flex items-center gap-1.5">
                  <AlertCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">AutoMod</span>
                </TabsTrigger>
                <TabsTrigger value="utility" className="flex items-center gap-1.5">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Utility</span>
                </TabsTrigger>
                <TabsTrigger value="info" className="flex items-center gap-1.5">
                  <Info className="h-4 w-4" />
                  <span className="hidden sm:inline">Info</span>
                </TabsTrigger>
                <TabsTrigger value="premium" className="flex items-center gap-1.5">
                  <Star className="h-4 w-4" />
                  <span className="hidden sm:inline">Premium</span>
                </TabsTrigger>
                <TabsTrigger value="admin" className="flex items-center gap-1.5">
                  <Lock className="h-4 w-4" />
                  <span className="hidden sm:inline">Admin</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value={activeCategory} className="mt-0">
                {filteredCommands.length > 0 ? (
                  <div className="space-y-4">
                    {activeCategory === 'premium' && premiumUpsellMessage()}
                    
                    {filteredCommands.map((command, index) => (
                      <div 
                        key={index} 
                        className="border rounded-lg p-4 transition-all hover:bg-secondary/5"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <h3 className="font-mono text-lg font-semibold">
                              {command.name}
                            </h3>
                            {command.isPremium && (
                              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                                <Star className="h-3 w-3 mr-1" />
                                Premium
                              </Badge>
                            )}
                            {command.isAdmin && (
                              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                                <Lock className="h-3 w-3 mr-1" />
                                Admin
                              </Badge>
                            )}
                          </div>
                          <Badge variant="secondary" className="capitalize">
                            {command.category}
                          </Badge>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-3">
                          {command.description}
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <div className="text-xs font-medium mb-1">Usage</div>
                            <div className="font-mono text-xs bg-secondary/20 p-2 rounded overflow-x-auto">
                              {command.usage}
                            </div>
                          </div>
                          <div>
                            <div className="text-xs font-medium mb-1">Example</div>
                            <div className="font-mono text-xs bg-secondary/20 p-2 rounded overflow-x-auto">
                              {command.example}
                            </div>
                          </div>
                        </div>
                        
                        {command.aliases && command.aliases.length > 0 && (
                          <div className="mt-3">
                            <div className="text-xs font-medium mb-1">Aliases</div>
                            <div className="flex flex-wrap gap-2">
                              {command.aliases.map((alias, aliasIndex) => (
                                <Badge key={aliasIndex} variant="outline" className="font-mono">
                                  {alias}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {command.isPremium && (
                          <div className="mt-3 flex items-center gap-2 text-xs text-primary">
                            <Star className="h-3 w-3" />
                            <span>This command is exclusive to Guard-shin Premium subscribers</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Search className="h-12 w-12 mx-auto text-muted-foreground opacity-20" />
                    <h3 className="mt-4 text-lg font-medium">No commands found</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Try a different search term or category
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Default prefix */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Default Prefix
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="font-mono text-lg font-semibold">;</div>
              <p className="text-sm text-muted-foreground">
                You can customize the prefix for your server using the <code className="font-mono bg-secondary/20 px-1 rounded">;prefix set</code> command.
              </p>
            </div>
            <div className="mt-4 p-3 rounded-md bg-secondary/10">
              <h4 className="font-medium text-sm flex items-center">
                <Info className="h-4 w-4 mr-2" />
                Server-specific Prefixes
              </h4>
              <p className="text-xs text-muted-foreground mt-1">
                Each server can have its own custom prefix. Use <code className="font-mono bg-secondary/20 px-1 rounded">;prefix</code> to check the current prefix in a server.
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Usage Notes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Usage Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <Info className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Command Arguments</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Arguments in <code className="font-mono bg-secondary/20 px-1 rounded">&lt;brackets&gt;</code> are required, while arguments in <code className="font-mono bg-secondary/20 px-1 rounded">[brackets]</code> are optional.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <Shield className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Permissions</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Some commands require specific permissions to use. Make sure Guard-shin has the necessary permissions in your server.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <Clock className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Cooldowns</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Some commands have cooldowns to prevent abuse. Premium users have reduced cooldowns on most commands.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">User Mentions</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  You can mention users instead of providing their ID in most commands. For example, <code className="font-mono bg-secondary/20 px-1 rounded">;warn @username</code> instead of <code className="font-mono bg-secondary/20 px-1 rounded">;warn 123456789012345678</code>.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

// Command definitions
const commands: Command[] = [
  // Moderation Commands
  {
    name: "ban",
    description: "Ban a user from the server with an optional reason",
    usage: ";ban <user> [reason] [delete_days]",
    example: ";ban @username Breaking server rules 7",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["b"]
  },
  {
    name: "unban",
    description: "Unban a user from the server",
    usage: ";unban <user_id>",
    example: ";unban 123456789012345678",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "kick",
    description: "Kick a user from the server with an optional reason",
    usage: ";kick <user> [reason]",
    example: ";kick @username Disruptive behavior",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["k"]
  },
  {
    name: "warn",
    description: "Warn a user with an optional reason",
    usage: ";warn <user> [reason]",
    example: ";warn @username Spamming in chat",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["w"]
  },
  {
    name: "warnings",
    description: "View warnings for a specific user",
    usage: ";warnings <user>",
    example: ";warnings @username",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["warns"]
  },
  {
    name: "clearwarnings",
    description: "Clear all warnings for a user",
    usage: ";clearwarnings <user>",
    example: ";clearwarnings @username",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["cw", "clearwarns"]
  },
  {
    name: "mute",
    description: "Mute a user for a specified duration",
    usage: ";mute <user> [duration] [reason]",
    example: ";mute @username 1h Excessive noise",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["m", "timeout"]
  },
  {
    name: "unmute",
    description: "Unmute a previously muted user",
    usage: ";unmute <user>",
    example: ";unmute @username",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["um"]
  },
  {
    name: "purge",
    description: "Delete a specified number of messages from a channel",
    usage: ";purge <amount> [user]",
    example: ";purge 50",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["clear", "prune"]
  },
  {
    name: "slowmode",
    description: "Set the slowmode cooldown for a channel",
    usage: ";slowmode <seconds>",
    example: ";slowmode 10",
    category: "moderation",
    isPremium: false,
    isAdmin: false,
    aliases: ["slow"]
  },
  
  // Advanced Moderation (Premium)
  {
    name: "lockdown",
    description: "Temporarily lock a channel, preventing messages from being sent",
    usage: ";lockdown [duration] [reason]",
    example: ";lockdown 30m Server raid in progress",
    category: "moderation",
    isPremium: true,
    isAdmin: false,
    aliases: ["lock"]
  },
  {
    name: "unlock",
    description: "Unlock a previously locked channel",
    usage: ";unlock",
    example: ";unlock",
    category: "moderation",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "massban",
    description: "Ban multiple users at once",
    usage: ";massban <user_id1> <user_id2> ... [reason]",
    example: ";massban 123456789012345678 234567890123456789 Raid participants",
    category: "moderation",
    isPremium: true,
    isAdmin: true,
    aliases: ["mb"]
  },
  {
    name: "hackban",
    description: "Ban a user that isn't in the server yet",
    usage: ";hackban <user_id> [reason]",
    example: ";hackban 123456789012345678 Known raider",
    category: "moderation",
    isPremium: true,
    isAdmin: false,
    aliases: ["hb", "preban"]
  },
  
  // AutoMod Commands
  {
    name: "automod",
    description: "View and configure the automod settings",
    usage: ";automod [setting] [value]",
    example: ";automod invites on",
    category: "automod",
    isPremium: false,
    isAdmin: false,
    aliases: ["am"]
  },
  {
    name: "filter",
    description: "Add or remove words from the word filter",
    usage: ";filter <add|remove|list> [word]",
    example: ";filter add badword",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "antispam",
    description: "Configure anti-spam settings",
    usage: ";antispam <on|off> [threshold] [timeframe]",
    example: ";antispam on 5 3",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "antiraid",
    description: "Configure anti-raid protection",
    usage: ";antiraid <on|off> [level]",
    example: ";antiraid on high",
    category: "automod",
    isPremium: false,
    isAdmin: false,
    aliases: ["ar"]
  },
  
  // Utility Commands
  {
    name: "prefix",
    description: "View or change the server's command prefix",
    usage: ";prefix [new_prefix]",
    example: ";prefix >",
    category: "utility",
    isPremium: false,
    isAdmin: false,
    aliases: ["setprefix"]
  },
  {
    name: "help",
    description: "Display help information for commands",
    usage: ";help [command]",
    example: ";help ban",
    category: "utility",
    isPremium: false,
    isAdmin: false,
    aliases: ["h", "commands"]
  },
  {
    name: "ping",
    description: "Check the bot's latency",
    usage: ";ping",
    example: ";ping",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "userinfo",
    description: "Display information about a user",
    usage: ";userinfo [user]",
    example: ";userinfo @username",
    category: "utility",
    isPremium: false,
    isAdmin: false,
    aliases: ["ui", "user", "whois"]
  },
  {
    name: "serverinfo",
    description: "Display information about the server",
    usage: ";serverinfo",
    example: ";serverinfo",
    category: "utility",
    isPremium: false,
    isAdmin: false,
    aliases: ["si", "server"]
  },
  
  // Premium Utility Commands
  {
    name: "welcome",
    description: "Configure welcome messages for new members",
    usage: ";welcome <on|off> [channel] [message]",
    example: ";welcome on #welcome Welcome {user} to {server}!",
    category: "utility",
    isPremium: true,
    isAdmin: false,
    aliases: ["wm"]
  },
  {
    name: "goodbye",
    description: "Configure goodbye messages for leaving members",
    usage: ";goodbye <on|off> [channel] [message]",
    example: ";goodbye on #general {user} has left the server.",
    category: "utility",
    isPremium: true,
    isAdmin: false,
    aliases: ["bye"]
  },
  {
    name: "reactionroles",
    description: "Set up reaction roles for users to self-assign",
    usage: ";reactionroles <create|remove> [message_id] [emoji] [role]",
    example: ";reactionroles create 123456789012345678 👍 @Member",
    category: "utility",
    isPremium: true,
    isAdmin: false,
    aliases: ["rr"]
  },
  {
    name: "autorole",
    description: "Automatically assign roles to new members",
    usage: ";autorole <on|off> [role]",
    example: ";autorole on @Member",
    category: "utility",
    isPremium: true,
    isAdmin: false,
    aliases: ["ar"]
  },
  {
    name: "logs",
    description: "Configure server logging",
    usage: ";logs <channel|disable> [type]",
    example: ";logs #mod-logs moderation",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  
  // Info Commands
  {
    name: "botinfo",
    description: "Display information about the bot",
    usage: ";botinfo",
    example: ";botinfo",
    category: "info",
    isPremium: false,
    isAdmin: false,
    aliases: ["bot", "about"]
  },
  {
    name: "uptime",
    description: "Check how long the bot has been online",
    usage: ";uptime",
    example: ";uptime",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "invite",
    description: "Get an invite link for the bot",
    usage: ";invite",
    example: ";invite",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "premium",
    description: "Get information about Guard-shin Premium",
    usage: ";premium",
    example: ";premium",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "support",
    description: "Get a link to the support server",
    usage: ";support",
    example: ";support",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  
  // Admin Commands
  {
    name: "setup",
    description: "Run the initial setup for Guard-shin",
    usage: ";setup",
    example: ";setup",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "config",
    description: "View and modify bot configuration",
    usage: ";config [setting] [value]",
    example: ";config modlogs #mod-logs",
    category: "admin",
    isPremium: false,
    isAdmin: true,
    aliases: ["settings"]
  },
  {
    name: "permission",
    description: "Configure command permissions for roles",
    usage: ";permission <command> <role> <allow|deny>",
    example: ";permission ban @Moderator allow",
    category: "admin",
    isPremium: false,
    isAdmin: true,
    aliases: ["perm"]
  },
  {
    name: "reset",
    description: "Reset all bot settings to default",
    usage: ";reset",
    example: ";reset",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  
  // Premium Admin Commands
  {
    name: "backup",
    description: "Create a backup of server settings and configurations",
    usage: ";backup <create|load|list> [backup_id]",
    example: ";backup create",
    category: "admin",
    isPremium: true,
    isAdmin: true
  },
  {
    name: "banlist",
    description: "View, import, or export the server ban list",
    usage: ";banlist <view|import|export>",
    example: ";banlist view",
    category: "admin",
    isPremium: true,
    isAdmin: true
  },
  {
    name: "verification",
    description: "Set up member verification system",
    usage: ";verification <setup|disable> [options]",
    example: ";verification setup captcha #verify",
    category: "admin",
    isPremium: true,
    isAdmin: true,
    aliases: ["verify"]
  }
];