import React from 'react';
import { Link } from 'wouter';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ChevronLeft, FileText } from 'lucide-react';

export default function TermsOfServicePage() {
  return (
    <div className="container max-w-4xl py-8 px-4 mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild className="gap-2">
          <Link href="/">
            <ChevronLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>
      
      <div className="flex items-center space-x-2 mb-6">
        <FileText className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Terms of Service</h1>
      </div>
      
      <div className="bg-card rounded-lg border p-6 shadow-sm">
        <ScrollArea className="h-[60vh]">
          <div className="prose prose-invert max-w-none">
            <p className="text-muted-foreground text-sm mb-4">Last Updated: April 16, 2025</p>
            
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing or using Guard-shin bot services ("Services"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our Services.
            </p>
            
            <h2>2. Description of Service</h2>
            <p>
              Guard-shin is a Discord moderation and security bot that provides tools for server administrators to protect and manage their Discord communities. The Services include, but are not limited to, auto-moderation, anti-raid protection, verification systems, and other security features.
            </p>
            
            <h2>3. User Registration and Account</h2>
            <p>
              To access certain features of the Service, you may be required to register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
            </p>
            <p>
              You are responsible for safeguarding your password and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.
            </p>
            
            <h2>4. Premium Services</h2>
            <p>
              Guard-shin offers both free and premium services. Premium features require payment of subscription fees as outlined on our pricing page. 
            </p>
            <p>
              Subscription fees are charged in advance on a monthly or annual basis. Subscriptions automatically renew unless cancelled at least 24 hours before the end of the current period.
            </p>
            
            <h2>5. User Conduct</h2>
            <p>
              You agree not to use the Services to:
            </p>
            <ul>
              <li>Violate any laws or regulations</li>
              <li>Infringe on the rights of others</li>
              <li>Distribute malware or other harmful code</li>
              <li>Attempt to gain unauthorized access to our systems or user accounts</li>
              <li>Interfere with or disrupt the integrity of the Services</li>
              <li>Harass, abuse, or harm another person</li>
              <li>Engage in any automated use of the system</li>
            </ul>
            
            <h2>6. Intellectual Property</h2>
            <p>
              All content, features, and functionality of the Services, including but not limited to text, graphics, logos, icons, images, audio clips, and software, are the exclusive property of Guard-shin and its licensors and are protected by copyright, trademark, and other intellectual property laws.
            </p>
            
            <h2>7. Limitation of Liability</h2>
            <p>
              In no event shall Guard-shin, its directors, employees, partners, agents, suppliers, or affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Services.
            </p>
            
            <h2>8. Termination</h2>
            <p>
              We may terminate or suspend your account and access to the Services immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
            </p>
            
            <h2>9. Changes to Terms</h2>
            <p>
              We reserve the right to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
            </p>
            
            <h2>10. Governing Law</h2>
            <p>
              These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.
            </p>
            
            <h2>11. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at <a href="mailto:support@witherco.org" className="text-primary hover:underline">support@witherco.org</a>.
            </p>
          </div>
        </ScrollArea>
      </div>
      
      <div className="mt-6 text-center text-sm text-muted-foreground">
        <p>
          By using Guard-shin, you agree to our{' '}
          <Link href="/terms-of-service" className="text-primary hover:underline">
            Terms of Service
          </Link>{' '}
          and{' '}
          <Link href="/privacy-policy" className="text-primary hover:underline">
            Privacy Policy
          </Link>
        </p>
      </div>
    </div>
  );
}