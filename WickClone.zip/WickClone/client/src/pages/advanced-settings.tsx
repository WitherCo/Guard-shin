import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { usePremiumStatus } from '@/hooks/use-discord';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import {
  Settings,
  Wrench,
  Sliders,
  Database,
  HardDrive,
  Bell,
  Clock,
  TimerReset,
  BellOff,
  Trash2,
  ShieldAlert,
  Shield,
  MessageSquare,
  Award,
  AlarmClock,
  PenTool,
  Undo2,
  Code,
  Eye,
  EyeOff
} from 'lucide-react';

// Form schema
const advancedSettingsSchema = z.object({
  // Bot behavior settings
  commandPrefix: z.string().max(5, { message: "Prefix must be 5 characters or less" }).default('!'),
  deleteCommandMessages: z.boolean().default(true),
  respondToBots: z.boolean().default(false),
  ignoreChannels: z.array(z.string()).default([]),
  
  // Log settings
  enableModLogs: z.boolean().default(true),
  modLogChannel: z.string().optional(),
  enableServerLogs: z.boolean().default(true),
  serverLogChannel: z.string().optional(),
  logMessageEdits: z.boolean().default(true),
  logMessageDeletes: z.boolean().default(true),
  logJoinLeave: z.boolean().default(true),
  
  // Role settings
  adminRoles: z.array(z.string()).default([]),
  modRoles: z.array(z.string()).default([]),
  muteRole: z.string().optional(),
  
  // Command cooldowns
  enableCooldowns: z.boolean().default(true),
  defaultCooldown: z.number().min(0).max(3600).default(3),
  moderationCooldown: z.number().min(0).max(3600).default(1),
  
  // Database settings
  purgeInfractions: z.boolean().default(false),
  infractionPurgeDays: z.number().min(30).max(365).default(90),
});

type AdvancedSettingsFormValues = z.infer<typeof advancedSettingsSchema>;

const AdvancedSettings: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const { isPremium } = usePremiumStatus();

  // Fetch server channels
  const { data: channels, isLoading: loadingChannels } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'channels'],
    enabled: !!selectedServerId,
  });

  // Fetch server roles
  const { data: roles, isLoading: loadingRoles } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'roles'],
    enabled: !!selectedServerId,
  });

  // Fetch advanced settings (placeholder)
  const { data: settings, isLoading: loadingSettings } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'advanced-settings'],
    enabled: !!selectedServerId,
    // Placeholder since we don't have this endpoint yet
    onError: () => {
      // Silently fail and use defaults
    }
  });

  // Form setup
  const form = useForm<AdvancedSettingsFormValues>({
    resolver: zodResolver(advancedSettingsSchema),
    defaultValues: {
      commandPrefix: '!',
      deleteCommandMessages: true,
      respondToBots: false,
      ignoreChannels: [],
      enableModLogs: true,
      modLogChannel: '',
      enableServerLogs: true,
      serverLogChannel: '',
      logMessageEdits: true,
      logMessageDeletes: true,
      logJoinLeave: true,
      adminRoles: [],
      modRoles: [],
      muteRole: '',
      enableCooldowns: true,
      defaultCooldown: 3,
      moderationCooldown: 1,
      purgeInfractions: false,
      infractionPurgeDays: 90,
    },
  });

  // Update form values when settings are loaded
  React.useEffect(() => {
    if (settings) {
      form.reset(settings);
    }
  }, [settings, form]);

  // Save settings mutation
  const saveSettings = useMutation({
    mutationFn: async (values: AdvancedSettingsFormValues) => {
      // Placeholder for API call
      toast({
        title: 'Settings saved',
        description: 'Advanced settings have been updated successfully.',
      });
      return values;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers', selectedServerId, 'advanced-settings'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save settings',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: AdvancedSettingsFormValues) => {
    saveSettings.mutate(values);
  };

  const resetSettings = () => {
    form.reset({
      commandPrefix: '!',
      deleteCommandMessages: true,
      respondToBots: false,
      ignoreChannels: [],
      enableModLogs: true,
      modLogChannel: '',
      enableServerLogs: true,
      serverLogChannel: '',
      logMessageEdits: true,
      logMessageDeletes: true,
      logJoinLeave: true,
      adminRoles: [],
      modRoles: [],
      muteRole: '',
      enableCooldowns: true,
      defaultCooldown: 3,
      moderationCooldown: 1,
      purgeInfractions: false,
      infractionPurgeDays: 90,
    });
    
    toast({
      title: 'Settings reset',
      description: 'Advanced settings have been reset to defaults.',
    });
  };

  return (
    <DashboardLayout title="Advanced Settings">
      <div className="space-y-6">
        <div className="max-w-5xl mx-auto">
          <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <div className="flex items-center">
                <div className="p-2 rounded-lg mr-3 bg-primary/10">
                  <Wrench className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-xl text-white">Advanced Bot Configuration</CardTitle>
                  <CardDescription>
                    Fine-tune the behavior and permissions of Guard-shin in your server
                  </CardDescription>
                </div>
                {!isPremium && (
                  <div className="ml-auto">
                    <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-white rounded-full px-3 py-1 text-xs font-semibold flex items-center">
                      <Award className="h-3.5 w-3.5 mr-1" />
                      Premium Feature
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <Tabs defaultValue="bot" className="w-full">
                    <TabsList className="grid grid-cols-4 mb-6">
                      <TabsTrigger value="bot">Bot Behavior</TabsTrigger>
                      <TabsTrigger value="logs">Log Settings</TabsTrigger>
                      <TabsTrigger value="roles">Role Settings</TabsTrigger>
                      <TabsTrigger value="advanced">Advanced</TabsTrigger>
                    </TabsList>

                    {/* Bot Behavior Tab */}
                    <TabsContent value="bot" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="commandPrefix"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Command Prefix</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="!"
                                  className="bg-discord-dark border-gray-700"
                                  maxLength={5}
                                  disabled={!isPremium}
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Character(s) that precede commands (e.g., !ban, .kick)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="space-y-3">
                          <FormField
                            control={form.control}
                            name="deleteCommandMessages"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-white">Delete Command Messages</FormLabel>
                                  <FormDescription className="text-xs text-gray-400">
                                    Automatically delete command messages after execution
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    disabled={!isPremium}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="respondToBots"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-white">Respond to Bots</FormLabel>
                                  <FormDescription className="text-xs text-gray-400">
                                    Allow the bot to process commands from other bots
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    disabled={!isPremium}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <FormField
                        control={form.control}
                        name="ignoreChannels"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Ignored Channels</FormLabel>
                            <Select
                              disabled={!isPremium}
                              value={field.value?.[0] || ''}
                              onValueChange={(value) => {
                                field.onChange([value]); // For simplicity, just allow one channel
                              }}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select channel" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                {/* Placeholder channels */}
                                <SelectItem value="111111111111111111">
                                  <div className="flex items-center">
                                    <span className="text-gray-400 mr-2">#</span>
                                    general
                                  </div>
                                </SelectItem>
                                <SelectItem value="222222222222222222">
                                  <div className="flex items-center">
                                    <span className="text-gray-400 mr-2">#</span>
                                    bot-commands
                                  </div>
                                </SelectItem>
                                <SelectItem value="333333333333333333">
                                  <div className="flex items-center">
                                    <span className="text-gray-400 mr-2">#</span>
                                    music
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Bot will ignore commands in these channels
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg mt-4">
                        <div className="flex items-start">
                          <Bell className="h-5 w-5 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                          <div>
                            <h3 className="text-sm font-medium text-white">Important Note</h3>
                            <p className="text-sm text-gray-400 mt-1">
                              Changing the command prefix affects all command invocations. Make sure to inform your server members about any prefix changes.
                            </p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Log Settings Tab */}
                    <TabsContent value="logs" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="enableModLogs"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base text-white">Moderation Logs</FormLabel>
                                <FormDescription className="text-sm text-gray-400">
                                  Log all moderation actions
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="modLogChannel"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Mod Log Channel</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                disabled={!isPremium || !form.getValues().enableModLogs}
                              >
                                <FormControl>
                                  <SelectTrigger className="bg-discord-dark border-gray-700">
                                    <SelectValue placeholder="Select channel" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                  {/* Placeholder channels */}
                                  <SelectItem value="444444444444444444">
                                    <div className="flex items-center">
                                      <span className="text-gray-400 mr-2">#</span>
                                      mod-logs
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="555555555555555555">
                                    <div className="flex items-center">
                                      <span className="text-gray-400 mr-2">#</span>
                                      bot-logs
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                Channel where moderation actions will be logged
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="enableServerLogs"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base text-white">Server Logs</FormLabel>
                                <FormDescription className="text-sm text-gray-400">
                                  Log server activity and member actions
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="serverLogChannel"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Server Log Channel</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                disabled={!isPremium || !form.getValues().enableServerLogs}
                              >
                                <FormControl>
                                  <SelectTrigger className="bg-discord-dark border-gray-700">
                                    <SelectValue placeholder="Select channel" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                  {/* Placeholder channels */}
                                  <SelectItem value="666666666666666666">
                                    <div className="flex items-center">
                                      <span className="text-gray-400 mr-2">#</span>
                                      server-logs
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="777777777777777777">
                                    <div className="flex items-center">
                                      <span className="text-gray-400 mr-2">#</span>
                                      activity-logs
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                Channel where server events will be logged
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="space-y-3 mt-4">
                        <h3 className="text-sm font-medium text-white">Log Events</h3>
                        <FormField
                          control={form.control}
                          name="logMessageEdits"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                              <div className="space-y-0.5">
                                <FormLabel className="text-white">Message Edits</FormLabel>
                                <FormDescription className="text-xs text-gray-400">
                                  Log when messages are edited
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium || !form.getValues().enableServerLogs}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="logMessageDeletes"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                              <div className="space-y-0.5">
                                <FormLabel className="text-white">Message Deletes</FormLabel>
                                <FormDescription className="text-xs text-gray-400">
                                  Log when messages are deleted
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium || !form.getValues().enableServerLogs}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="logJoinLeave"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                              <div className="space-y-0.5">
                                <FormLabel className="text-white">Join/Leave Events</FormLabel>
                                <FormDescription className="text-xs text-gray-400">
                                  Log when members join or leave the server
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium || !form.getValues().enableServerLogs}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </TabsContent>

                    {/* Role Settings Tab */}
                    <TabsContent value="roles" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="adminRoles"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Admin Roles</FormLabel>
                            <Select
                              disabled={!isPremium}
                              value={field.value?.[0] || ''}
                              onValueChange={(value) => {
                                field.onChange([value]); // For simplicity, just allow one role
                              }}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                {/* Placeholder roles */}
                                <SelectItem value="888888888888888888">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-red-500 mr-2" />
                                    Admin
                                  </div>
                                </SelectItem>
                                <SelectItem value="999999999999999999">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-blue-500 mr-2" />
                                    Owner
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Roles that can use all bot commands, including admin commands
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="modRoles"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Moderator Roles</FormLabel>
                            <Select
                              disabled={!isPremium}
                              value={field.value?.[0] || ''}
                              onValueChange={(value) => {
                                field.onChange([value]); // For simplicity, just allow one role
                              }}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                {/* Placeholder roles */}
                                <SelectItem value="101010101010101010">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-green-500 mr-2" />
                                    Moderator
                                  </div>
                                </SelectItem>
                                <SelectItem value="111111111111111111">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-yellow-500 mr-2" />
                                    Helper
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Roles that can use moderation commands (ban, kick, mute, etc.)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="muteRole"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Mute Role</FormLabel>
                            <Select
                              disabled={!isPremium}
                              value={field.value || ''}
                              onValueChange={field.onChange}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700 max-h-[300px]">
                                {/* Placeholder roles */}
                                <SelectItem value="121212121212121212">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-gray-500 mr-2" />
                                    Muted
                                  </div>
                                </SelectItem>
                                <SelectItem value="131313131313131313">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-gray-700 mr-2" />
                                    Timeout
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Role applied to muted users
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg mt-4">
                        <div className="flex items-start">
                          <Bell className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
                          <div>
                            <h3 className="text-sm font-medium text-white">Role Permissions</h3>
                            <p className="text-sm text-gray-400 mt-1">
                              Make sure your mute role has proper permission overrides in all text channels. It should deny "Send Messages" and "Add Reactions" permissions.
                            </p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Advanced Tab */}
                    <TabsContent value="advanced" className="space-y-4">
                      <div className="space-y-3">
                        <h3 className="text-sm font-medium text-white">Command Cooldowns</h3>
                        <FormField
                          control={form.control}
                          name="enableCooldowns"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                              <div className="space-y-0.5">
                                <FormLabel className="text-white">Enable Command Cooldowns</FormLabel>
                                <FormDescription className="text-xs text-gray-400">
                                  Prevent command spam by adding cooldowns
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="defaultCooldown"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Default Cooldown (seconds)</FormLabel>
                                <FormControl>
                                  <div className="flex items-center">
                                    <Slider
                                      disabled={!isPremium || !form.getValues().enableCooldowns}
                                      value={[field.value]}
                                      onValueChange={(value) => field.onChange(value[0])}
                                      max={30}
                                      min={0}
                                      step={1}
                                      className="mr-4 flex-1"
                                    />
                                    <Input
                                      type="number"
                                      disabled={!isPremium || !form.getValues().enableCooldowns}
                                      value={field.value}
                                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                      className="w-16 bg-discord-dark border-gray-700"
                                    />
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  Cooldown for regular commands
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="moderationCooldown"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Moderation Cooldown (seconds)</FormLabel>
                                <FormControl>
                                  <div className="flex items-center">
                                    <Slider
                                      disabled={!isPremium || !form.getValues().enableCooldowns}
                                      value={[field.value]}
                                      onValueChange={(value) => field.onChange(value[0])}
                                      max={10}
                                      min={0}
                                      step={1}
                                      className="mr-4 flex-1"
                                    />
                                    <Input
                                      type="number"
                                      disabled={!isPremium || !form.getValues().enableCooldowns}
                                      value={field.value}
                                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                      className="w-16 bg-discord-dark border-gray-700"
                                    />
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  Cooldown for moderation commands
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <div className="space-y-3 pt-4 border-t border-gray-800">
                        <h3 className="text-sm font-medium text-white">Database Settings</h3>
                        <FormField
                          control={form.control}
                          name="purgeInfractions"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-3">
                              <div className="space-y-0.5">
                                <FormLabel className="text-white">Auto-Purge Old Infractions</FormLabel>
                                <FormDescription className="text-xs text-gray-400">
                                  Automatically delete old infraction records
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="infractionPurgeDays"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Keep Infractions For (days)</FormLabel>
                              <FormControl>
                                <div className="flex items-center">
                                  <Slider
                                    disabled={!isPremium || !form.getValues().purgeInfractions}
                                    value={[field.value]}
                                    onValueChange={(value) => field.onChange(value[0])}
                                    max={365}
                                    min={30}
                                    step={1}
                                    className="mr-4 flex-1"
                                  />
                                  <Input
                                    type="number"
                                    disabled={!isPremium || !form.getValues().purgeInfractions}
                                    value={field.value}
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 30)}
                                    className="w-16 bg-discord-dark border-gray-700"
                                  />
                                </div>
                              </FormControl>
                              <FormDescription>
                                Delete infractions older than this many days
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="pt-4 border-t border-gray-800">
                        <Button 
                          type="button"
                          variant="destructive"
                          onClick={resetSettings}
                          disabled={!isPremium}
                          className="flex items-center"
                        >
                          <Undo2 className="h-4 w-4 mr-2" />
                          Reset to Defaults
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="pt-4 border-t border-gray-800 flex gap-2">
                    <Button 
                      type="submit"
                      disabled={!isPremium}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Save Changes
                    </Button>
                    <Button 
                      type="button"
                      variant="outline"
                      disabled={!isPremium}
                      className="border-gray-700"
                      onClick={() => form.reset()}
                    >
                      Cancel
                    </Button>
                    {!isPremium && (
                      <div className="ml-2 text-sm text-amber-400 flex items-center">
                        <Award className="h-3.5 w-3.5 mr-1.5" />
                        Advanced settings require a premium subscription
                      </div>
                    )}
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          <div className="mt-6">
            <h3 className="text-lg font-medium text-white mb-3">Configuration Commands</h3>
            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/config prefix !</div>
                    <div className="text-gray-400 text-xs mt-1">Set the command prefix for text commands</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/config modrole @Moderator</div>
                    <div className="text-gray-400 text-xs mt-1">Set the moderator role</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/config logchannel #server-logs</div>
                    <div className="text-gray-400 text-xs mt-1">Set the logging channel</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/config muterole @Muted</div>
                    <div className="text-gray-400 text-xs mt-1">Set the role used for muting members</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdvancedSettings;