import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Home, Rocket, Bell } from "lucide-react";
import { Link } from "wouter";

export default function ComingSoon() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      <Card className="w-full max-w-md mx-4 bg-gray-800 border-gray-700 shadow-lg">
        <CardHeader className="pb-0">
          <div className="flex items-center justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center text-white font-bold text-2xl">G</div>
          </div>
          <h1 className="text-2xl font-bold text-center text-white">Guard-shin</h1>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center mb-4 gap-2 text-center">
            <Rocket className="h-12 w-12 text-primary mb-2" />
            <h2 className="text-xl font-bold text-primary">Coming Soon</h2>
            <p className="mt-2 text-gray-300">
              We're working hard to bring you exciting new features. This page will be available shortly!
            </p>
            <div className="flex items-center justify-center mt-4 gap-2 text-yellow-400">
              <Clock className="h-5 w-5" />
              <span>Stay tuned for updates</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center gap-4 pt-2">
          <Button variant="outline" size="sm" asChild>
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Dashboard
            </Link>
          </Button>
          <Button variant="default" size="sm">
            <Bell className="mr-2 h-4 w-4" />
            Notify Me
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
