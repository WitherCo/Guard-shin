import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  User, 
  Shield, 
  Bell, 
  Lock, 
  CreditCard, 
  Check,
  Loader2,
  RotateCw,
  LogOut,
} from 'lucide-react';
import { SiDiscord } from 'react-icons/si';
import { Badge } from '@/components/ui/badge';
import { useLocation } from 'wouter';

const ProfilePage: React.FC = () => {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isUpdating, setIsUpdating] = useState(false);
  const [password, setPassword] = useState({
    current: '',
    new: '',
    confirm: '',
  });

  // Check if user has premium (this would be properly implemented with actual premium detection)
  const hasPremium = !!user?.premiumType;
  const premiumTier = user?.premiumType ? String(user.premiumType) : 'free';

  const [formData, setFormData] = useState({
    username: user?.username || '',
    email: 'user@example.com',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleUpdateProfile = () => {
    setIsUpdating(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsUpdating(false);
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated",
      });
    }, 1000);
  };

  const handlePasswordChange = () => {
    // Basic validation
    if (password.new !== password.confirm) {
      toast({
        title: "Passwords don't match",
        description: "The new password and confirmation do not match",
        variant: "destructive",
      });
      return;
    }
    
    if (password.new.length < 8) {
      toast({
        title: "Password too short",
        description: "Password must be at least 8 characters long",
        variant: "destructive",
      });
      return;
    }
    
    setIsUpdating(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsUpdating(false);
      setPassword({
        current: '',
        new: '',
        confirm: '',
      });
      toast({
        title: "Password updated",
        description: "Your password has been changed successfully",
      });
    }, 1000);
  };
  
  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      setLocation('/');
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error logging out",
        variant: "destructive",
      });
    }
  };

  return (
    <DashboardLayout title="Profile Settings">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          {/* User Card */}
          <Card className="w-full md:w-1/3 bg-card/50 border-border/50">
            <CardHeader className="pb-4">
              <CardTitle>Your Profile</CardTitle>
              <CardDescription>Manage your account settings</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center pb-6">
              <div className="relative">
                <div className="h-24 w-24 rounded-full bg-gradient-to-br from-primary to-primary-foreground/70 flex items-center justify-center text-white text-2xl font-medium shadow-glow">
                  {user?.username?.charAt(0)?.toUpperCase() || 'G'}
                </div>
                {hasPremium && (
                  <div className="absolute bottom-0 right-0 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-full p-1.5 border-2 border-card shadow-md">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                )}
              </div>
              
              <h3 className="text-lg font-medium mt-4">{user?.username || 'User'}</h3>
              
              {premiumTier !== 'free' && (
                <Badge className="mt-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                  {premiumTier === 'premium_plus' ? 'Premium+' : 'Premium'} Member
                </Badge>
              )}
              
              <div className="w-full mt-6">
                <div className="flex flex-col space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Account Type</span>
                    <span>{premiumTier === 'free' ? 'Free' : premiumTier === 'premium' ? 'Premium' : 'Premium+'}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">User ID</span>
                    <span>#{user?.id || '0000'}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Discord Connected</span>
                    <span>{user?.discordId ? 'Yes' : 'No'}</span>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex-col space-y-2 pt-0">
              {!user?.discordId && (
                <Button className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white gap-2">
                  <SiDiscord className="h-4 w-4" />
                  Connect Discord Account
                </Button>
              )}
              <Button variant="destructive" className="w-full gap-2" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </CardFooter>
          </Card>
          
          {/* Settings Tabs */}
          <div className="w-full md:w-2/3">
            <Tabs defaultValue="account" className="w-full">
              <TabsList className="grid grid-cols-3 mb-6">
                <TabsTrigger value="account" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">Account</span>
                </TabsTrigger>
                <TabsTrigger value="security" className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  <span className="hidden sm:inline">Security</span>
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  <span className="hidden sm:inline">Notifications</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Account Settings */}
              <TabsContent value="account">
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle>Account Settings</CardTitle>
                    <CardDescription>Manage your profile information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input 
                        id="username" 
                        value={formData.username} 
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        value={formData.email} 
                        onChange={handleInputChange}
                        placeholder="Your email address" 
                      />
                      <p className="text-sm text-muted-foreground">Email notifications will be sent to this address</p>
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-medium">Discord Integration</h3>
                        <p className="text-sm text-muted-foreground">Manage your Discord account connection</p>
                      </div>
                      
                      {user?.discordId ? (
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <SiDiscord className="h-5 w-5 text-[#5865F2]" />
                            <div>
                              <p className="text-sm font-medium">Discord Connected</p>
                              <p className="text-xs text-muted-foreground">Your Discord account is linked</p>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">Disconnect</Button>
                        </div>
                      ) : (
                        <div className="bg-slate-900/40 border border-slate-800 rounded-md p-4">
                          <div className="flex items-center gap-3">
                            <SiDiscord className="h-6 w-6 text-[#5865F2]" />
                            <div>
                              <p className="font-medium">Connect Discord Account</p>
                              <p className="text-sm text-muted-foreground">Link your Discord account to unlock premium features</p>
                            </div>
                          </div>
                          <Button className="mt-3 bg-[#5865F2] hover:bg-[#4752C4] text-white">
                            Connect Discord
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleUpdateProfile} disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        'Update Profile'
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              {/* Security Settings */}
              <TabsContent value="security">
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle>Security Settings</CardTitle>
                    <CardDescription>Manage your password and security options</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-medium">Change Password</h3>
                        <p className="text-sm text-muted-foreground">Update your password regularly to keep your account secure</p>
                      </div>
                      
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="current-password">Current Password</Label>
                          <Input 
                            id="current-password" 
                            type="password"
                            value={password.current}
                            onChange={(e) => setPassword({...password, current: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="new-password">New Password</Label>
                          <Input 
                            id="new-password" 
                            type="password"
                            value={password.new}
                            onChange={(e) => setPassword({...password, new: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="confirm-password">Confirm New Password</Label>
                          <Input 
                            id="confirm-password" 
                            type="password"
                            value={password.confirm}
                            onChange={(e) => setPassword({...password, confirm: e.target.value})}
                          />
                        </div>
                      </div>
                      
                      <Button 
                        onClick={handlePasswordChange} 
                        disabled={isUpdating}
                        className="mt-2"
                      >
                        {isUpdating ? (
                          <>
                            <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                            Updating...
                          </>
                        ) : (
                          'Change Password'
                        )}
                      </Button>
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                        <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Two-Factor Authentication</div>
                          <div className="text-sm text-muted-foreground">Require a verification code when logging in</div>
                        </div>
                        <Switch disabled={!hasPremium} />
                      </div>
                      
                      {!hasPremium && (
                        <div className="text-sm text-amber-400 bg-amber-900/20 border border-amber-900/40 rounded p-2">
                          Two-factor authentication requires a Premium subscription
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Notification Settings */}
              <TabsContent value="notifications">
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle>Notification Settings</CardTitle>
                    <CardDescription>Control how and when you receive notifications</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Email Notifications</h3>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Security Alerts</div>
                          <div className="text-sm text-muted-foreground">Receive emails about suspicious login attempts</div>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Product Updates</div>
                          <div className="text-sm text-muted-foreground">Receive emails about new features and updates</div>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Server Reports</div>
                          <div className="text-sm text-muted-foreground">Weekly summary of your servers' activities</div>
                        </div>
                        <Switch />
                      </div>
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Discord Notifications</h3>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Direct Messages</div>
                          <div className="text-sm text-muted-foreground">Allow Guard-shin to send you direct messages on Discord</div>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-medium">Server Events</div>
                          <div className="text-sm text-muted-foreground">Receive Discord notifications about important server events</div>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleUpdateProfile} disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save Preferences'
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        {/* Subscription Section */}
        {!hasPremium && (
          <Card className="bg-gradient-to-br from-primary/5 to-primary/20 border-primary/20">
            <CardHeader>
              <CardTitle>Upgrade to Premium</CardTitle>
              <CardDescription>Unlock premium features and enhance your server protection</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">Advanced Protection</h4>
                    <p className="text-sm text-muted-foreground">Enhanced anti-raid and security features</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Bell className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">Custom Welcome Messages</h4>
                    <p className="text-sm text-muted-foreground">Create personalized welcome experiences</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Lock className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">Two-Factor Authentication</h4>
                    <p className="text-sm text-muted-foreground">Additional security for your account</p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-gradient-to-r from-primary to-primary-foreground hover:opacity-90">
                <CreditCard className="mr-2 h-4 w-4" />
                Upgrade Now
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ProfilePage;