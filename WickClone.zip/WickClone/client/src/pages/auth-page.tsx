import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation, Link } from 'wouter';
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";
import { FaDiscord } from 'react-icons/fa';
import { SiDiscord } from 'react-icons/si';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DevLoginForm from "@/components/DevLoginForm";
import { Shield, ChevronRight, Bot, Lock, BookOpen, CreditCard, MessageSquare, BarChart } from 'lucide-react';
import botImage from "@assets/Gemini_Generated_Image_conf40conf40conf.jpg";

export default function AuthPage() {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  // Check for URL error parameters
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const error = searchParams.get('error');
    if (error) {
      toast({
        title: "Authentication Error",
        description: error,
        variant: "destructive",
      });
    }
  }, [location, toast]);

  const { loginWithDiscord } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Guard-shin</span>
            <span className="text-xs text-muted-foreground ml-2 hidden md:inline-block">witherco.org</span>
          </div>
          <div className="flex items-center gap-4">
            <Button asChild variant="link" size="sm" className="hidden md:inline-flex">
              <a href="https://witherco.org" target="_blank" rel="noopener noreferrer">
                Official Website
              </a>
            </Button>
            <Button asChild variant="default" size="sm">
              <Link href="/login">
                Log In
              </Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link href="/discord-signup">
                Register
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 px-4 bg-gradient-to-b from-background to-background/80">
          <div className="container mx-auto max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-5xl font-bold tracking-tighter">
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
                    Secure Your Discord Server
                  </span>
                </h1>
                <p className="text-xl text-muted-foreground">
                  Guard-shin provides advanced AI-powered moderation, anti-raid protection, and security 
                  tools to keep your Discord community safe.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button asChild size="lg" className="gap-2">
                    <Link href="/discord-signup">
                      Get Started <ChevronRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild size="lg" variant="outline" className="gap-2">
                    <a href="https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands" target="_blank" rel="noopener noreferrer">
                      <SiDiscord className="h-4 w-4 mr-2" />
                      Add to Discord
                    </a>
                  </Button>
                </div>
              </div>
              <div className="relative bg-gradient-to-b from-primary/20 to-primary/5 rounded-lg p-8">
                <div className="absolute inset-0 border border-primary/20 rounded-lg" />
                <div className="p-4 shadow-xl rounded-lg bg-card">
                  <img 
                    src={botImage}
                    alt="Guard-shin Bot" 
                    className="w-32 h-32 mx-auto mb-4 rounded-lg shadow-lg border-2 border-primary/40 object-cover"
                  />
                  <h2 className="text-xl font-bold text-center mb-4">Guard-shin Bot</h2>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Advanced Auto-Moderation</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Bot className="h-4 w-4 text-primary" />
                      <span>24/7 Raid Protection</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Lock className="h-4 w-4 text-primary" />
                      <span>Server Verification System</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MessageSquare className="h-4 w-4 text-primary" />
                      <span>Custom Welcome Messages</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <BarChart className="h-4 w-4 text-primary" />
                      <span>Detailed Analytics & Logs</span>
                    </div>
                  </div>
                  <Separator className="my-4" />
                  <div className="text-center">
                    <Button asChild size="lg" className="w-full gap-2 bg-blue-500 hover:bg-blue-600 text-white">
                      <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer">
                        <SiDiscord className="h-5 w-5 mr-2" />
                        Join Support Server
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 px-4 bg-card/50">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Powerful Discord Protection</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Guard-shin comes with a comprehensive set of features designed to protect 
                and enhance your Discord server experience.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Feature Cards */}
              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Advanced Moderation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    AI-powered auto moderation that detects and acts on inappropriate content, spam, and more.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Bot className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Raid Protection</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Real-time raid detection and prevention systems to protect your server from coordinated attacks.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Lock className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Verification System</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Keep your server secure with customizable verification systems for new members.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Welcome Messages</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Create personalized welcome messages for new members with customizable templates.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <BarChart className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Analytics & Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Detailed server analytics and comprehensive logs for all moderation actions.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-primary/20 bg-card/50 hover:shadow-md transition duration-300">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Documentation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Comprehensive documentation and command list to help you get the most out of Guard-shin.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <Button asChild size="lg">
                <Link href="/login">
                  Start Managing Your Servers
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Pricing/Plans Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Choose Your Plan</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                From free basic protection to premium features, Guard-shin offers flexible plans to meet your server's needs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Free Plan */}
              <Card className="border border-muted/20">
                <CardHeader>
                  <CardTitle>Free</CardTitle>
                  <CardDescription>Basic protection for small servers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold mb-6">$0</div>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Basic Moderation</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Simple Anti-Raid</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Limited Logs</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/discord-signup">
                      Get Started
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              {/* Premium Plan */}
              <Card className="border border-primary/50 relative overflow-hidden shadow-lg">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-primary/60" />
                <div className="absolute -top-1 right-4 bg-primary px-3 py-1 text-xs rounded-b-md font-medium">
                  POPULAR
                </div>
                <CardHeader>
                  <CardTitle>Premium</CardTitle>
                  <CardDescription>Advanced protection for growing communities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold mb-6">$9.99<span className="text-sm font-normal text-muted-foreground">/month</span></div>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Advanced Moderation</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Comprehensive Anti-Raid</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Verification System</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Welcome Messages</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Full Analytics</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" asChild>
                    <Link href="/discord-signup">
                      Upgrade Now
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              {/* Premium+ Plan */}
              <Card className="border border-muted/20">
                <CardHeader>
                  <CardTitle>Premium+</CardTitle>
                  <CardDescription>Ultimate protection for large servers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold mb-6">$19.99<span className="text-sm font-normal text-muted-foreground">/month</span></div>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Everything in Premium</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Custom Bot Voice</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>24/7 Priority Support</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Custom Commands</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Multiple Servers</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/discord-signup">
                      Upgrade Now
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4 bg-primary/5 border-y border-primary/10">
          <div className="container mx-auto max-w-6xl text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to secure your Discord server?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
              Join thousands of server owners who trust Guard-shin for their moderation and security needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/discord-signup">
                  Create an Account
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands" target="_blank" rel="noopener noreferrer">
                  Add to Discord
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between gap-8">
            <div className="space-y-4 max-w-md">
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-primary" />
                <span className="font-bold text-xl">Guard-shin</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Advanced Discord moderation and security bot providing comprehensive protection for your server.
              </p>
              <div className="flex gap-4">
                <Button variant="ghost" size="icon" asChild>
                  <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="h-5 w-5" />
                  </a>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="space-y-4">
                <h3 className="font-medium text-sm">Product</h3>
                <ul className="space-y-2 text-sm">
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/login">Dashboard</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/commands">Commands</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/documentation">Documentation</Link></Button></li>
                </ul>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium text-sm">Company</h3>
                <ul className="space-y-2 text-sm">
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/about">About</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/contact-public">Contact</Link></Button></li>
                </ul>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium text-sm">Legal</h3>
                <ul className="space-y-2 text-sm">
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/terms-of-service">Terms of Service</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/privacy-policy">Privacy Policy</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/refund-policy">Refund Policy</Link></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/guidelines">Guidelines</Link></Button></li>
                </ul>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium text-sm">Support</h3>
                <ul className="space-y-2 text-sm">
                  <li><Button variant="link" asChild className="h-auto p-0"><a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer">Discord Server</a></Button></li>
                  <li><Button variant="link" asChild className="h-auto p-0"><Link href="/contact-public">Contact Support</Link></Button></li>
                </ul>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              © 2025 Guard-shin | <a href="https://witherco.org" className="text-primary hover:underline">witherco.org</a> | All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <a href="https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands" target="_blank" rel="noopener noreferrer">
                  <SiDiscord className="h-4 w-4 mr-2" />
                  Add to Discord
                </a>
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}