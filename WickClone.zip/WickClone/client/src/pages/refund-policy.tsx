import React from 'react';
import { Link } from 'wouter';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ChevronLeft, CreditCard, DollarSign } from 'lucide-react';

export default function RefundPolicyPage() {
  return (
    <div className="container max-w-4xl py-8 px-4 mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild className="gap-2">
          <Link href="/">
            <ChevronLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>
      
      <div className="flex items-center space-x-2 mb-6">
        <CreditCard className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Refund Policy</h1>
      </div>
      
      <div className="bg-card rounded-lg border p-6 shadow-sm">
        <ScrollArea className="h-[60vh]">
          <div className="prose prose-invert max-w-none">
            <p className="text-muted-foreground text-sm mb-4">Last Updated: April 16, 2025</p>
            
            <p>
              Thank you for subscribing to Guard-shin Premium. This Refund Policy outlines the terms and conditions regarding refunds for our services.
            </p>
            
            <h2>1. Refund Eligibility</h2>
            <p>
              We offer refunds under the following circumstances:
            </p>
            <ul>
              <li>Service Unavailability: If Guard-shin Premium services are unavailable for a continuous period exceeding 24 hours due to issues on our end, you may be eligible for a prorated refund for the affected period.</li>
              <li>Billing Errors: If you have been incorrectly charged or double-billed, we will refund the incorrect or duplicate charge.</li>
              <li>Cancellation Within Trial Period: If you cancel during a free trial period, you will not be charged for the subscription.</li>
            </ul>
            
            <h2>2. Non-Refundable Circumstances</h2>
            <p>
              We do not offer refunds in the following cases:
            </p>
            <ul>
              <li>After Subscription Period: Once a subscription period (monthly/annually) has begun, we do not provide refunds for the remainder of that period if you decide to cancel mid-term.</li>
              <li>Feature Dissatisfaction: Refunds are not available if you are simply dissatisfied with the provided features or if the service does not meet your expectations.</li>
              <li>Terms of Service Violations: Accounts terminated due to violations of our Terms of Service are not eligible for refunds.</li>
              <li>Discord Server Removal: If you remove Guard-shin from your Discord server or lose access to your Discord server, this does not qualify for a refund.</li>
            </ul>
            
            <h2>3. Refund Process</h2>
            <p>
              To request a refund:
            </p>
            <ol>
              <li>Contact our support team at <a href="mailto:support@witherco.org" className="text-primary hover:underline">support@witherco.org</a> with your Discord username and transaction ID.</li>
              <li>Clearly state the reason for your refund request.</li>
              <li>Our team will review your request within 5 business days.</li>
              <li>If approved, refunds will be processed to the original payment method used for the purchase.</li>
              <li>Processing time for refunds may vary depending on your payment provider (typically 5-10 business days).</li>
            </ol>
            
            <h2>4. Payment Methods and Refund Processing</h2>
            <p>
              Refunds will be issued to the original payment method:
            </p>
            <ul>
              <li>PayPal: Refunds typically process within 5-7 business days.</li>
              <li>CashApp: Refunds typically process within 3-10 business days.</li>
              <li>Credit/Debit Cards: Refunds typically process within 5-10 business days, depending on your card issuer.</li>
            </ul>
            
            <h2>5. Subscription Cancellation</h2>
            <p>
              Cancelling your subscription:
            </p>
            <ul>
              <li>Does not automatically entitle you to a refund.</li>
              <li>Will stop future billing at the end of your current billing period.</li>
              <li>Allows you to continue using premium features until the end of your current billing period.</li>
            </ul>
            <p>
              To cancel your subscription, log in to your account dashboard and select "Manage Subscription."
            </p>
            
            <h2>6. Special Circumstances</h2>
            <p>
              In exceptional cases not covered by this policy, we may consider refund requests at our discretion. These will be evaluated on a case-by-case basis.
            </p>
            
            <h2>7. Changes to This Policy</h2>
            <p>
              We reserve the right to modify this Refund Policy at any time. Changes will be effective immediately upon posting to our website. Your continued use of Guard-shin Premium services after any changes to the Refund Policy constitutes your acceptance of such changes.
            </p>
            
            <h2>8. Contact Information</h2>
            <p>
              If you have questions about our Refund Policy or need assistance with a refund request, please contact our support team:
            </p>
            <ul>
              <li>Email: <a href="mailto:support@witherco.org" className="text-primary hover:underline">support@witherco.org</a></li>
              <li>Discord Support Server: <a href="https://discord.gg/g3rFbaW6gw" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">https://discord.gg/g3rFbaW6gw</a></li>
            </ul>
            
            <p className="mt-6">
              Thank you for choosing Guard-shin Premium services. We appreciate your business and are committed to providing excellent Discord security and moderation tools for your community.
            </p>
          </div>
        </ScrollArea>
      </div>
      
      <div className="mt-6 text-center text-sm text-muted-foreground">
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/terms-of-service" className="text-primary hover:underline">
            Terms of Service
          </Link>
          <Link href="/privacy-policy" className="text-primary hover:underline">
            Privacy Policy
          </Link>
          <Link href="/refund-policy" className="text-primary hover:underline">
            Refund Policy
          </Link>
          <Link href="/guidelines" className="text-primary hover:underline">
            Community Guidelines
          </Link>
        </div>
      </div>
    </div>
  );
}