import React, { useState } from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useToast } from '@/hooks/use-toast';
import { usePremiumStatus } from '@/hooks/use-discord';
import { SiDiscord } from 'react-icons/si';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  BookOpen,
  FileText,
  Shield,
  Users,
  Settings,
  Zap,
  Search,
  ChevronRight,
  ChevronDown,
  PlusCircle,
  MinusCircle,
  ExternalLink,
  Code,
  Server,
  HelpCircle,
  MessageSquare,
  BellRing,
  Bot,
  DatabaseIcon,
  Key,
  Award,
  Copy
} from 'lucide-react';

interface DocSection {
  id: string;
  title: string;
  icon: React.ReactNode;
  content: React.ReactNode;
}

interface DocCategory {
  id: string;
  title: string;
  icon: React.ReactNode;
  sections: DocSection[];
}

const DocAccordion: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border border-gray-800 rounded-lg overflow-hidden">
      <div 
        className="flex justify-between items-center p-4 bg-gray-900/50 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-lg font-medium text-white">{title}</h3>
        <div>
          {isOpen ? (
            <MinusCircle className="h-5 w-5 text-gray-400" />
          ) : (
            <PlusCircle className="h-5 w-5 text-gray-400" />
          )}
        </div>
      </div>
      {isOpen && (
        <div className="p-4 bg-gray-900/20 border-t border-gray-800">
          {children}
        </div>
      )}
    </div>
  );
};

const CodeBlock: React.FC<{ code: string; language?: string }> = ({ code, language = 'bash' }) => {
  const { toast } = useToast();
  
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Code copied!",
      description: "The code has been copied to your clipboard.",
    });
  };
  
  return (
    <div className="relative mt-2 mb-4 rounded-md overflow-hidden">
      <div className="flex items-center justify-between bg-gray-900 py-1.5 px-4">
        <div className="text-xs text-gray-400">{language}</div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-7 w-7 p-0 rounded-full"
          onClick={handleCopy}
        >
          <Copy className="h-4 w-4 text-gray-400 hover:text-white transition-colors" />
        </Button>
      </div>
      <pre className="p-4 bg-discord-dark overflow-x-auto">
        <code className="text-sm text-gray-300 font-mono">{code}</code>
      </pre>
    </div>
  );
};

const Documentation: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('getting-started');
  const { isPremium } = usePremiumStatus();
  
  const docCategories: DocCategory[] = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <BookOpen className="h-5 w-5" />,
      sections: [
        {
          id: 'introduction',
          title: 'Introduction',
          icon: <FileText className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Guard-shin is an advanced Discord moderation and security bot designed to protect your server 
                from raids, spam, and other unwanted behavior while providing powerful tools for server management.
              </p>
              <h3 className="text-lg font-bold text-white mt-4">Key Features:</h3>
              <ul className="space-y-2 text-gray-300 pl-6 list-disc">
                <li>Advanced auto-moderation with customizable filters</li>
                <li>Raid protection with automatic detection and prevention</li>
                <li>Comprehensive moderation commands (ban, kick, mute, warn)</li>
                <li>Welcome messages and automated role assignment</li>
                <li>Verification system to prevent spam accounts</li>
                <li>Detailed logging of all server activities</li>
                <li>Music playback and other fun commands</li>
                <li>Premium features for enhanced server protection</li>
              </ul>
            </div>
          )
        },
        {
          id: 'installation',
          title: 'Adding to Your Server',
          icon: <PlusCircle className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Adding Guard-shin to your Discord server is quick and easy. Follow these steps to get started:
              </p>
              <ol className="space-y-2 text-gray-300 pl-6 list-decimal">
                <li>
                  <span className="font-medium text-white">Invite the bot</span> - Click the invite button 
                  below or use the following link to add Guard-shin to your server.
                </li>
                <li>
                  <span className="font-medium text-white">Authorize the bot</span> - Select your server from 
                  the dropdown menu and click "Authorize" to give Guard-shin the necessary permissions.
                </li>
                <li>
                  <span className="font-medium text-white">Configure permissions</span> - Ensure Guard-shin has 
                  the proper role hierarchy (above users it needs to moderate) and channel permissions.
                </li>
                <li>
                  <span className="font-medium text-white">Initial setup</span> - Use the <code className="px-1.5 py-0.5 rounded bg-gray-800 text-xs text-blue-400 font-mono">/setup</code> command 
                  to configure basic settings or use this dashboard for more advanced configuration.
                </li>
              </ol>
              
              <div className="flex justify-center mt-6">
                <Button 
                  className="bg-[#5865F2] hover:bg-[#4752C4] text-white"
                  onClick={() => window.open('https://discord.com/oauth2/authorize?client_id=1361873604882731008&scope=bot%20applications.commands&permissions=8', '_blank')}
                >
                  <Bot className="mr-2 h-4 w-4" />
                  Invite Guard-shin to Your Server
                </Button>
              </div>
              
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mt-6">
                <div className="flex items-start">
                  <HelpCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Recommended Permissions</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      For optimal functionality, Guard-shin needs specific permissions such as 
                      <span className="font-medium"> Manage Server</span>,
                      <span className="font-medium"> Kick Members</span>,
                      <span className="font-medium"> Ban Members</span>,
                      <span className="font-medium"> Manage Messages</span>,
                      <span className="font-medium"> View Channels</span>, and
                      <span className="font-medium"> Send Messages</span>.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        },
        {
          id: 'quick-setup',
          title: 'Quick Setup Guide',
          icon: <Zap className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Once Guard-shin is added to your server, follow these steps to quickly set up the essential features:
              </p>
              
              <DocAccordion title="1. Basic Configuration">
                <div className="space-y-2 text-gray-300">
                  <p>To set up basic configuration, use the setup command:</p>
                  <CodeBlock code="/setup" />
                  <p>This interactive command will guide you through setting up:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Prefix for text commands (default is !)</li>
                    <li>Moderation logging channel</li>
                    <li>Server logs channel</li>
                    <li>Moderator and admin roles</li>
                    <li>Basic auto-moderation settings</li>
                  </ul>
                </div>
              </DocAccordion>
              
              <DocAccordion title="2. Moderation System">
                <div className="space-y-2 text-gray-300">
                  <p>Configure the moderation system with the following commands:</p>
                  <CodeBlock code="/config modrole @ModeratorRole" />
                  <CodeBlock code="/config adminrole @AdminRole" />
                  <CodeBlock code="/config muterole @MutedRole" />
                  <p>If you don't have a mute role yet, Guard-shin can create one for you:</p>
                  <CodeBlock code="/createmuterole" />
                </div>
              </DocAccordion>
              
              <DocAccordion title="3. Auto-Moderation">
                <div className="space-y-2 text-gray-300">
                  <p>Setup auto-moderation to automatically filter unwanted content:</p>
                  <CodeBlock code="/automod setup" />
                  <p>Or configure specific features:</p>
                  <CodeBlock code="/automod antispam enable 5 3" />
                  <p className="text-sm text-gray-400">(This enables anti-spam with a threshold of 5 messages within 3 seconds)</p>
                  <CodeBlock code="/automod profanity enable" />
                  <CodeBlock code="/automod invites disable" />
                </div>
              </DocAccordion>
              
              <DocAccordion title="4. Logging">
                <div className="space-y-2 text-gray-300">
                  <p>Set up logging channels to monitor server activity:</p>
                  <CodeBlock code="/log mod #mod-logs" />
                  <CodeBlock code="/log server #server-logs" />
                  <p>Configure what events to log:</p>
                  <CodeBlock code="/log config message-delete enable" />
                  <CodeBlock code="/log config message-edit enable" />
                  <CodeBlock code="/log config member-join enable" />
                </div>
              </DocAccordion>
              
              <DocAccordion title="5. Welcome Messages">
                <div className="space-y-2 text-gray-300">
                  <p>Set up welcome messages for new members:</p>
                  <CodeBlock code="/welcome set-channel #welcome" />
                  <CodeBlock code="/welcome set-message Welcome {user} to {server}! Please read our rules in <#CHANNEL_ID>." />
                  <CodeBlock code="/welcome toggle" />
                  <p>Test your welcome message:</p>
                  <CodeBlock code="/welcome test" />
                </div>
              </DocAccordion>
              
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mt-6">
                <div className="flex items-start">
                  <Server className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Need More Help?</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      For more detailed setup instructions and advanced configuration, join our 
                      <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline ml-1">support server</a> 
                      or continue exploring this documentation.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        },
        {
          id: 'dashboard-guide',
          title: 'Dashboard Guide',
          icon: <Settings className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                The Guard-shin dashboard provides an intuitive web interface for configuring all aspects of the bot. 
                Here's how to use the dashboard effectively:
              </p>
              
              <h3 className="text-lg font-bold text-white mt-4">Dashboard Sections:</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Server Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      View server statistics, member count, and recent activities. Monitor server health and bot status.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Auto-Moderation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      Configure filters for profanity, spam, excessive mentions, scam links, and other unwanted content.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Raid Protection</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      Set up automatic raid detection and response. Configure verification levels and member screening.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Infractions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      View and manage all moderation actions including warnings, mutes, kicks, and bans.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Welcome Messages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      Customize welcome messages and configure auto-role assignment for new members.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-gray-800 bg-gray-900/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Logs</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">
                      Browse detailed server logs, filter by event type, and export logs for record-keeping.
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-4">
                <h3 className="text-lg font-bold text-white">Premium Dashboard Features:</h3>
                <div className="mt-2 rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-4">
                  <div className="flex items-start">
                    <Award className="h-5 w-5 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                    <div>
                      <p className="text-gray-300">
                        Premium subscribers gain access to additional dashboard features:
                      </p>
                      <ul className="mt-2 space-y-1 text-gray-400 pl-6 list-disc">
                        <li>Advanced analytics with detailed server statistics</li>
                        <li>Extended log retention (90 days vs. 7 days)</li>
                        <li>Custom role menus and reaction roles</li>
                        <li>Advanced auto-moderation with AI-powered content filtering</li>
                        <li>Customizable embed welcome messages</li>
                        <li>Scheduled announcements and reminders</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )
        }
      ]
    },
    {
      id: 'moderation',
      title: 'Moderation Tools',
      icon: <Shield className="h-5 w-5" />,
      sections: [
        {
          id: 'mod-commands',
          title: 'Moderation Commands',
          icon: <MessageSquare className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Guard-shin provides a comprehensive set of moderation commands to help you manage your server effectively.
                Here are the essential moderation commands you should know:
              </p>
              
              <div className="grid grid-cols-1 gap-4 mt-4">
                <DocAccordion title="User Moderation Commands">
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-white font-medium">Ban Command</h4>
                      <CodeBlock code="/ban @user [reason] [delete_days]" />
                      <p className="text-sm text-gray-400">
                        Permanently bans a user from the server. The optional delete_days parameter (0-7) 
                        determines how many days of messages to delete.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Kick Command</h4>
                      <CodeBlock code="/kick @user [reason]" />
                      <p className="text-sm text-gray-400">
                        Kicks a user from the server. They can rejoin with a new invite.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Mute/Timeout Command</h4>
                      <CodeBlock code="/mute @user [duration] [reason]" />
                      <p className="text-sm text-gray-400">
                        Temporarily mutes a user for the specified duration. Default is 10 minutes if no duration is specified.
                        Duration can be specified as 5m (5 minutes), 2h (2 hours), 1d (1 day), etc.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Warn Command</h4>
                      <CodeBlock code="/warn @user [reason]" />
                      <p className="text-sm text-gray-400">
                        Issues a formal warning to a user. Warnings are tracked in the infractions database.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Infractions Command</h4>
                      <CodeBlock code="/infractions @user" />
                      <p className="text-sm text-gray-400">
                        Shows all infractions (warnings, mutes, kicks, bans) for a specific user.
                      </p>
                    </div>
                  </div>
                </DocAccordion>
                
                <DocAccordion title="Channel Moderation Commands">
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-white font-medium">Clear/Purge Command</h4>
                      <CodeBlock code="/clear [number] [@user]" />
                      <p className="text-sm text-gray-400">
                        Deletes a specified number of messages from the current channel. Optionally filter to only delete messages from a specific user.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Slowmode Command</h4>
                      <CodeBlock code="/slowmode [seconds]" />
                      <p className="text-sm text-gray-400">
                        Sets the slowmode delay for the current channel. Users will be limited to one message per specified seconds.
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Lockdown Command</h4>
                      <CodeBlock code="/lockdown [reason]" />
                      <p className="text-sm text-gray-400">
                        Locks the current channel, preventing regular users from sending messages. 
                        This is useful during raids or when you need to make important announcements.
                      </p>
                      <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium</Badge>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Unlock Command</h4>
                      <CodeBlock code="/unlock" />
                      <p className="text-sm text-gray-400">
                        Removes a lockdown from the current channel, allowing users to send messages again.
                      </p>
                      <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium</Badge>
                    </div>
                  </div>
                </DocAccordion>
                
                <DocAccordion title="Server-wide Moderation Commands">
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-white font-medium">Server Lockdown Command</h4>
                      <CodeBlock code="/serverlockdown [reason]" />
                      <p className="text-sm text-gray-400">
                        Locks down the entire server, preventing members from sending messages in all channels.
                        Extremely useful during major raids or emergencies.
                      </p>
                      <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium</Badge>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Server Unlock Command</h4>
                      <CodeBlock code="/serverunlock" />
                      <p className="text-sm text-gray-400">
                        Removes the server-wide lockdown, restoring normal access to all channels.
                      </p>
                      <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium</Badge>
                    </div>
                    
                    <div>
                      <h4 className="text-white font-medium">Raid Mode Command</h4>
                      <CodeBlock code="/raidmode [on/off]" />
                      <p className="text-sm text-gray-400">
                        Activates or deactivates raid mode, which implements stricter verification for new members
                        and can automatically kick suspicious accounts.
                      </p>
                      <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium</Badge>
                    </div>
                  </div>
                </DocAccordion>
              </div>
              
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mt-6">
                <div className="flex items-start">
                  <Key className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Required Permissions</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      To use moderation commands, both you and the bot need the appropriate permissions. 
                      Ensure Guard-shin's role is higher in the hierarchy than the roles of users it needs to moderate.
                      Users must have the corresponding permission for each command (e.g., Ban Members permission for the ban command).
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        },
        {
          id: 'auto-moderation',
          title: 'Auto-Moderation',
          icon: <Shield className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Guard-shin's auto-moderation system automatically detects and takes action against rule violations without moderator intervention.
                This helps maintain your server's quality even when moderators are offline.
              </p>
              
              <h3 className="text-lg font-bold text-white mt-4">Auto-Moderation Features:</h3>
              
              <DocAccordion title="Anti-Spam Protection">
                <div className="space-y-2 text-gray-300">
                  <p>Automatically detects and prevents spam messages:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Message rate limiting (configurable threshold)</li>
                    <li>Duplicate message detection</li>
                    <li>Excessive emoji/mention spam</li>
                    <li>Character/line spam</li>
                  </ul>
                  <p className="mt-3">Configure via command:</p>
                  <CodeBlock code="/automod antispam enable [messages] [seconds]" />
                  <p className="text-sm text-gray-400">Example: <code>/automod antispam enable 5 3</code> will trigger on 5+ messages in 3 seconds</p>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Profanity Filter">
                <div className="space-y-2 text-gray-300">
                  <p>Detects and removes messages containing profanity or offensive language:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Built-in word list of common profanity</li>
                    <li>Custom word list that you can edit</li>
                    <li>Bypass permissions for specific roles</li>
                    <li>Channel-specific exceptions</li>
                  </ul>
                  <p className="mt-3">Configure via commands:</p>
                  <CodeBlock code="/automod profanity enable" />
                  <CodeBlock code="/automod profanity word add [word]" />
                  <CodeBlock code="/automod profanity word remove [word]" />
                </div>
              </DocAccordion>
              
              <DocAccordion title="Link Filtering">
                <div className="space-y-2 text-gray-300">
                  <p>Controls what links can be posted in your server:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Block all links or only specific domains</li>
                    <li>Whitelist allowed domains</li>
                    <li>IP address/URL shortener detection</li>
                    <li>Phishing link detection (Premium)</li>
                  </ul>
                  <p className="mt-3">Configure via commands:</p>
                  <CodeBlock code="/automod links enable" />
                  <CodeBlock code="/automod links whitelist add [domain]" />
                  <CodeBlock code="/automod links whitelist remove [domain]" />
                </div>
              </DocAccordion>
              
              <DocAccordion title="Media Scanning">
                <div className="space-y-2 text-gray-300">
                  <p>Analyzes uploaded images and videos:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>NSFW content detection</li>
                    <li>Harmful media detection</li>
                    <li>File size limits</li>
                    <li>Advanced AI scanning (Premium)</li>
                  </ul>
                  <p className="mt-3">Configure via command:</p>
                  <CodeBlock code="/automod media enable" />
                  <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Premium Feature</Badge>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Automated Actions">
                <div className="space-y-2 text-gray-300">
                  <p>Configure actions to take when violations are detected:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Delete the offending message</li>
                    <li>Warn the user</li>
                    <li>Timeout/mute the user</li>
                    <li>Kick or ban for repeated offenses</li>
                    <li>Log the incident to mod-logs</li>
                    <li>Send alerts to moderators</li>
                  </ul>
                  <p className="mt-3">Configure via command:</p>
                  <CodeBlock code="/automod action [violation_type] [action] [duration]" />
                  <p className="text-sm text-gray-400">Example: <code>/automod action spam timeout 10m</code> will timeout users for 10 minutes when they spam</p>
                </div>
              </DocAccordion>
              
              <div className="rounded-lg bg-gray-900/50 p-4 border border-gray-800 mt-6">
                <div className="flex items-start">
                  <DatabaseIcon className="h-5 w-5 text-primary mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Auto-Moderation Dashboard</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      For a more user-friendly way to configure auto-moderation, use the Auto-Moderation section in the 
                      Guard-shin dashboard. The dashboard provides visual toggles, sliders, and input fields to customize 
                      all aspects of your auto-moderation setup.
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2 border-primary/30 text-primary hover:bg-primary/10"
                      onClick={() => window.location.href = '/auto-moderation'}
                    >
                      <Shield className="mr-2 h-4 w-4" />
                      Open Auto-Moderation Dashboard
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )
        },
        {
          id: 'raid-protection',
          title: 'Raid Protection',
          icon: <Shield className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Guard-shin's raid protection system is designed to detect and mitigate server raids automatically.
                It monitors for suspicious activity patterns and takes action to protect your server.
              </p>
              
              <h3 className="text-lg font-bold text-white mt-4">Raid Protection Features:</h3>
              
              <DocAccordion title="Join Rate Monitoring">
                <div className="space-y-2 text-gray-300">
                  <p>Detects unusual spikes in new members joining:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Configurable thresholds for join rates</li>
                    <li>Time window customization</li>
                    <li>Suspicious account detection</li>
                    <li>Coordinated join detection</li>
                  </ul>
                  <p className="mt-3">Configure via command:</p>
                  <CodeBlock code="/raidprotection joinrate [number] [seconds]" />
                  <p className="text-sm text-gray-400">Example: <code>/raidprotection joinrate 10 30</code> will trigger raid detection if 10+ users join in 30 seconds</p>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Account Screening">
                <div className="space-y-2 text-gray-300">
                  <p>Analyzes accounts for signs of being raid participants or spam accounts:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Account age verification</li>
                    <li>Profile picture detection</li>
                    <li>Username pattern recognition</li>
                    <li>AI-powered screening (Premium)</li>
                  </ul>
                  <p className="mt-3">Configure via command:</p>
                  <CodeBlock code="/raidprotection accountage [days]" />
                  <p className="text-sm text-gray-400">Example: <code>/raidprotection accountage 7</code> will flag accounts younger than 7 days</p>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Auto-Response Actions">
                <div className="space-y-2 text-gray-300">
                  <p>Configure automatic responses to detected raids:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Server lockdown</li>
                    <li>Verification level increase</li>
                    <li>Bulk kick of suspicious accounts</li>
                    <li>Auto-mute of new members</li>
                    <li>Alert moderators and administrators</li>
                  </ul>
                  <p className="mt-3">Configure via commands:</p>
                  <CodeBlock code="/raidprotection action [lockdown/kick/mute/notify]" />
                  <p className="text-sm text-gray-400">Example: <code>/raidprotection action lockdown</code> to enable auto-lockdown during raids</p>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Verification System">
                <div className="space-y-2 text-gray-300">
                  <p>Require verification before new members can access the server:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Captcha verification</li>
                    <li>Role-based access control</li>
                    <li>Custom verification messages</li>
                    <li>Verification through reactions or buttons</li>
                  </ul>
                  <p className="mt-3">Configure via commands:</p>
                  <CodeBlock code="/verification setup" />
                  <CodeBlock code="/verification role @VerifiedRole" />
                  <CodeBlock code="/verification channel #verification-channel" />
                  <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Advanced Options with Premium</Badge>
                </div>
              </DocAccordion>
              
              <DocAccordion title="Manual Raid Mode">
                <div className="space-y-2 text-gray-300">
                  <p>Manually activate raid protection when needed:</p>
                  <CodeBlock code="/raidmode on" />
                  <p>This command activates the following protections:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Increases server verification level</li>
                    <li>Enables strict auto-moderation</li>
                    <li>Applies join rate limitations</li>
                    <li>Restricts permissions for new members</li>
                  </ul>
                  <p>To disable raid mode:</p>
                  <CodeBlock code="/raidmode off" />
                </div>
              </DocAccordion>
              
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mt-6">
                <div className="flex items-start">
                  <Award className="h-5 w-5 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Premium Raid Protection</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      Premium subscribers gain access to enhanced raid protection features:
                    </p>
                    <ul className="mt-2 space-y-1 text-gray-400 pl-6 list-disc">
                      <li>Machine learning-based raid detection with 99% accuracy</li>
                      <li>Predictive raid analysis that can detect raids before they fully happen</li>
                      <li>Automated IP range blocking for coordinated attacks</li>
                      <li>24/7 raid monitoring with instant alerts to your phone</li>
                      <li>Detailed forensic analysis of raid participants</li>
                      <li>Advanced verification methods including email and phone verification</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )
        }
      ]
    },
    {
      id: 'premium',
      title: 'Premium Features',
      icon: <Award className="h-5 w-5" />,
      sections: [
        {
          id: 'premium-benefits',
          title: 'Premium Benefits',
          icon: <Award className="h-4 w-4" />,
          content: (
            <div className="space-y-4">
              <p className="text-gray-300">
                Upgrade to Guard-shin Premium to unlock advanced features designed for growing communities and servers
                with high security needs.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <Card className="border-yellow-500/20 bg-yellow-500/5">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <Shield className="h-4 w-4 mr-2 text-yellow-500" />
                      Enhanced Security
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                      <li>AI-powered raid detection and prevention</li>
                      <li>Automatic phishing link detection</li>
                      <li>NSFW and harmful content scanning</li>
                      <li>Advanced verification methods</li>
                      <li>Server-wide lockdown capabilities</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="border-yellow-500/20 bg-yellow-500/5">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <MessageSquare className="h-4 w-4 mr-2 text-yellow-500" />
                      Advanced Customization
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                      <li>Custom welcome embeds with images</li>
                      <li>Role reaction menus and dropdown roles</li>
                      <li>Advanced auto-response system</li>
                      <li>Custom slash commands for your server</li>
                      <li>Scheduled announcements and events</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="border-yellow-500/20 bg-yellow-500/5">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <BellRing className="h-4 w-4 mr-2 text-yellow-500" />
                      Exclusive Features
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                      <li>Music playback in voice channels</li>
                      <li>Advanced poll and giveaway system</li>
                      <li>Temporary voice channels</li>
                      <li>Starboard for highlighting great messages</li>
                      <li>Server backups and configuration exports</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="border-yellow-500/20 bg-yellow-500/5">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <DatabaseIcon className="h-4 w-4 mr-2 text-yellow-500" />
                      Priority Support & Storage
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1">
                      <li>90-day log retention (vs 7 days for free)</li>
                      <li>Priority support with 12-hour response time</li>
                      <li>Detailed analytics and reporting</li>
                      <li>Higher rate limits for commands</li>
                      <li>Early access to new features</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <h3 className="text-lg font-bold text-white mt-6">Premium Tiers</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <Card className="border-primary/20 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="text-xl">Premium</CardTitle>
                    <div className="flex items-baseline">
                      <span className="text-3xl font-bold text-white">$5</span>
                      <span className="text-sm text-gray-400 ml-2">per month</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-white mb-2">What's Included:</h4>
                      <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1.5">
                        <li>All basic moderation features</li>
                        <li>Music commands</li>
                        <li>Advanced auto-moderation</li>
                        <li>Raid protection system</li>
                        <li>Custom welcome messages</li>
                        <li>30-day log retention</li>
                        <li>Support within 24 hours</li>
                      </ul>
                    </div>
                    <Button 
                      className="w-full bg-primary"
                      onClick={() => window.open('/premium/subscribe?tier=premium', '_blank')}
                    >
                      Subscribe to Premium
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="border-yellow-500/30 bg-yellow-500/10">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">Premium+</CardTitle>
                      <Badge className="bg-yellow-500/20 text-yellow-500">Recommended</Badge>
                    </div>
                    <div className="flex items-baseline">
                      <span className="text-3xl font-bold text-white">$10</span>
                      <span className="text-sm text-gray-400 ml-2">per month</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-white mb-2">Everything in Premium, plus:</h4>
                      <ul className="text-sm text-gray-400 list-disc pl-5 space-y-1.5">
                        <li>AI-powered content moderation</li>
                        <li>Advanced verification methods</li>
                        <li>Server backups</li>
                        <li>Custom command creation</li>
                        <li>Advanced analytics dashboard</li>
                        <li>90-day log retention</li>
                        <li>Priority support within 12 hours</li>
                        <li>Early access to new features</li>
                      </ul>
                    </div>
                    <Button 
                      className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400"
                      onClick={() => window.open('/premium/subscribe?tier=premium_plus', '_blank')}
                    >
                      Subscribe to Premium+
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              <div className="rounded-lg bg-blue-500/10 p-4 border border-blue-500/20 mt-6">
                <div className="flex items-start">
                  <HelpCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-white">Payment & Verification</h4>
                    <p className="text-sm text-gray-400 mt-1">
                      We offer secure payment options through PayPal and CashApp. After payment, you'll need to verify your 
                      Discord account to receive your premium role. Visit our 
                      <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline ml-1">support server</a>
                      for assistance with premium subscription issues.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        }
      ]
    }
  ];
  
  // Filter sections based on search query
  const filteredCategories = docCategories.map(category => {
    const filteredSections = category.sections.filter(section => {
      const lowerSearch = searchQuery.toLowerCase();
      return !searchQuery || 
        section.title.toLowerCase().includes(lowerSearch) ||
        category.title.toLowerCase().includes(lowerSearch);
    });
    
    return {
      ...category,
      sections: filteredSections
    };
  }).filter(category => category.sections.length > 0);
  
  // Get the current category
  const currentCategory = filteredCategories.find(cat => cat.id === selectedCategory) || filteredCategories[0];
  
  return (
    <DashboardLayout title="Documentation">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Documentation</h1>
            <p className="text-gray-400 mt-1">Complete guide to using Guard-shin for your Discord server</p>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-64 shrink-0 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search documentation..."
                className="bg-discord-dark border-gray-700 pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="space-y-1">
              {filteredCategories.map(category => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "secondary" : "ghost"}
                  className={`w-full justify-start ${selectedCategory === category.id ? 'bg-primary/20 text-primary' : 'text-gray-300'}`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <div className="mr-2">
                    {category.icon}
                  </div>
                  <span>{category.title}</span>
                </Button>
              ))}
            </div>
            
            <Card className="border-yellow-500/30 bg-yellow-500/10 mt-6">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-3 mb-2">
                  <Award className="h-5 w-5 text-yellow-500" />
                  <h3 className="font-medium text-white">Premium Support</h3>
                </div>
                <p className="text-sm text-gray-300">
                  Need more help? Premium subscribers get priority support and access to additional documentation.
                </p>
                <Button 
                  className="w-full mt-4 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400"
                  size="sm"
                  onClick={() => window.location.href = '/premium/subscribe'}
                >
                  Upgrade to Premium
                </Button>
              </CardContent>
            </Card>
            
            <div className="rounded-lg p-4 bg-gray-900/50 border border-gray-800">
              <div className="flex items-center space-x-3 mb-2">
                <HelpCircle className="h-5 w-5 text-blue-500" />
                <h3 className="font-medium text-white">Need Help?</h3>
              </div>
              <p className="text-sm text-gray-400">
                Join our support server for direct assistance from our team and community.
              </p>
              <Button 
                className="w-full mt-4 bg-blue-500 hover:bg-blue-600 text-white"
                size="lg"
                onClick={() => window.open('https://discord.gg/g3rFbaW6gw', '_blank')}
              >
                <SiDiscord className="mr-2 h-5 w-5" />
                Join Support Server
              </Button>
            </div>
          </div>
          
          {/* Main content */}
          <div className="flex-1">
            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  {currentCategory?.icon}
                  <CardTitle>{currentCategory?.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {/* Tab navigation for sections */}
                <Tabs 
                  value={currentCategory?.sections[0]?.id || ''}
                  className="w-full"
                >
                  <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-6">
                    {currentCategory?.sections.map(section => (
                      <TabsTrigger key={section.id} value={section.id} className="flex items-center gap-2">
                        <span className="hidden md:inline-block">{section.icon}</span>
                        <span>{section.title}</span>
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  
                  {currentCategory?.sections.map(section => (
                    <TabsContent key={section.id} value={section.id} className="space-y-4">
                      {section.content}
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Documentation;