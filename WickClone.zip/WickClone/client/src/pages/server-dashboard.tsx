import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { DataLoader } from '@/components/data-loader';
import { LoadingPage } from '@/components/loading-page';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { SecurityLoader } from '@/components/ui/security-loader';

// Import Discord components
import DiscordServerList from '@/components/discord/DiscordServerList';
import DiscordChannelList from '@/components/discord/DiscordChannelList';
import ServerOverview from '@/components/discord/ServerOverview';
import MemberManagement from '@/components/discord/MemberManagement';

// Import icons
import { 
  LayoutDashboard,
  Shield,
  AlertTriangle,
  Users,
  MessageSquare,
  Settings,
  Bot,
  Activity,
  Home,
  ArrowLeft
} from 'lucide-react';

// Interface for server data
interface Server {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number | null;
  ownerId: string;
  joinedAt: Date | null;
  premium: boolean | null;
  premiumTier: string | null;
  premiumExpiresAt: Date | null;
  lastTransactionId: string | null;
}

export default function ServerDashboard() {
  const params = useParams();
  const serverId = params.serverId || '';
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch server details
  const { data: server, isLoading, isError, error } = useQuery<Server>({
    queryKey: [`/api/servers/${serverId}`],
    enabled: !!serverId,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Handle back to server list
  const handleBackToServerList = () => {
    setLocation('/dashboard');
  };

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  // If no server ID is provided, show the server list
  if (!serverId) {
    return (
      <div className="container py-6 space-y-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Discord Servers</h1>
          <Button variant="outline" onClick={() => setLocation('/dashboard')}>
            <Home className="mr-2 h-4 w-4" />
            Dashboard Home
          </Button>
        </div>
        <Separator />
        <DiscordServerList />
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" onClick={handleBackToServerList}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Servers
        </Button>
      </div>

      <DataLoader
        isLoading={isLoading}
        isError={isError}
        error={error as Error}
        loadingText="Loading server details..."
        errorText="Failed to load server information"
      >
        {server ? (
          <div className="space-y-6">
            <ServerOverview serverId={serverId} />
            
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="grid w-full grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <LayoutDashboard className="h-4 w-4" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="members" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span className="hidden sm:inline">Members</span>
                </TabsTrigger>
                <TabsTrigger value="channels" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  <span className="hidden sm:inline">Channels</span>
                </TabsTrigger>
                <TabsTrigger value="moderation" className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  <span className="hidden sm:inline">Moderation</span>
                </TabsTrigger>
                <TabsTrigger value="automod" className="flex items-center gap-2">
                  <Bot className="h-4 w-4" />
                  <span className="hidden sm:inline">Auto-Mod</span>
                </TabsTrigger>
                <TabsTrigger value="raid-protection" className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="hidden sm:inline">Raid</span>
                </TabsTrigger>
                <TabsTrigger value="logs" className="flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  <span className="hidden sm:inline">Logs</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Settings</span>
                </TabsTrigger>
              </TabsList>
              
              <div className="mt-6">
                <TabsContent value="overview" className="w-full">
                  <div className="grid gap-6 md:grid-cols-3">
                    <div className="md:col-span-2">
                      <Card className="h-full p-6">
                        <h2 className="text-xl font-semibold mb-4">Server Activity</h2>
                        <p className="text-muted-foreground">
                          Server activity statistics will be displayed here. This includes message count, command usage, moderation actions, and member join/leave events.
                        </p>
                        <div className="flex justify-center items-center h-[300px]">
                          <SecurityLoader type="scanning" text="Collecting activity data..." />
                        </div>
                      </Card>
                    </div>
                    <div>
                      <DiscordChannelList serverId={serverId} />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="members">
                  <MemberManagement serverId={serverId} />
                </TabsContent>
                
                <TabsContent value="channels">
                  <div className="grid gap-6 md:grid-cols-2">
                    <DiscordChannelList serverId={serverId} />
                    <Card className="h-full p-6">
                      <h2 className="text-xl font-semibold mb-4">Channel Management</h2>
                      <p className="text-muted-foreground">
                        Select a channel from the list to manage its settings, permissions, and more.
                      </p>
                      <div className="flex justify-center items-center h-[300px]">
                        <SecurityLoader type="shield" text="Select a channel to manage" />
                      </div>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="moderation">
                  <Card className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Moderation Tools</h2>
                    <p className="text-muted-foreground mb-6">
                      Moderation features will be displayed here. This includes user infractions, ban management, mute controls, and more.
                    </p>
                    <div className="flex justify-center items-center h-[300px]">
                      <SecurityLoader type="shield" text="Loading moderation tools..." />
                    </div>
                  </Card>
                </TabsContent>
                
                <TabsContent value="automod">
                  <Card className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Auto-Moderation</h2>
                    <p className="text-muted-foreground mb-6">
                      Auto-moderation settings will be displayed here. This includes profanity filters, spam detection, invite link blocking, and more.
                    </p>
                    <div className="flex justify-center items-center h-[300px]">
                      <SecurityLoader type="shield" text="Loading auto-moderation settings..." />
                    </div>
                  </Card>
                </TabsContent>
                
                <TabsContent value="raid-protection">
                  <Card className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Raid Protection</h2>
                    <p className="text-muted-foreground mb-6">
                      Raid protection settings will be displayed here. This includes member verification, join throttling, and lockdown controls.
                    </p>
                    <div className="flex justify-center items-center h-[300px]">
                      <SecurityLoader type="shield" text="Loading raid protection settings..." />
                    </div>
                  </Card>
                </TabsContent>
                
                <TabsContent value="logs">
                  <Card className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Server Logs</h2>
                    <p className="text-muted-foreground mb-6">
                      Server logs will be displayed here. This includes moderation actions, message edits/deletes, member join/leave events, and more.
                    </p>
                    <div className="flex justify-center items-center h-[300px]">
                      <SecurityLoader type="scanning" text="Loading server logs..." />
                    </div>
                  </Card>
                </TabsContent>
                
                <TabsContent value="settings">
                  <Card className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Server Settings</h2>
                    <p className="text-muted-foreground mb-6">
                      Server settings will be displayed here. This includes bot prefix, command permissions, logging channels, and more.
                    </p>
                    <div className="flex justify-center items-center h-[300px]">
                      <SecurityLoader type="fingerprint" text="Loading server settings..." />
                    </div>
                  </Card>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-2">Server not found</h2>
            <p className="text-muted-foreground mb-6">
              The server you're looking for could not be found or you don't have access to it.
            </p>
            <Button onClick={handleBackToServerList}>
              Return to Server List
            </Button>
          </div>
        )}
      </DataLoader>
    </div>
  );
}