import React from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { WebhookMessageForm } from '@/components/dashboard/WebhookMessageForm';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageSquare, MessagesSquare, Info, Mail, Users } from 'lucide-react';

export default function WebhookPage() {
  // Set title via useEffect
  React.useEffect(() => {
    document.title = "Contact Us - Guard-shin";
  }, []);

  // Default webhook URL from user
  const defaultWebhookUrl = "https://discord.com/api/webhooks/1362287611703459961/7U1Q65ihBfWTaAYsov57YS1CiZ1GjE-A0ybJI5-Hf6Th4cwzm7dGoFddME_pyh5vU6PX";

  return (
    <DashboardLayout title="Contact Us">
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Contact Support</h1>
            <p className="text-muted-foreground">
              Send a message directly to our Discord support team
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <WebhookMessageForm defaultWebhookUrl={defaultWebhookUrl} />
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <Info className="mr-2 h-5 w-5" />
                  Contact Information
                </CardTitle>
                <CardDescription>
                  Other ways to reach our support team
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Join Our Support Server</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    For the fastest support, join our official Discord server where our team and community can help with your questions.
                  </p>
                  <div className="mt-3">
                    <a 
                      href="https://discord.gg/g3rFbaW6gw" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-gray-700 bg-gray-800 hover:bg-gray-700 text-sm font-medium text-white transition-colors"
                    >
                      <Users className="h-4 w-4" />
                      <span>Join Support Server</span>
                    </a>
                  </div>
                </div>
                
                <div className="pt-3 border-t border-gray-800">
                  <h3 className="font-medium">Email Support</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    You can also reach us by email for billing inquiries or sensitive matters.
                  </p>
                  <p className="mt-1 text-sm">
                    <a href="mailto:support@witherco.org" className="text-primary hover:underline">
                      support@witherco.org
                    </a>
                  </p>
                </div>
                
                <div className="rounded-md bg-primary/5 p-4 mt-3 border border-primary/20">
                  <p className="text-sm font-medium flex items-center">
                    <Users className="h-4 w-4 mr-2 text-primary" />
                    Premium Support
                  </p>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Premium subscribers receive priority support and access to exclusive features.
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Upgrade to Premium for faster response times and dedicated support.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Common Questions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li>
                    <p className="font-medium text-sm">How do I add Guard-shin to my server?</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Click the "Add to Server" button on the dashboard and follow the authorization steps.
                    </p>
                  </li>
                  
                  <li>
                    <p className="font-medium text-sm">How do I upgrade to Premium?</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Visit the Premium page on our dashboard to view pricing and payment options.
                    </p>
                  </li>
                  
                  <li>
                    <p className="font-medium text-sm">Is my data secure?</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Yes, we use encryption and follow best practices to protect your information.
                    </p>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}