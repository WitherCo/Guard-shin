import React from 'react';
import { ResetPasswordForm } from '@/components/auth/ResetPasswordForm';

export default function ResetPasswordPage() {
  // Set document title directly
  React.useEffect(() => {
    document.title = "Reset Password - Guard-shin";
  }, []);
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">Guard-shin</h1>
          <p className="text-gray-400">Create a new password</p>
        </div>
        <ResetPasswordForm />
      </div>
    </div>
  );
}