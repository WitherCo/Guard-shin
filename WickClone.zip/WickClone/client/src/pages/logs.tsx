import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useToast } from '@/hooks/use-toast';
import { usePremiumStatus } from '@/hooks/use-discord';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  AlertCircle, 
  FileText, 
  Shield, 
  Users, 
  MessageSquare, 
  ArrowDownWideNarrow, 
  Search, 
  Download, 
  Calendar, 
  Award,
  User,
  Edit as MessageEdit,
  Trash2,
  AlertTriangle as ShieldAlert,
  CheckCircle as ShieldCheck,
  UserPlus,
  UserMinus,
  TimerReset,
  Ban,
  ChevronRight,
  ChevronLeft,
  X,
  Check,
  Clock,
  MoreHorizontal,
  Filter,
  RefreshCcw
} from 'lucide-react';

// Placeholder log data
const logsData = [
  {
    id: '1',
    type: 'moderation',
    action: 'ban',
    timestamp: '2025-04-16T14:32:15Z',
    user: { id: '1111111111111111', name: 'ShadowGamer', avatar: null },
    moderator: { id: '2222222222222222', name: 'ModeratorX', avatar: null },
    reason: 'Repeated violations of server rules',
    channel: { id: '3333333333333333', name: 'general' },
    details: 'Permanent ban',
  },
  {
    id: '2',
    type: 'moderation',
    action: 'mute',
    timestamp: '2025-04-16T13:45:22Z',
    user: { id: '4444444444444444', name: 'NinjaDragon', avatar: null },
    moderator: { id: '2222222222222222', name: 'ModeratorX', avatar: null },
    reason: 'Excessive caps and spam',
    channel: { id: '3333333333333333', name: 'general' },
    details: 'Timed mute: 30 minutes',
  },
  {
    id: '3',
    type: 'message',
    action: 'delete',
    timestamp: '2025-04-16T12:15:30Z',
    user: { id: '5555555555555555', name: 'CoolCat99', avatar: null },
    moderator: { id: '2222222222222222', name: 'ModeratorX', avatar: null },
    reason: 'Message contained prohibited content',
    channel: { id: '6666666666666666', name: 'memes' },
    details: 'Message content: [redacted]',
  },
  {
    id: '4',
    type: 'server',
    action: 'join',
    timestamp: '2025-04-16T10:20:45Z',
    user: { id: '7777777777777777', name: 'NewMember123', avatar: null },
    channel: null,
    details: 'Account created: 45 days ago',
  },
  {
    id: '5',
    type: 'server',
    action: 'leave',
    timestamp: '2025-04-16T09:17:32Z',
    user: { id: '8888888888888888', name: 'GoneUser', avatar: null },
    channel: null,
    details: 'Was a member for: 87 days',
  },
  {
    id: '6',
    type: 'automod',
    action: 'filter',
    timestamp: '2025-04-16T08:45:12Z',
    user: { id: '9999999999999999', name: 'TalkativeUser', avatar: null },
    channel: { id: '3333333333333333', name: 'general' },
    details: 'Message contained prohibited words',
  },
  {
    id: '7',
    type: 'message',
    action: 'edit',
    timestamp: '2025-04-16T07:52:34Z',
    user: { id: '1010101010101010', name: 'RegularUser', avatar: null },
    channel: { id: '3333333333333333', name: 'general' },
    details: 'Message edited: Before "[redacted]", After "[redacted]"',
  },
  {
    id: '8',
    type: 'moderation',
    action: 'warn',
    timestamp: '2025-04-16T06:32:15Z',
    user: { id: '1212121212121212', name: 'WarningUser', avatar: null },
    moderator: { id: '2222222222222222', name: 'ModeratorX', avatar: null },
    reason: 'Inappropriate behavior',
    channel: { id: '6666666666666666', name: 'memes' },
    details: 'First warning',
  },
  {
    id: '9',
    type: 'automod',
    action: 'quarantine',
    timestamp: '2025-04-15T23:12:47Z',
    user: { id: '1313131313131313', name: 'SuspiciousUser', avatar: null },
    channel: { id: '3333333333333333', name: 'general' },
    details: 'Sent too many messages in a short period',
  },
  {
    id: '10',
    type: 'moderation',
    action: 'kick',
    timestamp: '2025-04-15T21:08:19Z',
    user: { id: '1414141414141414', name: 'KickedUser', avatar: null },
    moderator: { id: '2222222222222222', name: 'ModeratorX', avatar: null },
    reason: 'Advertising other Discord servers',
    channel: { id: '3333333333333333', name: 'general' },
    details: '',
  },
];

// Helper function to format timestamps
const formatDate = (timestamp: string) => {
  const date = new Date(timestamp);
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
};

// Helper function to get the icon for log type
const getLogIcon = (type: string, action: string) => {
  switch (type) {
    case 'moderation':
      switch (action) {
        case 'ban':
          return <Ban className="h-4 w-4 text-red-500" />;
        case 'mute':
          return <TimerReset className="h-4 w-4 text-yellow-500" />;
        case 'warn':
          return <AlertCircle className="h-4 w-4 text-orange-500" />;
        case 'kick':
          return <UserMinus className="h-4 w-4 text-red-400" />;
        default:
          return <Shield className="h-4 w-4 text-purple-500" />;
      }
    case 'message':
      if (action === 'delete') {
        return <Trash2 className="h-4 w-4 text-gray-500" />;
      } else {
        return <MessageEdit className="h-4 w-4 text-blue-500" />;
      }
    case 'server':
      if (action === 'join') {
        return <UserPlus className="h-4 w-4 text-green-500" />;
      } else {
        return <UserMinus className="h-4 w-4 text-red-400" />;
      }
    case 'automod':
      return <ShieldAlert className="h-4 w-4 text-yellow-500" />;
    default:
      return <FileText className="h-4 w-4 text-gray-500" />;
  }
};

// Helper function to get the badge color for log type
const getLogBadgeColor = (type: string) => {
  switch (type) {
    case 'moderation':
      return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
    case 'message':
      return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    case 'server':
      return 'bg-green-500/10 text-green-500 border-green-500/20';
    case 'automod':
      return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    default:
      return 'bg-gray-500/10 text-gray-500 border-gray-500/20';
  }
};

const Logs: React.FC = () => {
  const { toast } = useToast();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const [selectedLogType, setSelectedLogType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const { isPremium } = usePremiumStatus();
  
  const logsPerPage = 10;

  // Fetch logs data
  const { data: logs, isLoading, refetch } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'logs', selectedLogType, currentPage],
    enabled: !!selectedServerId && isPremium,
    // Since we don't have this endpoint yet, we'll just use our mock data
    queryFn: () => {
      // Filter logs based on selected type and search query
      return Promise.resolve({
        logs: logsData
          .filter(log => selectedLogType === 'all' || log.type === selectedLogType)
          .filter(log => {
            if (!searchQuery) return true;
            const query = searchQuery.toLowerCase();
            return (
              (log.user?.name?.toLowerCase().includes(query)) ||
              (log.moderator?.name?.toLowerCase().includes(query)) ||
              (log.reason?.toLowerCase().includes(query)) ||
              (log.channel?.name?.toLowerCase().includes(query)) ||
              (log.details?.toLowerCase().includes(query))
            );
          }),
        totalPages: Math.ceil(logsData.length / logsPerPage)
      });
    },
    onError: () => {
      // Silently fail and show empty state
    }
  });

  const filteredLogs = logs?.logs || [];
  const totalPages = logs?.totalPages || 1;

  const handleDownloadLogs = () => {
    if (!isPremium) {
      toast({
        title: "Premium feature",
        description: "Log export is only available with a premium subscription.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Logs export initiated",
      description: "Your logs export is being prepared and will be downloaded shortly.",
    });
    
    // In a real implementation, this would trigger a server endpoint to generate a CSV/JSON file
  };

  const handleRefreshLogs = () => {
    refetch();
    toast({
      title: "Logs refreshed",
      description: "The logs have been updated with the latest data.",
    });
  };

  const toggleLogExpand = (logId: string) => {
    if (expandedLogId === logId) {
      setExpandedLogId(null);
    } else {
      setExpandedLogId(logId);
    }
  };

  return (
    <DashboardLayout title="Server Logs">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Server Audit Logs</h1>
            <p className="text-gray-400 mt-1">Detailed history of server activity and moderation actions</p>
          </div>
          <div className="mt-4 sm:mt-0 space-x-2 flex">
            <Button 
              variant="outline" 
              className="border-gray-700 text-white hover:bg-gray-700 space-x-1"
              onClick={handleRefreshLogs}
              disabled={!isPremium}
            >
              <RefreshCcw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
            <Button 
              variant="outline" 
              className="border-gray-700 text-white hover:bg-gray-700 space-x-1"
              onClick={handleDownloadLogs}
              disabled={!isPremium}
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
          </div>
        </div>

        {!isPremium && (
          <Card className="border-yellow-600/30 bg-yellow-600/10 shadow-lg">
            <CardContent className="pt-6">
              <div className="flex items-start">
                <div className="mr-4 mt-0.5">
                  <Award className="h-8 w-8 text-yellow-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">Premium Feature</h3>
                  <p className="text-sm text-gray-300 mt-1">
                    Detailed server logs and audit history are available with premium subscriptions. Upgrade to gain insights into moderation actions, message activities, and server events.
                  </p>
                  <Button 
                    className="mt-4 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400"
                    onClick={() => window.location.href = `/premium/${selectedServerId}`}
                  >
                    <Award className="mr-2 h-4 w-4" />
                    Upgrade to Premium
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle>Log Filters</CardTitle>
            <CardDescription>Narrow down logs by type or search for specific events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="w-full md:w-1/3">
                <Select
                  value={selectedLogType}
                  onValueChange={setSelectedLogType}
                  disabled={!isPremium}
                >
                  <SelectTrigger className="w-full bg-discord-dark border-gray-700">
                    <div className="flex items-center">
                      <Filter className="mr-2 h-4 w-4 text-gray-400" />
                      <SelectValue placeholder="Filter by log type" />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-discord-dark border-gray-700">
                    <SelectItem value="all">
                      <div className="flex items-center">
                        <FileText className="mr-2 h-4 w-4 text-gray-400" />
                        All Logs
                      </div>
                    </SelectItem>
                    <SelectItem value="moderation">
                      <div className="flex items-center">
                        <Shield className="mr-2 h-4 w-4 text-purple-500" />
                        Moderation
                      </div>
                    </SelectItem>
                    <SelectItem value="message">
                      <div className="flex items-center">
                        <MessageSquare className="mr-2 h-4 w-4 text-blue-500" />
                        Messages
                      </div>
                    </SelectItem>
                    <SelectItem value="server">
                      <div className="flex items-center">
                        <Users className="mr-2 h-4 w-4 text-green-500" />
                        Server Events
                      </div>
                    </SelectItem>
                    <SelectItem value="automod">
                      <div className="flex items-center">
                        <ShieldAlert className="mr-2 h-4 w-4 text-yellow-500" />
                        AutoMod
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full md:w-2/3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search logs by user, moderator, or action"
                    className="bg-discord-dark border-gray-700 pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    disabled={!isPremium}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
          <CardHeader className="pb-0">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="all" onClick={() => setSelectedLogType('all')}>All</TabsTrigger>
                <TabsTrigger value="moderation" onClick={() => setSelectedLogType('moderation')}>Moderation</TabsTrigger>
                <TabsTrigger value="message" onClick={() => setSelectedLogType('message')}>Messages</TabsTrigger>
                <TabsTrigger value="server" onClick={() => setSelectedLogType('server')}>Server</TabsTrigger>
                <TabsTrigger value="automod" onClick={() => setSelectedLogType('automod')}>AutoMod</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-[250px]" />
                      <Skeleton className="h-4 w-[200px]" />
                    </div>
                  </div>
                ))}
              </div>
            ) : !isPremium ? (
              <div className="py-12 text-center">
                <FileText className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Premium Feature</h3>
                <p className="text-gray-400 max-w-md mx-auto">
                  Server logs require a premium subscription to access.
                </p>
              </div>
            ) : filteredLogs.length === 0 ? (
              <div className="py-12 text-center">
                <FileText className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No logs found</h3>
                <p className="text-gray-400 max-w-md mx-auto">
                  No logs match your current search criteria. Try adjusting your filters or search query.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredLogs.map((log) => (
                  <div 
                    key={log.id} 
                    className={`p-4 rounded-lg border border-gray-800 transition-all ${
                      expandedLogId === log.id ? 'bg-gray-900/50' : 'hover:bg-gray-900/30'
                    }`}
                  >
                    <div 
                      className="flex items-start justify-between cursor-pointer"
                      onClick={() => toggleLogExpand(log.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 pt-1">
                          {getLogIcon(log.type, log.action)}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge className={`font-normal ${getLogBadgeColor(log.type)}`}>
                              {log.type.charAt(0).toUpperCase() + log.type.slice(1)}
                            </Badge>
                            <span className="text-sm text-gray-300 capitalize">{log.action}</span>
                            <span className="text-xs text-gray-500">{formatDate(log.timestamp)}</span>
                          </div>
                          <p className="text-sm text-white">
                            {log.type === 'moderation' ? (
                              <>
                                <span className="font-medium">{log.moderator?.name}</span>
                                <span className="text-gray-400"> {log.action}ned </span>
                                <span className="font-medium">{log.user?.name}</span>
                                {log.reason && (
                                  <span className="text-gray-400"> for "{log.reason}"</span>
                                )}
                              </>
                            ) : log.type === 'message' ? (
                              <>
                                <span className="font-medium">{log.user?.name}</span>
                                <span className="text-gray-400">'s message was {log.action}ed</span>
                                {log.channel && (
                                  <span className="text-gray-400"> in #{log.channel.name}</span>
                                )}
                              </>
                            ) : log.type === 'server' ? (
                              <>
                                <span className="font-medium">{log.user?.name}</span>
                                <span className="text-gray-400"> {log.action === 'join' ? 'joined' : 'left'} the server</span>
                              </>
                            ) : log.type === 'automod' ? (
                              <>
                                <span className="text-gray-400">AutoMod {log.action}ed a message from </span>
                                <span className="font-medium">{log.user?.name}</span>
                                {log.channel && (
                                  <span className="text-gray-400"> in #{log.channel.name}</span>
                                )}
                              </>
                            ) : (
                              <span className="text-gray-400">Unknown log action</span>
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="flex-shrink-0 pt-1">
                        {expandedLogId === log.id ? (
                          <ChevronRight className="h-5 w-5 text-gray-500 transform rotate-90" />
                        ) : (
                          <ChevronRight className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {/* Expanded log details */}
                    {expandedLogId === log.id && (
                      <div className="mt-4 pl-10 pt-4 border-t border-gray-800">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-3 gap-x-6">
                          <div>
                            <h4 className="text-xs text-gray-500 uppercase mb-1">User</h4>
                            <p className="text-sm text-white flex items-center">
                              <User className="h-3.5 w-3.5 text-gray-400 mr-1.5" />
                              {log.user?.name} ({log.user?.id})
                            </p>
                          </div>
                          
                          {log.moderator && (
                            <div>
                              <h4 className="text-xs text-gray-500 uppercase mb-1">Moderator</h4>
                              <p className="text-sm text-white flex items-center">
                                <Shield className="h-3.5 w-3.5 text-gray-400 mr-1.5" />
                                {log.moderator?.name} ({log.moderator?.id})
                              </p>
                            </div>
                          )}
                          
                          {log.channel && (
                            <div>
                              <h4 className="text-xs text-gray-500 uppercase mb-1">Channel</h4>
                              <p className="text-sm text-white flex items-center">
                                <MessageSquare className="h-3.5 w-3.5 text-gray-400 mr-1.5" />
                                #{log.channel?.name} ({log.channel?.id})
                              </p>
                            </div>
                          )}
                          
                          <div>
                            <h4 className="text-xs text-gray-500 uppercase mb-1">Timestamp</h4>
                            <p className="text-sm text-white flex items-center">
                              <Clock className="h-3.5 w-3.5 text-gray-400 mr-1.5" />
                              {new Date(log.timestamp).toLocaleString()}
                            </p>
                          </div>
                          
                          {log.reason && (
                            <div className="md:col-span-2">
                              <h4 className="text-xs text-gray-500 uppercase mb-1">Reason</h4>
                              <p className="text-sm text-white">
                                {log.reason}
                              </p>
                            </div>
                          )}
                          
                          {log.details && (
                            <div className="md:col-span-2">
                              <h4 className="text-xs text-gray-500 uppercase mb-1">Details</h4>
                              <p className="text-sm text-white">
                                {log.details}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="border-gray-700"
                    >
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                    <span className="text-sm text-gray-400">
                      Page {currentPage} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="border-gray-700"
                    >
                      Next
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="rounded-lg bg-gray-900/50 p-4 border border-gray-800">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5 mr-3" />
            <div>
              <h3 className="text-sm font-medium text-white">Log Retention</h3>
              <p className="text-sm text-gray-400 mt-1">
                Server logs are retained for 30 days with the standard premium plan, and 90 days with the premium+ plan. 
                Export logs regularly if you need to keep them for longer periods.
              </p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Logs;