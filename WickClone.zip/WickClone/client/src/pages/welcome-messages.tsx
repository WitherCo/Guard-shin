import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { WelcomeMessageSetting } from '@shared/schema';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import { usePremiumStatus } from '@/hooks/use-discord';
import {
  MessageSquarePlus,
  Tag,
  Hash,
  Zap,
  User,
  Calendar,
  Server,
  Palette,
  ImagePlus,
  MessagesSquare,
  BellPlus,
  HelpCircle,
  Award
} from 'lucide-react';

// Form schema
const welcomeMessageSchema = z.object({
  enabled: z.boolean().default(false),
  welcomeChannelId: z.string().optional(),
  welcomeMessage: z.string().optional(),
  embedEnabled: z.boolean().default(false),
  embedColor: z.string().default('#5865F2'),
  embedTitle: z.string().optional(),
  embedDescription: z.string().optional(),
  embedThumbnail: z.boolean().default(false),
  embedImage: z.string().optional(),
  embedFooter: z.string().optional(),
  dmWelcomeEnabled: z.boolean().default(false),
  dmWelcomeMessage: z.string().optional(),
  autoRoleEnabled: z.boolean().default(false),
  autoRoleIds: z.array(z.string()).optional(),
});

type WelcomeMessageFormValues = z.infer<typeof welcomeMessageSchema>;

const WelcomeMessages: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const { isPremium } = usePremiumStatus();

  // Fetch server channels
  const { data: channels, isLoading: loadingChannels } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'channels'],
    enabled: !!selectedServerId,
  });

  // Fetch server roles
  const { data: roles, isLoading: loadingRoles } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'roles'],
    enabled: !!selectedServerId,
  });

  // Fetch welcome message settings
  const { data: settings, isLoading: loadingSettings } = useQuery<WelcomeMessageSetting>({
    queryKey: ['/api/servers', selectedServerId, 'welcome-message'],
    enabled: !!selectedServerId,
  });

  // Form setup
  const form = useForm<WelcomeMessageFormValues>({
    resolver: zodResolver(welcomeMessageSchema),
    defaultValues: {
      enabled: false,
      welcomeChannelId: '',
      welcomeMessage: 'Welcome {user} to {server}!',
      embedEnabled: false,
      embedColor: '#5865F2',
      embedTitle: 'Welcome to {server}',
      embedDescription: 'Thanks for joining our community! We now have {memberCount} members!',
      embedThumbnail: false,
      embedImage: '',
      embedFooter: 'Powered by Guard-shin',
      dmWelcomeEnabled: false,
      dmWelcomeMessage: 'Thanks for joining {server}! We hope you enjoy your stay.',
      autoRoleEnabled: false,
      autoRoleIds: [],
    },
  });

  // Update form values when settings are loaded
  React.useEffect(() => {
    if (settings) {
      form.reset({
        enabled: settings.enabled || false,
        welcomeChannelId: settings.welcomeChannelId || '',
        welcomeMessage: settings.welcomeMessage || 'Welcome {user} to {server}!',
        embedEnabled: settings.embedEnabled || false,
        embedColor: settings.embedColor || '#5865F2',
        embedTitle: settings.embedTitle || 'Welcome to {server}',
        embedDescription: settings.embedDescription || 'Thanks for joining our community! We now have {memberCount} members!',
        embedThumbnail: settings.embedThumbnail || false,
        embedImage: settings.embedImage || '',
        embedFooter: settings.embedFooter || 'Powered by Guard-shin',
        dmWelcomeEnabled: settings.dmWelcomeEnabled || false,
        dmWelcomeMessage: settings.dmWelcomeMessage || 'Thanks for joining {server}! We hope you enjoy your stay.',
        autoRoleEnabled: settings.autoRoleEnabled || false,
        autoRoleIds: settings.autoRoleIds || [],
      });
    }
  }, [settings, form]);

  // Save settings mutation
  const saveSettings = useMutation({
    mutationFn: async (values: WelcomeMessageFormValues) => {
      const response = await fetch(`/api/servers/${selectedServerId}/welcome-message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...values,
          serverId: selectedServerId,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update welcome message settings');
      }

      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers', selectedServerId, 'welcome-message'] });
      toast({
        title: 'Settings saved',
        description: 'Welcome message settings have been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save settings',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: WelcomeMessageFormValues) => {
    saveSettings.mutate(values);
  };

  // Variables placeholders
  const variablePlaceholders = [
    { name: '{user}', description: 'Mentions the user' },
    { name: '{username}', description: 'User\'s name without mention' },
    { name: '{server}', description: 'Server name' },
    { name: '{memberCount}', description: 'Current member count' },
    { name: '{userAvatar}', description: 'User\'s avatar URL' },
  ];

  // Loading state
  if (loadingSettings) {
    return (
      <DashboardLayout title="Welcome Messages">
        <div className="space-y-6">
          <Skeleton className="h-[400px] w-full rounded-lg" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Welcome Messages">
      <div className="space-y-6">
        <div className="max-w-5xl mx-auto">
          <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <div className="flex items-center">
                <div className="p-2 rounded-lg mr-3 bg-primary/10">
                  <MessageSquarePlus className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-xl text-white">Welcome Message Configuration</CardTitle>
                  <CardDescription>
                    Customize how new members are welcomed to your server
                  </CardDescription>
                </div>
                {!isPremium && (
                  <div className="ml-auto">
                    <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-white rounded-full px-3 py-1 text-xs font-semibold flex items-center">
                      <Award className="h-3.5 w-3.5 mr-1" />
                      Premium Feature
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="enabled"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base text-white">Enable Welcome Messages</FormLabel>
                          <FormDescription className="text-sm text-gray-400">
                            Send a message when new users join your server
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            disabled={!isPremium}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <Tabs defaultValue="channel" className="w-full">
                    <TabsList className="grid grid-cols-3 mb-6">
                      <TabsTrigger value="channel">Channel Message</TabsTrigger>
                      <TabsTrigger value="embed">Embed Settings</TabsTrigger>
                      <TabsTrigger value="additional">Additional Options</TabsTrigger>
                    </TabsList>

                    {/* Channel Message Settings */}
                    <TabsContent value="channel" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="welcomeChannelId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Welcome Channel</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              disabled={!isPremium || !form.getValues().enabled}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select channel" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700">
                                {/* Placeholder for channels - would be populated from API */}
                                <SelectItem value="999999999999999999">
                                  <div className="flex items-center">
                                    <Hash className="h-4 w-4 mr-2 text-gray-400" />
                                    welcome
                                  </div>
                                </SelectItem>
                                <SelectItem value="888888888888888888">
                                  <div className="flex items-center">
                                    <Hash className="h-4 w-4 mr-2 text-gray-400" />
                                    general
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Choose the channel where welcome messages will be sent
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="welcomeMessage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Welcome Message</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Welcome {user} to {server}!"
                                className="resize-y min-h-[100px] bg-discord-dark border-gray-700"
                                disabled={!isPremium || !form.getValues().enabled}
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Customize the message that will be sent when a user joins
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="p-4 bg-gray-900 rounded-lg">
                        <h4 className="text-sm font-medium text-white mb-2 flex items-center">
                          <HelpCircle className="h-4 w-4 mr-1.5 text-blue-400" />
                          Available Variables
                        </h4>
                        <div className="grid grid-cols-2 gap-2">
                          {variablePlaceholders.map((variable) => (
                            <div key={variable.name} className="flex items-start">
                              <code className="px-1.5 py-0.5 rounded bg-gray-800 text-xs text-blue-400 font-mono mr-2">
                                {variable.name}
                              </code>
                              <span className="text-xs text-gray-400">{variable.description}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </TabsContent>

                    {/* Embed Settings */}
                    <TabsContent value="embed" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="embedEnabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base text-white">Enable Embed</FormLabel>
                              <FormDescription className="text-sm text-gray-400">
                                Send a rich embed instead of a plain message
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                disabled={!isPremium || !form.getValues().enabled}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="embedColor"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Embed Color</FormLabel>
                              <div className="flex">
                                <FormControl>
                                  <Input
                                    type="text"
                                    placeholder="#5865F2"
                                    className="bg-discord-dark border-gray-700"
                                    disabled={!isPremium || !form.getValues().embedEnabled}
                                    {...field}
                                  />
                                </FormControl>
                                <div 
                                  className="w-10 h-10 ml-2 rounded border border-gray-700" 
                                  style={{ backgroundColor: field.value || '#5865F2' }}
                                />
                              </div>
                              <FormDescription>
                                Color for the embed's left border (hex code)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="embedTitle"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Embed Title</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Welcome to {server}"
                                  className="bg-discord-dark border-gray-700"
                                  disabled={!isPremium || !form.getValues().embedEnabled}
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Title displayed at the top of the embed
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="embedDescription"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Embed Description</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Thanks for joining our community!"
                                className="resize-y min-h-[100px] bg-discord-dark border-gray-700"
                                disabled={!isPremium || !form.getValues().embedEnabled}
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Main content of the embed
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="embedThumbnail"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base text-white">User Avatar Thumbnail</FormLabel>
                                <FormDescription className="text-sm text-gray-400">
                                  Display user's avatar as thumbnail
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  disabled={!isPremium || !form.getValues().embedEnabled}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="embedImage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Embed Image URL</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="https://example.com/welcome-banner.png"
                                  className="bg-discord-dark border-gray-700"
                                  disabled={!isPremium || !form.getValues().embedEnabled}
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                URL to an image displayed in the embed
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="embedFooter"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Embed Footer</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Powered by Guard-shin"
                                className="bg-discord-dark border-gray-700"
                                disabled={!isPremium || !form.getValues().embedEnabled}
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Small text displayed at the bottom of the embed
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Embed Preview */}
                      <div className="mt-4">
                        <h3 className="text-sm font-medium text-white mb-2">Embed Preview</h3>
                        <div className="border-l-4 rounded-sm p-4 bg-discord-dark" style={{ borderLeftColor: form.getValues().embedColor || '#5865F2' }}>
                          <div className="mb-2 font-semibold">{form.getValues().embedTitle || 'Welcome to {server}'}</div>
                          <div className="text-sm text-gray-300 mb-3">{form.getValues().embedDescription || 'Thanks for joining our community!'}</div>
                          {form.getValues().embedImage && (
                            <div className="my-2 bg-gray-700 w-full h-32 rounded flex items-center justify-center">
                              <ImagePlus className="h-8 w-8 text-gray-500" />
                            </div>
                          )}
                          {form.getValues().embedFooter && (
                            <div className="text-xs text-gray-400">{form.getValues().embedFooter}</div>
                          )}
                        </div>
                      </div>
                    </TabsContent>

                    {/* Additional Options */}
                    <TabsContent value="additional" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="dmWelcomeEnabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base text-white">Direct Message Welcome</FormLabel>
                              <FormDescription className="text-sm text-gray-400">
                                Send a welcome message via DM when users join
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                disabled={!isPremium || !form.getValues().enabled}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="dmWelcomeMessage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">DM Welcome Message</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Thanks for joining {server}! We hope you enjoy your stay."
                                className="resize-y min-h-[100px] bg-discord-dark border-gray-700"
                                disabled={!isPremium || !form.getValues().dmWelcomeEnabled}
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Message that will be sent via DM
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="autoRoleEnabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base text-white">Auto-Role Assignment</FormLabel>
                              <FormDescription className="text-sm text-gray-400">
                                Automatically assign roles to new members
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                disabled={!isPremium || !form.getValues().enabled}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="autoRoleIds"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Roles to Assign</FormLabel>
                            <Select
                              disabled={!isPremium || !form.getValues().autoRoleEnabled}
                              value={field.value?.[0] || ''}
                              onValueChange={(value) => {
                                field.onChange([value]); // For simplicity, just allow one role
                              }}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-discord-dark border-gray-700">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-discord-dark border-gray-700">
                                {/* Placeholder for roles - would be populated from API */}
                                <SelectItem value="101010101010101010">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-green-500 mr-2" />
                                    Member
                                  </div>
                                </SelectItem>
                                <SelectItem value="202020202020202020">
                                  <div className="flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-blue-500 mr-2" />
                                    Newcomer
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Role(s) that will be assigned to new members
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="p-4 bg-gray-900 rounded-lg">
                        <h4 className="text-sm font-medium text-white mb-2 flex items-center">
                          <HelpCircle className="h-4 w-4 mr-1.5 text-blue-400" />
                          Auto-Role Requirements
                        </h4>
                        <ul className="space-y-1 text-sm text-gray-400">
                          <li className="flex items-center">
                            <Tag className="h-3.5 w-3.5 mr-1.5 text-green-400" />
                            Bot needs "Manage Roles" permission
                          </li>
                          <li className="flex items-center">
                            <Tag className="h-3.5 w-3.5 mr-1.5 text-green-400" />
                            Bot's role must be higher than assigned roles
                          </li>
                        </ul>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="pt-4 border-t border-gray-800">
                    <Button 
                      type="submit"
                      disabled={!isPremium}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Save Changes
                    </Button>
                    {!isPremium && (
                      <div className="mt-2 text-sm text-amber-400 flex items-center">
                        <Award className="h-3.5 w-3.5 mr-1.5" />
                        This is a premium feature. Upgrade to customize welcome messages.
                      </div>
                    )}
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          <div className="mt-6">
            <h3 className="text-lg font-medium text-white mb-3">Command Usage</h3>
            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/welcome set-channel #welcome</div>
                    <div className="text-gray-400 text-xs mt-1">Set the channel where welcome messages will be sent</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/welcome set-message Welcome {'{user}'} to our server!</div>
                    <div className="text-gray-400 text-xs mt-1">Set the welcome message text</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/welcome toggle</div>
                    <div className="text-gray-400 text-xs mt-1">Turn welcome messages on or off</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md font-mono text-sm">
                    <div className="text-blue-400">/welcome test</div>
                    <div className="text-gray-400 text-xs mt-1">Test the welcome message with your account</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default WelcomeMessages;