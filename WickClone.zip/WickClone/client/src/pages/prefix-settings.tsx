import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Server } from '@shared/schema';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Terminal, Check, AlertCircle } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

const PrefixSettings: React.FC = () => {
  const { toast } = useToast();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const [newPrefix, setNewPrefix] = useState<string>('!');
  
  // Fetch servers
  const { data: servers, isLoading: loadingServers } = useQuery<Server[]>({ 
    queryKey: ['/api/servers'], 
  });
  
  // Fetch server details
  const { data: server } = useQuery<Server>({ 
    queryKey: ['/api/servers', selectedServerId], 
    enabled: !!selectedServerId,
  });

  // Get current prefix (in a real implementation, this would be fetched from the API)
  const getCurrentPrefix = () => {
    // This is a placeholder. In a real implementation, you would fetch this from the API
    const prefixMap: Record<string, string> = {
      '123456789012345678': '.',    // Example server 1
      '234567890123456789': '?',    // Example server 2
      '345678901234567890': '+'     // Example server 3
    };
    
    return prefixMap[selectedServerId] || '!';
  };
  
  const currentPrefix = getCurrentPrefix();
  
  // Mock mutation for updating prefix (in a real implementation, this would be a proper API call)
  const updatePrefixMutation = useMutation({
    mutationFn: async (prefix: string) => {
      // This would be an actual API call in a real implementation
      return { success: true, prefix };
    },
    onSuccess: () => {
      toast({
        title: "Prefix updated",
        description: `Server prefix has been updated to "${newPrefix}"`,
        variant: "default",
      });
    },
    onError: () => {
      toast({
        title: "Failed to update prefix",
        description: "An error occurred while updating the prefix",
        variant: "destructive",
      });
    }
  });
  
  const handleServerChange = (value: string) => {
    setSelectedServerId(value);
    // In a real implementation, you'd fetch the current prefix for the selected server
    // For now, we'll use our mock function
    setNewPrefix(getCurrentPrefix());
  };
  
  const handlePrefixChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewPrefix(e.target.value);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate prefix
    if (!newPrefix) {
      toast({
        title: "Invalid prefix",
        description: "Prefix cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    if (newPrefix.length > 5) {
      toast({
        title: "Invalid prefix",
        description: "Prefix cannot be longer than 5 characters",
        variant: "destructive",
      });
      return;
    }
    
    // Update prefix
    updatePrefixMutation.mutate(newPrefix);
  };
  
  // Generate command examples with the new prefix
  const generateExamples = (prefix: string) => {
    return [
      `${prefix}help`,
      `${prefix}ban @user`,
      `${prefix}warn @user Bad behavior`,
      `${prefix}mute @user 10m`
    ];
  };
  
  return (
    <DashboardLayout title="Prefix Settings">
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 min-w-0">
            <div className="relative rounded-md w-full sm:w-64">
              <Select 
                value={selectedServerId} 
                onValueChange={handleServerChange}
              >
                <SelectTrigger className="pl-10 w-full">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Users className="h-5 w-5 text-gray-400" />
                  </div>
                  <SelectValue placeholder="Select a server" />
                </SelectTrigger>
                <SelectContent className="bg-discord-dark border-discord-darker">
                  {!loadingServers && servers?.map(server => (
                    <SelectItem key={server.id} value={server.id}>{server.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-discord-dark">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Terminal className="mr-2 h-5 w-5 text-primary" />
              Command Prefix
            </CardTitle>
            <CardDescription>
              Set a custom command prefix for your server. The default prefix is <code>!</code>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <div className="grid w-full items-center gap-4">
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="prefix">Current Prefix: <code>{currentPrefix}</code></Label>
                  <div className="flex space-x-2">
                    <Input
                      id="prefix"
                      placeholder="New prefix (e.g. !, ., ?)"
                      value={newPrefix}
                      onChange={handlePrefixChange}
                      className="bg-discord-darker"
                      maxLength={5}
                    />
                    <Button 
                      type="submit" 
                      disabled={updatePrefixMutation.isPending || newPrefix === currentPrefix}
                    >
                      {updatePrefixMutation.isPending ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-t-transparent" />
                      ) : (
                        <>Save</>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </form>
            
            <div className="mt-4">
              <h3 className="text-sm font-medium mb-2">Command Format</h3>
              <div className="bg-discord-darker rounded-md p-3">
                <code>{newPrefix}command [arguments]</code>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-start">
            <h3 className="text-sm font-medium mb-2">Notes</h3>
            <ul className="space-y-1 text-sm text-gray-400">
              <li className="flex items-start">
                <Check className="h-4 w-4 mr-2 text-green-500 mt-0.5" />
                Commands also work by mentioning the bot: <code>@Guard-shin help</code>
              </li>
              <li className="flex items-start">
                <Check className="h-4 w-4 mr-2 text-green-500 mt-0.5" />
                Slash commands work without any prefix: <code>/ban @user</code>
              </li>
              <li className="flex items-start">
                <AlertCircle className="h-4 w-4 mr-2 text-amber-500 mt-0.5" />
                Maximum prefix length is 5 characters
              </li>
            </ul>
          </CardFooter>
        </Card>
        
        <Card className="bg-discord-dark">
          <CardHeader>
            <CardTitle>Command Examples</CardTitle>
            <CardDescription>
              Here are some examples of commands with the new prefix
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {generateExamples(newPrefix).map((example, index) => (
                <div key={index} className="bg-discord-darker rounded-md p-3">
                  <code>{example}</code>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="link" className="px-0 text-primary">
              View all commands
            </Button>
          </CardFooter>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default PrefixSettings;