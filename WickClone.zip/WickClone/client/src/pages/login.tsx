import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Shield, ChevronLeft, Bot, Info } from 'lucide-react';
import { SiDiscord } from 'react-icons/si';
import LoginForm from '@/components/auth/LoginForm';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-border py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Guard-shin</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild size="sm">
              <Link href="/">
                <ChevronLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <Button variant="outline" asChild size="sm">
              <Link href="/register">
                Register
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8 bg-gradient-to-b from-background to-background/80">
        <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {/* Login form */}
          <div className="flex flex-col items-center">
            <LoginForm />
          </div>
          
          {/* Information section */}
          <div className="bg-card border rounded-lg p-8 hidden md:block">
            <div className="flex items-center gap-2 mb-6">
              <Shield className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">Welcome to Guard-shin</h1>
            </div>
            
            <div className="space-y-6">
              <p className="text-muted-foreground">
                Log in to access your dashboard and manage your Discord server's security and moderation settings.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Security Dashboard</h3>
                    <p className="text-sm text-muted-foreground">
                      Configure anti-raid protection, verification systems, and auto-moderation settings.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Server Management</h3>
                    <p className="text-sm text-muted-foreground">
                      View server statistics, member activity, and moderation logs all in one place.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full mt-0.5">
                    <Info className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Need Help?</h3>
                    <p className="text-sm text-muted-foreground">
                      Join our <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">support server</a> for assistance with setting up Guard-shin or troubleshooting issues.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="relative pt-6">
                <div className="absolute inset-0 flex items-center">
                  <Separator className="w-full" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-card px-2 text-muted-foreground">
                    New to Guard-shin?
                  </span>
                </div>
              </div>
              
              <div className="flex flex-col gap-4 text-center">
                <p className="text-sm text-muted-foreground">
                  Create an account to get started with Guard-shin's advanced Discord security features.
                </p>
                <Button size="sm" asChild>
                  <Link href="/register">
                    Create an Account
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="py-6 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-semibold">Guard-shin</span>
              <span className="text-sm text-muted-foreground">© 2025</span>
            </div>
            
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
              <Link href="/terms-of-service" className="hover:text-foreground transition-colors">
                Terms
              </Link>
              <Link href="/privacy-policy" className="hover:text-foreground transition-colors">
                Privacy
              </Link>
              <Link href="/refund-policy" className="hover:text-foreground transition-colors">
                Refunds
              </Link>
              <Link href="/guidelines" className="hover:text-foreground transition-colors">
                Guidelines
              </Link>
              <a 
                href="https://discord.gg/g3rFbaW6gw" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors"
              >
                Support
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}