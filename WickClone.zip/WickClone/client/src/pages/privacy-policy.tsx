import React from 'react';
import { Link } from 'wouter';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Shield, Lock } from 'lucide-react';

export default function PrivacyPolicyPage() {
  return (
    <div className="container max-w-4xl py-8 px-4 mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild className="gap-2">
          <Link href="/">
            <ChevronLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>
      
      <div className="flex items-center space-x-2 mb-6">
        <Lock className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Privacy Policy</h1>
      </div>
      
      <div className="bg-card rounded-lg border p-6 shadow-sm">
        <ScrollArea className="h-[60vh]">
          <div className="prose prose-invert max-w-none">
            <p className="text-muted-foreground text-sm mb-4">Last Updated: April 16, 2025</p>
            
            <p>
              At Guard-shin, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our Discord bot services and website.
            </p>
            
            <h2>1. Information We Collect</h2>
            <p>
              We collect several types of information for various purposes to provide and improve our Service to you:
            </p>
            <h3>1.1. Personal Data</h3>
            <p>
              When you register for an account or use our bot, we may collect:
            </p>
            <ul>
              <li>Discord User ID</li>
              <li>Username and discriminator</li>
              <li>Email address (if provided)</li>
              <li>Avatar images</li>
              <li>Server information for servers where Guard-shin is installed</li>
              <li>Payment information (for premium subscriptions, processed securely through third-party payment processors)</li>
            </ul>
            
            <h3>1.2. Usage Data</h3>
            <p>
              We collect information on how the Service is accessed and used, including:
            </p>
            <ul>
              <li>Commands used</li>
              <li>Features enabled</li>
              <li>Server activity statistics (message counts, moderation actions, etc.)</li>
              <li>Bot performance metrics</li>
            </ul>
            
            <h2>2. How We Use Your Information</h2>
            <p>
              We use the collected data for various purposes:
            </p>
            <ul>
              <li>To provide and maintain our Service</li>
              <li>To notify you about changes to our Service</li>
              <li>To allow you to participate in interactive features of our Service</li>
              <li>To provide customer support</li>
              <li>To gather analysis or valuable information so that we can improve our Service</li>
              <li>To monitor the usage of our Service</li>
              <li>To detect, prevent and address technical issues</li>
              <li>To process payments and maintain subscriptions</li>
            </ul>
            
            <h2>3. Data Retention</h2>
            <p>
              We will retain your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your Personal Data to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our legal agreements and policies.
            </p>
            <p>
              Usage Data is generally retained for a shorter period, except when this data is used to strengthen the security or to improve the functionality of our Service, or we are legally obligated to retain this data for longer periods.
            </p>
            
            <h2>4. Data Transfer</h2>
            <p>
              Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ from those of your jurisdiction.
            </p>
            <p>
              Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.
            </p>
            
            <h2>5. Disclosure of Data</h2>
            <h3>5.1. Business Transaction</h3>
            <p>
              If we are involved in a merger, acquisition or asset sale, your Personal Data may be transferred. We will provide notice before your Personal Data is transferred and becomes subject to a different Privacy Policy.
            </p>
            
            <h3>5.2. Disclosure for Law Enforcement</h3>
            <p>
              Under certain circumstances, we may be required to disclose your Personal Data if required to do so by law or in response to valid requests by public authorities (e.g., a court or a government agency).
            </p>
            
            <h2>6. Security of Data</h2>
            <p>
              The security of your data is important to us but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.
            </p>
            
            <h2>7. Your Data Protection Rights</h2>
            <p>
              You have certain data protection rights. If you wish to be informed about what Personal Data we hold about you and if you want it to be removed from our systems, please contact us.
            </p>
            <p>
              In certain circumstances, you have the following data protection rights:
            </p>
            <ul>
              <li>The right to access, update or delete the information we have on you</li>
              <li>The right of rectification</li>
              <li>The right to object</li>
              <li>The right of restriction</li>
              <li>The right to data portability</li>
              <li>The right to withdraw consent</li>
            </ul>
            
            <h2>8. Service Providers</h2>
            <p>
              We may employ third-party companies and individuals to facilitate our Service ("Service Providers"), provide the Service on our behalf, perform Service-related services or assist us in analyzing how our Service is used.
            </p>
            <p>
              These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
            </p>
            
            <h2>9. Children's Privacy</h2>
            <p>
              Our Service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from anyone under the age of 13. If you are a parent or guardian and you are aware that your child has provided us with Personal Data, please contact us.
            </p>
            
            <h2>10. Changes to This Privacy Policy</h2>
            <p>
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
            </p>
            <p>
              You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
            </p>
            
            <h2>11. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at privacy@guard-shin.com.
            </p>
          </div>
        </ScrollArea>
      </div>
      
      <div className="mt-6 text-center text-sm text-muted-foreground">
        <p>
          By using Guard-shin, you agree to our{' '}
          <Link href="/terms-of-service" className="text-primary hover:underline">
            Terms of Service
          </Link>{' '}
          and{' '}
          <Link href="/privacy-policy" className="text-primary hover:underline">
            Privacy Policy
          </Link>
        </p>
      </div>
    </div>
  );
}