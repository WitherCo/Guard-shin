import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { SiDiscord } from 'react-icons/si';
import { Shield, Lock, ArrowRight } from 'lucide-react';

const DiscordLoginPage: React.FC = () => {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading } = useAuth();
  
  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (user && !isLoading) {
      navigate('/dashboard');
      toast({
        title: "Already logged in",
        description: "You're already logged in with your account",
      });
    }
  }, [user, isLoading, navigate, toast]);
  
  // Function to handle Discord login
  const handleDiscordLogin = () => {
    window.location.href = '/api/auth/discord';
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <Card className="border-gray-800 bg-black/50 backdrop-blur-sm shadow-xl">
          <CardHeader className="text-center space-y-1">
            <div className="mx-auto h-12 w-12 rounded-full bg-blue-600/10 flex items-center justify-center mb-2">
              <Shield className="h-6 w-6 text-blue-500" />
            </div>
            <CardTitle className="text-2xl font-bold text-white">Login with Discord</CardTitle>
            <CardDescription className="text-gray-400">
              Connect your Discord account to access Guard-shin dashboard
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="rounded-lg border border-blue-500/20 bg-blue-500/5 p-4">
              <div className="flex items-start">
                <Lock className="h-5 w-5 text-blue-400 mt-0.5 mr-2" />
                <div>
                  <p className="text-sm text-gray-300">
                    Logging in with Discord is secure and only requires basic permissions. 
                    We do not store your Discord password.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-gray-300">What you'll get access to:</h3>
              <ul className="space-y-1.5 text-sm text-gray-400 list-disc pl-5">
                <li>Configure bot settings for your servers</li>
                <li>Manage moderation and security features</li>
                <li>View server statistics and logs</li>
                <li>Set up custom welcome messages</li>
                <li>Enable premium features</li>
              </ul>
            </div>
          </CardContent>
          
          <CardFooter>
            <Button 
              onClick={handleDiscordLogin}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center gap-2 py-6"
            >
              <SiDiscord className="h-5 w-5" />
              <span>Continue with Discord</span>
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
          
          <div className="px-6 pb-6 pt-2">
            <p className="text-xs text-center text-gray-500">
              By logging in, you agree to our{' '}
              <a href="/terms-of-service" className="text-blue-400 hover:underline">Terms of Service</a> and{' '}
              <a href="/privacy-policy" className="text-blue-400 hover:underline">Privacy Policy</a>
            </p>
          </div>
        </Card>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-400">
            Need help? <a href="/support" className="text-blue-400 hover:underline">Visit our support page</a> or{' '}
            <a href="https://discord.gg/g3rFbaW6gw" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
              join our support server
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default DiscordLoginPage;