import React, { useState, useEffect } from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Separator 
} from '@/components/ui/separator';
import { 
  Terminal, 
  Shield, 
  AlertCircle, 
  User, 
  Settings, 
  Search, 
  Zap, 
  Info, 
  Clock, 
  Lock, 
  Star,
  Bell,
  MessageCircle,
  Slash
} from 'lucide-react';

// Slash Command interface
interface SlashCommand {
  name: string;
  description: string;
  options: CommandOption[];
  usage: string;
  example: string;
  category: string;
  isPremium: boolean;
  isAdmin: boolean;
}

interface CommandOption {
  name: string;
  description: string;
  type: string;
  required: boolean;
  choices?: { name: string; value: string }[];
}

export default function SlashCommandsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCommands, setFilteredCommands] = useState<SlashCommand[]>([]);
  const [activeCategory, setActiveCategory] = useState('all');
  
  useEffect(() => {
    document.title = "Slash Commands - Guard-shin";
    setFilteredCommands(filterCommands(commands, searchTerm, activeCategory));
  }, [searchTerm, activeCategory]);

  // Filter commands based on search term and active category
  const filterCommands = (commands: SlashCommand[], searchTerm: string, category: string) => {
    return commands.filter(command => {
      const matchesSearch = 
        command.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        command.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        command.options.some(option => 
          option.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          option.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
      const matchesCategory = 
        category === 'all' || 
        command.category.toLowerCase() === category.toLowerCase() ||
        (category === 'premium' && command.isPremium) ||
        (category === 'admin' && command.isAdmin);
        
      return matchesSearch && matchesCategory;
    });
  };

  // Generate a premium upsell message
  const premiumUpsellMessage = () => {
    return (
      <div className="p-4 rounded-lg border border-primary/20 bg-primary/5 mt-4">
        <div className="flex items-start gap-3">
          <Star className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium text-primary">Premium Commands</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Premium commands require a Guard-shin Premium subscription. Upgrade today to unlock all premium features and commands.
            </p>
            <div className="mt-3">
              <a 
                href="/premium/123456789012345678" 
                className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
              >
                View Premium Plans
                <Zap className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <DashboardLayout title="Slash Commands">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Slash Commands</h1>
            <p className="text-muted-foreground">
              Complete list of Guard-shin slash commands
            </p>
          </div>
          
          <div className="relative w-full sm:w-64 lg:w-72">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search commands..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Commands section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Slash Command List</CardTitle>
            <CardDescription>
              Browse all available slash commands for Guard-shin Bot
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs 
              defaultValue="all" 
              value={activeCategory}
              onValueChange={setActiveCategory}
              className="w-full"
            >
              <TabsList className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 mb-6">
                <TabsTrigger value="all" className="flex items-center gap-1.5">
                  <Terminal className="h-4 w-4" />
                  <span className="hidden sm:inline">All</span>
                </TabsTrigger>
                <TabsTrigger value="moderation" className="flex items-center gap-1.5">
                  <Shield className="h-4 w-4" />
                  <span className="hidden sm:inline">Moderation</span>
                </TabsTrigger>
                <TabsTrigger value="automod" className="flex items-center gap-1.5">
                  <AlertCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">AutoMod</span>
                </TabsTrigger>
                <TabsTrigger value="utility" className="flex items-center gap-1.5">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Utility</span>
                </TabsTrigger>
                <TabsTrigger value="info" className="flex items-center gap-1.5">
                  <Info className="h-4 w-4" />
                  <span className="hidden sm:inline">Info</span>
                </TabsTrigger>
                <TabsTrigger value="premium" className="flex items-center gap-1.5">
                  <Star className="h-4 w-4" />
                  <span className="hidden sm:inline">Premium</span>
                </TabsTrigger>
                <TabsTrigger value="admin" className="flex items-center gap-1.5">
                  <Lock className="h-4 w-4" />
                  <span className="hidden sm:inline">Admin</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value={activeCategory} className="mt-0">
                {filteredCommands.length > 0 ? (
                  <div className="space-y-4">
                    {activeCategory === 'premium' && premiumUpsellMessage()}
                    
                    {filteredCommands.map((command, index) => (
                      <div 
                        key={index} 
                        className="border rounded-lg p-4 transition-all hover:bg-secondary/5"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <h3 className="font-mono text-lg font-semibold">
                              /{command.name}
                            </h3>
                            {command.isPremium && (
                              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                                <Star className="h-3 w-3 mr-1" />
                                Premium
                              </Badge>
                            )}
                            {command.isAdmin && (
                              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                                <Lock className="h-3 w-3 mr-1" />
                                Admin
                              </Badge>
                            )}
                          </div>
                          <Badge variant="secondary" className="capitalize">
                            {command.category}
                          </Badge>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-3">
                          {command.description}
                        </p>
                        
                        {command.options.length > 0 && (
                          <div className="mb-4">
                            <h4 className="text-xs font-medium mb-2">Options</h4>
                            <div className="space-y-2">
                              {command.options.map((option, idx) => (
                                <div key={idx} className="bg-secondary/10 p-2 rounded-md">
                                  <div className="flex flex-wrap items-center justify-between gap-2">
                                    <div className="flex items-center gap-2">
                                      <code className="text-xs font-mono">{option.name}</code>
                                      <span className="text-xs text-muted-foreground">({option.type})</span>
                                      {option.required && (
                                        <Badge variant="outline" className="text-[0.65rem] py-0 h-4">Required</Badge>
                                      )}
                                    </div>
                                  </div>
                                  <p className="text-xs text-muted-foreground mt-1">{option.description}</p>
                                  
                                  {option.choices && option.choices.length > 0 && (
                                    <div className="mt-1">
                                      <span className="text-xs text-muted-foreground">Choices: </span>
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {option.choices.map((choice, choiceIdx) => (
                                          <Badge key={choiceIdx} variant="outline" className="text-xs">
                                            {choice.name}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <div className="text-xs font-medium mb-1">Usage</div>
                            <div className="font-mono text-xs bg-secondary/20 p-2 rounded overflow-x-auto">
                              {command.usage}
                            </div>
                          </div>
                          <div>
                            <div className="text-xs font-medium mb-1">Example</div>
                            <div className="font-mono text-xs bg-secondary/20 p-2 rounded overflow-x-auto">
                              {command.example}
                            </div>
                          </div>
                        </div>
                        
                        {command.isPremium && (
                          <div className="mt-3 flex items-center gap-2 text-xs text-primary">
                            <Star className="h-3 w-3" />
                            <span>This command is exclusive to Guard-shin Premium subscribers</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Search className="h-12 w-12 mx-auto text-muted-foreground opacity-20" />
                    <h3 className="mt-4 text-lg font-medium">No commands found</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Try a different search term or category
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Slash commands vs Prefix commands */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Slash className="h-5 w-5" />
              Slash Commands vs Prefix Commands
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <Slash className="h-4 w-4 text-primary" />
                  Slash Commands
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Easier to use with auto-complete suggestions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Clearer parameter inputs with descriptions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Works in all channels, including DMs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Doesn't conflict with other bots</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <Terminal className="h-4 w-4 text-primary" />
                  Prefix Commands
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Faster to type for experienced users</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Customizable server-specific prefix</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Works even when Discord's slash commands are down</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Familiar for users of older Discord bots</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="rounded-md bg-secondary/10 p-3">
              <p className="text-sm">
                <strong>Note:</strong> Guard-shin supports both slash commands and prefix commands. You can use either method based on your preference.
              </p>
              <p className="text-sm mt-1">
                Prefix commands use <code className="bg-secondary/20 px-1 rounded">!</code> by default, but this can be customized per server.
              </p>
              <p className="text-sm mt-1">
                Premium commands are available in both formats but require a Premium subscription in either case.
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Usage Notes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Usage Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <MessageCircle className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Auto-completion</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Discord provides auto-completion for slash commands. Just type <code className="font-mono bg-secondary/20 px-1 rounded">/</code> and select Guard-shin from the menu to see all available commands.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <Shield className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Permissions</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Some commands require specific permissions to use. Discord will automatically check if you have the required permissions.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <Clock className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Cooldowns</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Some commands have cooldowns to prevent abuse. Premium users have reduced cooldowns on most commands.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">User Mentions</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  When a command requires a user, you can select them directly from the Discord interface after typing the command.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

// Slash Command definitions
const commands: SlashCommand[] = [
  // Moderation Commands
  {
    name: "ban",
    description: "Ban a user from the server with an optional reason",
    options: [
      {
        name: "user",
        description: "The user to ban",
        type: "User",
        required: true
      },
      {
        name: "reason",
        description: "The reason for the ban",
        type: "String",
        required: false
      },
      {
        name: "delete_days",
        description: "Number of days of messages to delete (0-7)",
        type: "Integer",
        required: false
      }
    ],
    usage: "/ban user:@username reason:Breaking server rules delete_days:7",
    example: "/ban user:@username reason:Breaking server rules delete_days:7",
    category: "moderation",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "unban",
    description: "Unban a user from the server",
    options: [
      {
        name: "user_id",
        description: "The user ID to unban",
        type: "String",
        required: true
      }
    ],
    usage: "/unban user_id:123456789012345678",
    example: "/unban user_id:123456789012345678",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "kick",
    description: "Kick a user from the server with an optional reason",
    options: [
      {
        name: "user",
        description: "The user to kick",
        type: "User",
        required: true
      },
      {
        name: "reason",
        description: "The reason for the kick",
        type: "String",
        required: false
      }
    ],
    usage: "/kick user:@username reason:Disruptive behavior",
    example: "/kick user:@username reason:Disruptive behavior",
    category: "moderation",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "warn",
    description: "Warn a user with an optional reason",
    options: [
      {
        name: "user",
        description: "The user to warn",
        type: "User",
        required: true
      },
      {
        name: "reason",
        description: "The reason for the warning",
        type: "String",
        required: false
      }
    ],
    usage: "/warn user:@username reason:Spamming in chat",
    example: "/warn user:@username reason:Spamming in chat",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "warnings",
    description: "View warnings for a specific user",
    options: [
      {
        name: "user",
        description: "The user to check warnings for",
        type: "User",
        required: true
      }
    ],
    usage: "/warnings user:@username",
    example: "/warnings user:@username",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "clearwarnings",
    description: "Clear all warnings for a user",
    options: [
      {
        name: "user",
        description: "The user to clear warnings for",
        type: "User",
        required: true
      }
    ],
    usage: "/clearwarnings user:@username",
    example: "/clearwarnings user:@username",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "mute",
    description: "Mute a user for a specified duration",
    options: [
      {
        name: "user",
        description: "The user to mute",
        type: "User",
        required: true
      },
      {
        name: "duration",
        description: "Duration of the mute (e.g., 1h, 30m, 1d)",
        type: "String",
        required: false
      },
      {
        name: "reason",
        description: "The reason for the mute",
        type: "String",
        required: false
      }
    ],
    usage: "/mute user:@username duration:1h reason:Excessive noise",
    example: "/mute user:@username duration:1h reason:Excessive noise",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "unmute",
    description: "Unmute a previously muted user",
    options: [
      {
        name: "user",
        description: "The user to unmute",
        type: "User",
        required: true
      }
    ],
    usage: "/unmute user:@username",
    example: "/unmute user:@username",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "purge",
    description: "Delete a specified number of messages from a channel",
    options: [
      {
        name: "amount",
        description: "Number of messages to delete (1-100)",
        type: "Integer",
        required: true
      },
      {
        name: "user",
        description: "Only delete messages from this user",
        type: "User",
        required: false
      }
    ],
    usage: "/purge amount:50",
    example: "/purge amount:50",
    category: "moderation",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "slowmode",
    description: "Set the slowmode cooldown for a channel",
    options: [
      {
        name: "seconds",
        description: "Slowmode delay in seconds (0 to disable)",
        type: "Integer",
        required: true
      }
    ],
    usage: "/slowmode seconds:10",
    example: "/slowmode seconds:10",
    category: "moderation",
    isPremium: false,
    isAdmin: true
  },
  
  // Advanced Moderation (Premium)
  {
    name: "lockdown",
    description: "Temporarily lock a channel, preventing messages from being sent",
    options: [
      {
        name: "duration",
        description: "Duration of the lockdown (e.g., 30m, 1h)",
        type: "String",
        required: false
      },
      {
        name: "reason",
        description: "Reason for the lockdown",
        type: "String",
        required: false
      }
    ],
    usage: "/lockdown duration:30m reason:Server raid in progress",
    example: "/lockdown duration:30m reason:Server raid in progress",
    category: "moderation",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "unlock",
    description: "Unlock a previously locked channel",
    options: [],
    usage: "/unlock",
    example: "/unlock",
    category: "moderation",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "massban",
    description: "Ban multiple users at once",
    options: [
      {
        name: "users",
        description: "Comma-separated list of user IDs to ban",
        type: "String",
        required: true
      },
      {
        name: "reason",
        description: "Reason for the mass ban",
        type: "String",
        required: false
      }
    ],
    usage: "/massban users:123456789012345678,234567890123456789 reason:Raid participants",
    example: "/massban users:123456789012345678,234567890123456789 reason:Raid participants",
    category: "moderation",
    isPremium: true,
    isAdmin: true
  },
  {
    name: "hackban",
    description: "Ban a user that isn't in the server yet",
    options: [
      {
        name: "user_id",
        description: "The user ID to ban",
        type: "String",
        required: true
      },
      {
        name: "reason",
        description: "Reason for the ban",
        type: "String",
        required: false
      }
    ],
    usage: "/hackban user_id:123456789012345678 reason:Known raider",
    example: "/hackban user_id:123456789012345678 reason:Known raider",
    category: "moderation",
    isPremium: true,
    isAdmin: false
  },
  
  // AutoMod Commands
  {
    name: "automod",
    description: "View and configure the automod settings",
    options: [
      {
        name: "setting",
        description: "The automod setting to configure",
        type: "String",
        required: false,
        choices: [
          { name: "Invites", value: "invites" },
          { name: "Links", value: "links" },
          { name: "Caps", value: "caps" },
          { name: "Mentions", value: "mentions" },
          { name: "Spam", value: "spam" }
        ]
      },
      {
        name: "value",
        description: "The value to set (on/off)",
        type: "String",
        required: false,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      }
    ],
    usage: "/automod setting:invites value:on",
    example: "/automod setting:invites value:on",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "filter",
    description: "Add or remove words from the word filter",
    options: [
      {
        name: "action",
        description: "Action to perform on the filter",
        type: "String",
        required: true,
        choices: [
          { name: "Add", value: "add" },
          { name: "Remove", value: "remove" },
          { name: "List", value: "list" }
        ]
      },
      {
        name: "word",
        description: "The word to add or remove",
        type: "String",
        required: false
      }
    ],
    usage: "/filter action:add word:badword",
    example: "/filter action:add word:badword",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "antispam",
    description: "Configure anti-spam settings",
    options: [
      {
        name: "status",
        description: "Enable or disable anti-spam",
        type: "String",
        required: true,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      },
      {
        name: "threshold",
        description: "Number of messages that trigger anti-spam",
        type: "Integer",
        required: false
      },
      {
        name: "timeframe",
        description: "Timeframe in seconds to check messages",
        type: "Integer",
        required: false
      }
    ],
    usage: "/antispam status:on threshold:5 timeframe:3",
    example: "/antispam status:on threshold:5 timeframe:3",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "antiraid",
    description: "Configure anti-raid protection",
    options: [
      {
        name: "status",
        description: "Enable or disable anti-raid",
        type: "String",
        required: true,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      },
      {
        name: "level",
        description: "Protection level",
        type: "String",
        required: false,
        choices: [
          { name: "Low", value: "low" },
          { name: "Medium", value: "medium" },
          { name: "High", value: "high" }
        ]
      }
    ],
    usage: "/antiraid status:on level:high",
    example: "/antiraid status:on level:high",
    category: "automod",
    isPremium: false,
    isAdmin: false
  },
  
  // Utility Commands
  {
    name: "prefix",
    description: "View or change the server's command prefix",
    options: [
      {
        name: "new_prefix",
        description: "The new prefix to set (leave empty to view current)",
        type: "String",
        required: false
      }
    ],
    usage: "/prefix new_prefix:>",
    example: "/prefix new_prefix:>",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "help",
    description: "Display help information for commands",
    options: [
      {
        name: "command",
        description: "Specific command to get help with",
        type: "String",
        required: false
      }
    ],
    usage: "/help command:ban",
    example: "/help command:ban",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "ping",
    description: "Check the bot's latency",
    options: [],
    usage: "/ping",
    example: "/ping",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "userinfo",
    description: "Display information about a user",
    options: [
      {
        name: "user",
        description: "The user to get information about",
        type: "User",
        required: false
      }
    ],
    usage: "/userinfo user:@username",
    example: "/userinfo user:@username",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "serverinfo",
    description: "Display information about the server",
    options: [],
    usage: "/serverinfo",
    example: "/serverinfo",
    category: "utility",
    isPremium: false,
    isAdmin: false
  },
  
  // Premium Utility Commands
  {
    name: "welcome",
    description: "Configure welcome messages for new members",
    options: [
      {
        name: "status",
        description: "Enable or disable welcome messages",
        type: "String",
        required: true,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      },
      {
        name: "channel",
        description: "The channel to send welcome messages to",
        type: "Channel",
        required: false
      },
      {
        name: "message",
        description: "Custom welcome message (use {user} and {server} as placeholders)",
        type: "String",
        required: false
      }
    ],
    usage: "/welcome status:on channel:#welcome message:Welcome {user} to {server}!",
    example: "/welcome status:on channel:#welcome message:Welcome {user} to {server}!",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "goodbye",
    description: "Configure goodbye messages for leaving members",
    options: [
      {
        name: "status",
        description: "Enable or disable goodbye messages",
        type: "String",
        required: true,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      },
      {
        name: "channel",
        description: "The channel to send goodbye messages to",
        type: "Channel",
        required: false
      },
      {
        name: "message",
        description: "Custom goodbye message (use {user} and {server} as placeholders)",
        type: "String",
        required: false
      }
    ],
    usage: "/goodbye status:on channel:#general message:{user} has left the server.",
    example: "/goodbye status:on channel:#general message:{user} has left the server.",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "reactionroles",
    description: "Set up reaction roles for users to self-assign",
    options: [
      {
        name: "action",
        description: "Action to perform",
        type: "String",
        required: true,
        choices: [
          { name: "Create", value: "create" },
          { name: "Remove", value: "remove" }
        ]
      },
      {
        name: "message_id",
        description: "ID of the message to add reactions to",
        type: "String",
        required: false
      },
      {
        name: "emoji",
        description: "Emoji to use for the reaction",
        type: "String",
        required: false
      },
      {
        name: "role",
        description: "Role to assign when reacted",
        type: "Role",
        required: false
      }
    ],
    usage: "/reactionroles action:create message_id:123456789012345678 emoji:👍 role:@Member",
    example: "/reactionroles action:create message_id:123456789012345678 emoji:👍 role:@Member",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "autorole",
    description: "Automatically assign roles to new members",
    options: [
      {
        name: "status",
        description: "Enable or disable autorole",
        type: "String",
        required: true,
        choices: [
          { name: "On", value: "on" },
          { name: "Off", value: "off" }
        ]
      },
      {
        name: "role",
        description: "Role to automatically assign",
        type: "Role",
        required: false
      }
    ],
    usage: "/autorole status:on role:@Member",
    example: "/autorole status:on role:@Member",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  {
    name: "logs",
    description: "Configure server logging",
    options: [
      {
        name: "channel",
        description: "Channel to send logs to (use 'disable' to turn off logging)",
        type: "Channel",
        required: true
      },
      {
        name: "type",
        description: "Type of logs to send",
        type: "String",
        required: false,
        choices: [
          { name: "Moderation", value: "moderation" },
          { name: "Messages", value: "messages" },
          { name: "Members", value: "members" },
          { name: "Server", value: "server" },
          { name: "All", value: "all" }
        ]
      }
    ],
    usage: "/logs channel:#mod-logs type:moderation",
    example: "/logs channel:#mod-logs type:moderation",
    category: "utility",
    isPremium: true,
    isAdmin: false
  },
  
  // Info Commands
  {
    name: "botinfo",
    description: "Display information about the bot",
    options: [],
    usage: "/botinfo",
    example: "/botinfo",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "uptime",
    description: "Check how long the bot has been online",
    options: [],
    usage: "/uptime",
    example: "/uptime",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "invite",
    description: "Get an invite link for the bot",
    options: [],
    usage: "/invite",
    example: "/invite",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "premium",
    description: "Get information about Guard-shin Premium",
    options: [],
    usage: "/premium",
    example: "/premium",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  {
    name: "support",
    description: "Get a link to the support server",
    options: [],
    usage: "/support",
    example: "/support",
    category: "info",
    isPremium: false,
    isAdmin: false
  },
  
  // Admin Commands
  {
    name: "setup",
    description: "Run the initial setup for Guard-shin",
    options: [],
    usage: "/setup",
    example: "/setup",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "config",
    description: "View and modify bot configuration",
    options: [
      {
        name: "setting",
        description: "Setting to configure",
        type: "String",
        required: false
      },
      {
        name: "value",
        description: "Value to set",
        type: "String",
        required: false
      }
    ],
    usage: "/config setting:modlogs value:#mod-logs",
    example: "/config setting:modlogs value:#mod-logs",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "permission",
    description: "Configure command permissions for roles",
    options: [
      {
        name: "command",
        description: "Command to configure permissions for",
        type: "String",
        required: true
      },
      {
        name: "role",
        description: "Role to configure permissions for",
        type: "Role",
        required: true
      },
      {
        name: "permission",
        description: "Allow or deny permission",
        type: "String",
        required: true,
        choices: [
          { name: "Allow", value: "allow" },
          { name: "Deny", value: "deny" }
        ]
      }
    ],
    usage: "/permission command:ban role:@Moderator permission:allow",
    example: "/permission command:ban role:@Moderator permission:allow",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  {
    name: "reset",
    description: "Reset all bot settings to default",
    options: [],
    usage: "/reset",
    example: "/reset",
    category: "admin",
    isPremium: false,
    isAdmin: true
  },
  
  // Premium Admin Commands
  {
    name: "backup",
    description: "Create a backup of server settings and configurations",
    options: [
      {
        name: "action",
        description: "Action to perform",
        type: "String",
        required: true,
        choices: [
          { name: "Create", value: "create" },
          { name: "Load", value: "load" },
          { name: "List", value: "list" }
        ]
      },
      {
        name: "backup_id",
        description: "ID of the backup (required for load)",
        type: "String",
        required: false
      }
    ],
    usage: "/backup action:create",
    example: "/backup action:create",
    category: "admin",
    isPremium: true,
    isAdmin: true
  },
  {
    name: "banlist",
    description: "View, import, or export the server ban list",
    options: [
      {
        name: "action",
        description: "Action to perform",
        type: "String",
        required: true,
        choices: [
          { name: "View", value: "view" },
          { name: "Import", value: "import" },
          { name: "Export", value: "export" }
        ]
      }
    ],
    usage: "/banlist action:view",
    example: "/banlist action:view",
    category: "admin",
    isPremium: true,
    isAdmin: true
  },
  {
    name: "verification",
    description: "Set up member verification system",
    options: [
      {
        name: "action",
        description: "Action to perform",
        type: "String",
        required: true,
        choices: [
          { name: "Setup", value: "setup" },
          { name: "Disable", value: "disable" }
        ]
      },
      {
        name: "method",
        description: "Verification method",
        type: "String",
        required: false,
        choices: [
          { name: "Captcha", value: "captcha" },
          { name: "Reaction", value: "reaction" },
          { name: "Question", value: "question" }
        ]
      },
      {
        name: "channel",
        description: "Channel for verification",
        type: "Channel",
        required: false
      }
    ],
    usage: "/verification action:setup method:captcha channel:#verify",
    example: "/verification action:setup method:captcha channel:#verify",
    category: "admin",
    isPremium: true,
    isAdmin: true
  }
];