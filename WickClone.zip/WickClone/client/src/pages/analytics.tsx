import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useToast } from '@/hooks/use-toast';
import { usePremiumStatus } from '@/hooks/use-discord';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  Line,
  LineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  BarChart3,
  LineChart as LineIcon,
  PieChart as PieIcon,
  Users,
  MessageSquare,
  Shield,
  ShieldAlert,
  Clock,
  Award,
  DownloadCloud,
  Calendar,
  TrendingUp,
  HelpCircle,
  User,
  Info,
} from 'lucide-react';

// Placeholder data for charts
const commandUsageData = [
  { name: 'Ban', count: 23, color: '#FF4D4D' },
  { name: 'Kick', count: 17, color: '#FFA64D' },
  { name: 'Mute', count: 45, color: '#FFEE4D' },
  { name: 'Warn', count: 67, color: '#4DFF77' },
  { name: 'Clear', count: 38, color: '#4DC3FF' },
  { name: 'Help', count: 120, color: '#AD4DFF' },
];

const activityData = [
  { date: 'Mon', messages: 1420, commands: 89, automod: 12 },
  { date: 'Tue', messages: 1550, commands: 102, automod: 15 },
  { date: 'Wed', messages: 1780, commands: 134, automod: 18 },
  { date: 'Thu', messages: 1620, commands: 96, automod: 10 },
  { date: 'Fri', messages: 2100, commands: 156, automod: 25 },
  { date: 'Sat', messages: 2540, commands: 187, automod: 31 },
  { date: 'Sun', messages: 2210, commands: 164, automod: 22 },
];

const memberActivityData = [
  { date: 'Mon', joins: 8, leaves: 3 },
  { date: 'Tue', joins: 12, leaves: 5 },
  { date: 'Wed', joins: 15, leaves: 4 },
  { date: 'Thu', joins: 9, leaves: 6 },
  { date: 'Fri', joins: 21, leaves: 7 },
  { date: 'Sat', joins: 28, leaves: 9 },
  { date: 'Sun', joins: 17, leaves: 8 },
];

const infractionTypeData = [
  { name: 'Warnings', value: 67, color: '#FFD700' },
  { name: 'Mutes', value: 45, color: '#FF9900' },
  { name: 'Kicks', value: 17, color: '#FF6347' },
  { name: 'Bans', value: 23, color: '#DC143C' },
];

const messageActivityHourly = [
  { hour: '00:00', messages: 120 },
  { hour: '01:00', messages: 90 },
  { hour: '02:00', messages: 70 },
  { hour: '03:00', messages: 45 },
  { hour: '04:00', messages: 30 },
  { hour: '05:00', messages: 25 },
  { hour: '06:00', messages: 45 },
  { hour: '07:00', messages: 80 },
  { hour: '08:00', messages: 110 },
  { hour: '09:00', messages: 150 },
  { hour: '10:00', messages: 180 },
  { hour: '11:00', messages: 210 },
  { hour: '12:00', messages: 250 },
  { hour: '13:00', messages: 280 },
  { hour: '14:00', messages: 310 },
  { hour: '15:00', messages: 340 },
  { hour: '16:00', messages: 370 },
  { hour: '17:00', messages: 400 },
  { hour: '18:00', messages: 450 },
  { hour: '19:00', messages: 470 },
  { hour: '20:00', messages: 430 },
  { hour: '21:00', messages: 380 },
  { hour: '22:00', messages: 300 },
  { hour: '23:00', messages: 200 },
];

const topChannelsData = [
  { name: 'general', messages: 12450, color: '#4DC3FF' },
  { name: 'memes', messages: 8970, color: '#FFEE4D' },
  { name: 'bot-commands', messages: 6540, color: '#4DFF77' },
  { name: 'help', messages: 5230, color: '#AD4DFF' },
  { name: 'anime', messages: 3870, color: '#FF4D4D' },
];

const formatNumber = (num: number) => {
  return num > 999 ? (num / 1000).toFixed(1) + 'k' : num;
};

const Analytics: React.FC = () => {
  const { toast } = useToast();
  const [selectedServerId, setSelectedServerId] = useState<string>('123456789012345678');
  const [timeRange, setTimeRange] = useState<string>('7d');
  const { isPremium } = usePremiumStatus();

  // Fetch analytics data
  const { data: analyticsData, isLoading: loadingAnalytics } = useQuery({
    queryKey: ['/api/servers', selectedServerId, 'analytics', timeRange],
    enabled: !!selectedServerId && isPremium,
    // Placeholder since we don't have this endpoint yet
    onError: () => {
      // Silently fail and use mock data for now
    }
  });

  const handleExportData = () => {
    if (!isPremium) {
      toast({
        title: "Premium feature",
        description: "Data export is only available with a premium subscription.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Data export initiated",
      description: "Your analytics data export is being prepared and will be sent to you shortly.",
    });
  };

  return (
    <DashboardLayout title="Analytics & Statistics">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Server Analytics</h1>
            <p className="text-gray-400 mt-1">Detailed statistics about your Discord server activity</p>
          </div>
          <div className="mt-4 sm:mt-0 space-x-2 flex">
            <div className="flex-grow max-w-xs">
              <Select
                value={timeRange}
                onValueChange={setTimeRange}
                disabled={!isPremium}
              >
                <SelectTrigger className="w-full bg-discord-dark border-discord-darker">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent className="bg-discord-dark border-discord-darker">
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                  <SelectItem value="90d">Last 3 Months</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              variant="outline" 
              className="border-gray-700 text-white hover:bg-gray-700"
              onClick={handleExportData}
              disabled={!isPremium}
            >
              <DownloadCloud className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        {!isPremium && (
          <Card className="border-yellow-600/30 bg-yellow-600/10 shadow-lg">
            <CardContent className="pt-6">
              <div className="flex items-start">
                <div className="mr-4 mt-0.5">
                  <Award className="h-8 w-8 text-yellow-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">Premium Feature</h3>
                  <p className="text-sm text-gray-300 mt-1">
                    Detailed analytics and statistics are available with premium subscriptions. Upgrade to unlock insights about your server activity, command usage, and member growth.
                  </p>
                  <Button 
                    className="mt-4 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400"
                    onClick={() => window.location.href = `/premium/${selectedServerId}`}
                  >
                    <Award className="mr-2 h-4 w-4" />
                    Upgrade to Premium
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="commands">Commands</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Users className="h-5 w-5 mr-2 text-primary" />
                    Member Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={memberActivityData}
                          margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis dataKey="date" stroke="#6B7280" />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Line type="monotone" dataKey="joins" name="Joins" stroke="#4ADE80" strokeWidth={2} />
                          <Line type="monotone" dataKey="leaves" name="Leaves" stroke="#F87171" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <LineIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2 text-primary" />
                    Server Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={activityData}
                          margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis dataKey="date" stroke="#6B7280" />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Bar dataKey="messages" name="Messages" fill="#3B82F6" />
                          <Bar dataKey="commands" name="Commands" fill="#8B5CF6" />
                          <Bar dataKey="automod" name="AutoMod Actions" fill="#EC4899" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <ShieldAlert className="h-5 w-5 mr-2 text-primary" />
                    Moderation Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={infractionTypeData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {infractionTypeData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <PieIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Total Members</p>
                      <h3 className="text-2xl font-bold text-white mt-1">
                        {isPremium ? formatNumber(2547) : "—"}
                      </h3>
                      {isPremium && (
                        <p className="text-xs font-medium text-green-500 flex items-center mt-1">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          +8.3% from last week
                        </p>
                      )}
                    </div>
                    <div className="p-2 rounded-lg bg-blue-500/10">
                      <Users className="h-5 w-5 text-blue-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Messages Today</p>
                      <h3 className="text-2xl font-bold text-white mt-1">
                        {isPremium ? formatNumber(3218) : "—"}
                      </h3>
                      {isPremium && (
                        <p className="text-xs font-medium text-green-500 flex items-center mt-1">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          +12.5% from yesterday
                        </p>
                      )}
                    </div>
                    <div className="p-2 rounded-lg bg-purple-500/10">
                      <MessageSquare className="h-5 w-5 text-purple-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Commands Used</p>
                      <h3 className="text-2xl font-bold text-white mt-1">
                        {isPremium ? formatNumber(187) : "—"}
                      </h3>
                      {isPremium && (
                        <p className="text-xs font-medium text-green-500 flex items-center mt-1">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          +4.2% from last week
                        </p>
                      )}
                    </div>
                    <div className="p-2 rounded-lg bg-green-500/10">
                      <Clock className="h-5 w-5 text-green-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Moderation Actions</p>
                      <h3 className="text-2xl font-bold text-white mt-1">
                        {isPremium ? formatNumber(28) : "—"}
                      </h3>
                      {isPremium && (
                        <p className="text-xs font-medium text-red-500 flex items-center mt-1">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          +16.7% from last week
                        </p>
                      )}
                    </div>
                    <div className="p-2 rounded-lg bg-red-500/10">
                      <Shield className="h-5 w-5 text-red-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Commands Tab */}
          <TabsContent value="commands" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Command Usage</CardTitle>
                  <CardDescription>Most used moderation commands</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={commandUsageData}
                          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis type="number" stroke="#6B7280" />
                          <YAxis dataKey="name" type="category" stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Bar dataKey="count" name="Times Used">
                            {commandUsageData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-80 flex items-center justify-center">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Command Usage by Time</CardTitle>
                  <CardDescription>When commands are most active</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={messageActivityHourly}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis 
                            dataKey="hour" 
                            stroke="#6B7280"
                            tickFormatter={(value) => value.slice(0, 2)} 
                          />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="messages" 
                            name="Commands" 
                            stroke="#8B5CF6" 
                            activeDot={{ r: 8 }} 
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-80 flex items-center justify-center">
                      <div className="text-center">
                        <LineIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <CardTitle>Top Command Users</CardTitle>
                <CardDescription>Members who use the bot commands most frequently</CardDescription>
              </CardHeader>
              <CardContent>
                {isPremium ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                      <thead className="text-xs text-gray-400 uppercase bg-discord-dark/50">
                        <tr>
                          <th scope="col" className="px-6 py-3">User</th>
                          <th scope="col" className="px-6 py-3">Commands Used</th>
                          <th scope="col" className="px-6 py-3">Favorite Command</th>
                          <th scope="col" className="px-6 py-3">Last Active</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { id: '1', name: 'WizardKing', commands: 89, favorite: 'help', lastActive: '2 hours ago' },
                          { id: '2', name: 'NightWalker', commands: 65, favorite: 'ban', lastActive: '5 hours ago' },
                          { id: '3', name: 'StormRider', commands: 52, favorite: 'clear', lastActive: '1 day ago' },
                          { id: '4', name: 'Dragonheart', commands: 34, favorite: 'warn', lastActive: '3 hours ago' },
                          { id: '5', name: 'ShadowGuard', commands: 28, favorite: 'mute', lastActive: '6 hours ago' },
                        ].map((user) => (
                          <tr key={user.id} className="border-b border-gray-800">
                            <td className="px-6 py-4 font-medium text-white">
                              <div className="flex items-center">
                                <User className="h-4 w-4 mr-2 text-gray-400" />
                                {user.name}
                              </div>
                            </td>
                            <td className="px-6 py-4">{user.commands}</td>
                            <td className="px-6 py-4">!{user.favorite}</td>
                            <td className="px-6 py-4">{user.lastActive}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="h-48 flex items-center justify-center">
                    <div className="text-center">
                      <Info className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                      <p className="text-gray-400">Premium feature</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Members Tab */}
          <TabsContent value="members" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Member Growth</CardTitle>
                  <CardDescription>New members over time</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={memberActivityData}
                          margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis dataKey="date" stroke="#6B7280" />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Line type="monotone" dataKey="joins" name="Joins" stroke="#4ADE80" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <LineIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Member Retention</CardTitle>
                  <CardDescription>Members leaving the server</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={memberActivityData}
                          margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis dataKey="date" stroke="#6B7280" />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Line type="monotone" dataKey="leaves" name="Leaves" stroke="#F87171" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <LineIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Net Growth</CardTitle>
                  <CardDescription>Overall member change</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={memberActivityData.map(day => ({
                            ...day,
                            net: day.joins - day.leaves
                          }))}
                          margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis dataKey="date" stroke="#6B7280" />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Bar dataKey="net" name="Net Growth" fill="#3B82F6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <CardTitle>Most Active Members</CardTitle>
                <CardDescription>Members with the highest message count</CardDescription>
              </CardHeader>
              <CardContent>
                {isPremium ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                      <thead className="text-xs text-gray-400 uppercase bg-discord-dark/50">
                        <tr>
                          <th scope="col" className="px-6 py-3">Rank</th>
                          <th scope="col" className="px-6 py-3">User</th>
                          <th scope="col" className="px-6 py-3">Messages</th>
                          <th scope="col" className="px-6 py-3">Favorite Channel</th>
                          <th scope="col" className="px-6 py-3">Join Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { id: '1', name: 'CrystalMage', messages: 1243, favoriteChannel: 'general', joinDate: '3 months ago' },
                          { id: '2', name: 'Thunderbolt', messages: 987, favoriteChannel: 'memes', joinDate: '5 months ago' },
                          { id: '3', name: 'SilverArrow', messages: 754, favoriteChannel: 'gaming', joinDate: '2 months ago' },
                          { id: '4', name: 'NightOwl', messages: 612, favoriteChannel: 'anime', joinDate: '6 months ago' },
                          { id: '5', name: 'FrostGiant', messages: 589, favoriteChannel: 'music', joinDate: '1 month ago' },
                        ].map((user, index) => (
                          <tr key={user.id} className="border-b border-gray-800">
                            <td className="px-6 py-4">{index + 1}</td>
                            <td className="px-6 py-4 font-medium text-white">
                              <div className="flex items-center">
                                <User className="h-4 w-4 mr-2 text-gray-400" />
                                {user.name}
                              </div>
                            </td>
                            <td className="px-6 py-4">{user.messages}</td>
                            <td className="px-6 py-4">#{user.favoriteChannel}</td>
                            <td className="px-6 py-4">{user.joinDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="h-48 flex items-center justify-center">
                    <div className="text-center">
                      <Info className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                      <p className="text-gray-400">Premium feature</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Message Activity (24h)</CardTitle>
                  <CardDescription>Messages per hour</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={messageActivityHourly}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis 
                            dataKey="hour" 
                            stroke="#6B7280"
                            tickFormatter={(value) => value.slice(0, 2)} 
                          />
                          <YAxis stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="messages" 
                            name="Messages" 
                            stroke="#3B82F6" 
                            activeDot={{ r: 8 }} 
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-72 flex items-center justify-center">
                      <div className="text-center">
                        <LineIcon className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle>Top Active Channels</CardTitle>
                  <CardDescription>Channels with most messages</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  {isPremium ? (
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={topChannelsData}
                          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                          <XAxis type="number" stroke="#6B7280" />
                          <YAxis dataKey="name" type="category" stroke="#6B7280" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                            labelStyle={{ color: '#FFFFFF' }}
                          />
                          <Bar dataKey="messages" name="Messages">
                            {topChannelsData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-72 flex items-center justify-center">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                        <p className="text-gray-400">Premium feature</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="border-discord-dark bg-black/50 backdrop-blur-sm shadow-lg overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Weekly Message Trends</CardTitle>
                  <CardDescription>Messages per day of the week</CardDescription>
                </div>
                {isPremium && (
                  <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30">
                    Total: 12,820 messages
                  </Badge>
                )}
              </CardHeader>
              <CardContent>
                {isPremium ? (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={activityData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#2D2D2D" />
                        <XAxis dataKey="date" stroke="#6B7280" />
                        <YAxis stroke="#6B7280" />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1F1F1F', borderColor: '#333333' }}
                          labelStyle={{ color: '#FFFFFF' }}
                        />
                        <Bar dataKey="messages" name="Messages" fill="#3B82F6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-80 flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 text-gray-600 mx-auto mb-2" />
                      <p className="text-gray-400">Premium feature</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-between pt-4 border-t border-gray-800">
          <div className="text-sm text-gray-400 flex items-center">
            <HelpCircle className="h-4 w-4 mr-2" />
            Data refreshes every 24 hours. Last update: April 16, 2025, 12:15 AM
          </div>
          <Button 
            variant="link" 
            className="text-primary" 
            onClick={handleExportData}
            disabled={!isPremium}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Export Full Analytics Report
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Analytics;