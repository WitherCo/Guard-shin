import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, PlusCircle, Server, Settings } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

interface DiscordServer {
  id: string;
  name: string;
  icon: string;
  permissions: number;
  owner: boolean;
  features: string[];
}

const DiscordServersList: React.FC = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fetch Discord servers from our API
  const { data: servers, isLoading, error } = useQuery<DiscordServer[]>({
    queryKey: ['/api/discord/guilds'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    retry: 1, // Only retry once if fail
  });

  // Navigate to server dashboard
  const navigateToServer = (serverId: string) => {
    navigate(`/servers/${serverId}`);
  };

  // Open Discord OAuth to add bot to server
  const addBotToServer = () => {
    window.open('https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands', '_blank');
  };

  // Render loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Your Discord Servers</h2>
          <Skeleton className="h-9 w-32" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="bg-black/40 border-gray-800">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <Skeleton className="h-6 w-32" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full my-2" />
                <Skeleton className="h-4 w-3/4 my-2" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-9 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Handle error
  if (error) {
    if (error.message.includes('Discord integration not available')) {
      return (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Your Discord Servers</h2>
          <Card className="bg-black/40 border-gray-800">
            <CardHeader>
              <CardTitle>Discord Connection Required</CardTitle>
              <CardDescription>
                Link your Discord account to see your servers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Connect your Discord account to access server management features.
                You'll be able to configure Guard-shin bot for all servers where you have administrator permissions.
              </p>
            </CardContent>
            <CardFooter>
              <Button 
                variant="default" 
                className="w-full bg-[#5865F2] hover:bg-[#4752C4]"
                onClick={() => window.location.href = '/api/auth/discord'}
              >
                Connect Discord Account
              </Button>
            </CardFooter>
          </Card>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Your Discord Servers</h2>
        <Card className="bg-black/40 border-gray-800 border-red-800/50">
          <CardHeader>
            <CardTitle className="text-red-400">Error Loading Servers</CardTitle>
          </CardHeader>
          <CardContent>
            <p>We couldn't load your Discord servers: {error.message}</p>
            <p className="text-sm text-muted-foreground mt-2">
              This might be due to temporary Discord API issues. Please try again later.
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              variant="outline" 
              onClick={() => window.location.reload()}
              className="w-full"
            >
              Try Again
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // If no servers are returned
  if (!servers || servers.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Your Discord Servers</h2>
          <Button 
            variant="outline" 
            className="bg-black/20"
            onClick={addBotToServer}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add to Server
          </Button>
        </div>
        
        <Card className="bg-black/40 border-gray-800">
          <CardHeader>
            <CardTitle>No Servers Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              You don't have any Discord servers where you have administrator permissions,
              or you haven't added Guard-shin to any of your servers yet.
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              onClick={addBotToServer}
              className="w-full"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Guard-shin to a Server
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Get the server icon URL
  const getServerIcon = (server: DiscordServer): string | undefined => {
    if (!server.icon) return undefined;
    return `https://cdn.discordapp.com/icons/${server.id}/${server.icon}.webp?size=96`;
  };

  // Sort servers: owned servers first, then by name
  const sortedServers = [...servers].sort((a, b) => {
    // Owner servers first
    if (a.owner && !b.owner) return -1;
    if (!a.owner && b.owner) return 1;
    
    // Then sort by name alphabetically
    return a.name.localeCompare(b.name);
  });

  // Check if user can manage the server (has admin permissions)
  const canManageServer = (server: DiscordServer) => {
    // Permission code for ADMINISTRATOR is 0x8 (8)
    return server.owner || (server.permissions & 0x8) === 0x8;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Your Discord Servers</h2>
        <Button 
          variant="outline" 
          className="bg-black/20"
          onClick={addBotToServer}
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          Add to Server
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedServers.map(server => (
          <Card key={server.id} className="bg-black/40 border-gray-800 overflow-hidden hover:border-gray-700 transition-colors">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                {getServerIcon(server) ? (
                  <img 
                    src={getServerIcon(server)} 
                    alt={`${server.name} icon`} 
                    className="h-10 w-10 rounded-full"
                  />
                ) : (
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                    <Server className="h-5 w-5 text-gray-300" />
                  </div>
                )}
                <div>
                  <h3 className="font-medium text-white truncate max-w-[200px]">{server.name}</h3>
                  <div className="flex items-center mt-1">
                    {server.owner && (
                      <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full mr-2">
                        Owner
                      </span>
                    )}
                    {server.features.includes('VERIFIED') && (
                      <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">
                        Verified
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardFooter className="pt-2">
              {canManageServer(server) ? (
                <Button 
                  onClick={() => navigateToServer(server.id)}
                  className="w-full"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Manage
                </Button>
              ) : (
                <Button 
                  variant="secondary" 
                  className="w-full opacity-70"
                  disabled
                >
                  <Shield className="mr-2 h-4 w-4" />
                  No Permission
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default DiscordServersList;