import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Terminal, CommandIcon, LightbulbIcon, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface BotCommandDebuggerProps {
  isAdmin?: boolean;
}

const BotCommandDebugger: React.FC<BotCommandDebuggerProps> = ({ isAdmin = false }) => {
  const [command, setCommand] = useState('');
  const [serverId, setServerId] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [commandType, setCommandType] = useState<'prefix' | 'slash'>('prefix');
  const [selectedCommand, setSelectedCommand] = useState('');
  const { toast } = useToast();

  // List of available prefix commands for quick selection
  const prefixCommands = [
    { name: 'test', description: 'Test if the bot is working' },
    { name: 'ping', description: 'Check bot latency' },
    { name: 'help', description: 'Show list of commands' },
    { name: 'serverinfo', description: 'Display server information' },
    { name: 'premium', description: 'Show premium information' }
  ];

  // Only show to admin users
  if (!isAdmin) return null;

  const handleCommandSelect = (commandName: string) => {
    setSelectedCommand(commandName);
    const prefix = ';';
    setCommand(`${prefix}${commandName}`);
  };

  const handleTestCommand = async () => {
    if (!command) {
      setError('Please enter a command to test');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // Add information about command type to the request
      const response = await apiRequest('POST', '/api/discord/debug/command', {
        command,
        serverId: serverId || undefined,
        type: commandType
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setResult(data.result || 'Command executed successfully');
        toast({
          title: 'Command Test',
          description: `${commandType === 'prefix' ? 'Prefix' : 'Slash'} command sent to the bot successfully`,
        });
      } else {
        setError(data.error || 'Failed to execute command');
        toast({
          title: 'Command Test Failed',
          description: data.error || 'Could not execute the command',
          variant: 'destructive',
        });
      }
    } catch (err) {
      setError('Connection error: ' + (err instanceof Error ? err.message : String(err)));
      toast({
        title: 'Connection Error',
        description: 'Could not connect to the bot service',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full mt-4 border border-gray-800 bg-black/40">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-5 w-5" />
          Bot Command Debugger
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Command Type Selector */}
          <Tabs value={commandType} onValueChange={(value) => setCommandType(value as 'prefix' | 'slash')}>
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="prefix">Prefix Commands</TabsTrigger>
              <TabsTrigger value="slash">Slash Commands</TabsTrigger>
            </TabsList>
            
            <TabsContent value="prefix" className="space-y-4">
              {/* Quick Select Commands */}
              <div>
                <p className="text-sm text-gray-400 mb-2">Quick Select:</p>
                <Select onValueChange={handleCommandSelect} value={selectedCommand}>
                  <SelectTrigger className="bg-gray-950 border-gray-800">
                    <SelectValue placeholder="Select command" />
                  </SelectTrigger>
                  <SelectContent>
                    {prefixCommands.map((cmd) => (
                      <SelectItem key={cmd.name} value={cmd.name}>
                        {cmd.name} - {cmd.description}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center p-3 border rounded border-gray-800 bg-gray-950/50">
                <Info className="h-4 w-4 mr-2 text-primary" />
                <p className="text-xs text-gray-400">
                  Prefix commands use the <code className="bg-gray-900 p-1 rounded">;</code> prefix. Example: <code className="bg-gray-900 p-1 rounded">;help</code>
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="slash" className="space-y-4">
              <div className="flex items-center p-3 border rounded border-gray-800 bg-gray-950/50">
                <Info className="h-4 w-4 mr-2 text-primary" />
                <p className="text-xs text-gray-400">
                  Slash commands use the <code className="bg-gray-900 p-1 rounded">/</code> prefix. Example: <code className="bg-gray-900 p-1 rounded">/help</code>
                </p>
              </div>
            </TabsContent>
          </Tabs>
          
          {/* Command Input */}
          <div>
            <p className="text-sm text-gray-400 mb-2">
              Enter {commandType === 'prefix' ? 'prefix' : 'slash'} command to test:
            </p>
            <Input
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder={commandType === 'prefix' ? ";test or ;ping" : "/help or /serverinfo"}
              className="bg-gray-950 border-gray-800"
            />
          </div>
          
          {/* Server ID */}
          <div>
            <p className="text-sm text-gray-400 mb-2">Server ID (optional):</p>
            <Input
              value={serverId}
              onChange={(e) => setServerId(e.target.value)}
              placeholder="Server ID for context"
              className="bg-gray-950 border-gray-800"
            />
          </div>

          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error}
              </AlertDescription>
            </Alert>
          )}

          {/* Command Result */}
          {result && (
            <div>
              <p className="text-sm text-gray-400 mb-2">Response:</p>
              <div className="rounded-md bg-gray-950 p-4 text-sm font-mono overflow-x-auto">
                <pre className="whitespace-pre-wrap">{result}</pre>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleTestCommand} 
          disabled={loading}
          className="w-full"
          variant="default"
        >
          {loading ? 'Testing...' : `Test ${commandType === 'prefix' ? 'Prefix' : 'Slash'} Command`}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BotCommandDebugger;