import React from 'react';
import { Menu, Bell, HelpCircle, Search, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useLocation } from 'wouter';
import UserProfileDisplay from './UserProfileDisplay';

interface HeaderProps {
  title: string;
  openSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ title, openSidebar }) => {
  const [, setLocation] = useLocation();
  
  return (
    <header className="bg-black/95 border-b border-gray-800 z-10 backdrop-blur-sm">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <button 
              className="lg:hidden text-gray-400 hover:text-white focus:outline-none mr-3"
              onClick={openSidebar}
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="lg:ml-0">
              <h1 className="text-xl font-bold text-white">{title}</h1>
            </div>
          </div>
          
          <div className="hidden md:flex items-center relative max-w-md w-full mx-4">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-500" />
              </div>
              <Input 
                type="text" 
                placeholder="Search..." 
                className="w-full pl-10 py-1.5 bg-gray-800/50 border-0 text-sm text-gray-300 focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              className="hidden sm:flex items-center text-gray-300 hover:text-white"
              onClick={() => window.open('https://discord.com/oauth2/authorize?client_id=1361873604882731008', '_blank')}
            >
              <PlusCircle className="h-4 w-4 mr-1" />
              <span>Add Server</span>
            </Button>
            
            <div className="flex space-x-1">
              <button className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 transition-colors">
                <Bell className="h-5 w-5" />
              </button>
              <button className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 transition-colors">
                <HelpCircle className="h-5 w-5" />
              </button>
            </div>
            
            <div className="hidden sm:flex items-center border-l border-gray-700 pl-3 ml-2">
              <UserProfileDisplay />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
