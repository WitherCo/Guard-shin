import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Shield, ChevronDown, Crown, CircleCheck, LogOut, User } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

export const UserProfileDisplay: React.FC = () => {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      toast({
        title: 'Successfully logged out',
        description: 'You have been logged out of your account',
      });
      navigate('/login');
    } catch (error) {
      toast({
        title: 'Logout failed',
        description: 'There was an error logging out',
        variant: 'destructive',
      });
    }
  };

  // Get premium status badge
  const getPremiumBadge = () => {
    if (!user) return null;
    
    const premiumType = user.premiumType;
    
    if (premiumType === 2 || premiumType === 3) {
      return (
        <div className="flex items-center ml-2 text-amber-400" title="Premium Plus">
          <Crown className="h-4 w-4" />
        </div>
      );
    } else if (premiumType === 1) {
      return (
        <div className="flex items-center ml-2 text-blue-400" title="Premium">
          <CircleCheck className="h-4 w-4" />
        </div>
      );
    }
    
    return null;
  };

  // Generate user initials for avatar fallback
  const getInitials = () => {
    if (!user) return 'GS';
    
    // If discord username is available, use that
    if (user.discordUsername) {
      return user.discordUsername.substring(0, 2).toUpperCase();
    }
    
    // Otherwise use regular username
    return user.username.substring(0, 2).toUpperCase();
  };
  
  // Get user display name (prefer Discord username if available)
  const getDisplayName = () => {
    if (!user) return 'Guest';
    
    if (user.discordUsername) {
      return user.discordUsername;
    }
    
    return user.username;
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-9 px-2 flex items-center gap-2">
          <Avatar className="h-7 w-7">
            {user?.avatar ? (
              <AvatarImage src={user.avatar} alt={getDisplayName()} />
            ) : (
              <AvatarFallback className="bg-primary/10 text-primary">
                {getInitials()}
              </AvatarFallback>
            )}
          </Avatar>
          <div className="flex items-center">
            <span className="text-sm font-medium max-w-28 truncate">{getDisplayName()}</span>
            {getPremiumBadge()}
            <ChevronDown className="h-4 w-4 ml-1" />
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">{getDisplayName()}</p>
            {user?.email && (
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            )}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => navigate('/profile')}>
          Profile Settings
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => navigate('/dashboard')}>
          Dashboard
        </DropdownMenuItem>
        {user?.role === 'admin' || user?.role === 'owner' ? (
          <DropdownMenuItem onClick={() => navigate('/admin')}>
            Admin Panel
          </DropdownMenuItem>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleLogout} className="text-red-500">
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserProfileDisplay;