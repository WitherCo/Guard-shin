import React from 'react';
import { TrendingDown, TrendingUp } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgColor: string;
  iconColor: string;
  changePercentage?: number;
  changeLabel?: string;
  subtitle?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  iconBgColor,
  iconColor,
  changePercentage,
  changeLabel = "from last week",
  subtitle
}) => {
  const isPositiveChange = changePercentage !== undefined && changePercentage >= 0;
  
  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-lg border border-gray-800 shadow-lg p-5 overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none"></div>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-400 mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-white tracking-tight">{value.toLocaleString()}</h3>
          {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
        </div>
        <div className={`rounded-md p-3 ${iconBgColor} bg-opacity-20 flex items-center justify-center`}>
          {icon}
        </div>
      </div>
      
      {changePercentage !== undefined && (
        <div className="mt-4 pt-3 border-t border-gray-800/50">
          <div className="flex items-center text-sm">
            <span className={`${isPositiveChange ? 'text-green-500' : 'text-red-500'} flex items-center font-medium`}>
              {isPositiveChange ? (
                <TrendingUp className="h-3.5 w-3.5 mr-1 stroke-[3]" />
              ) : (
                <TrendingDown className="h-3.5 w-3.5 mr-1 stroke-[3]" />
              )}
              {isPositiveChange ? '+' : ''}{changePercentage}%
            </span>
            <span className="text-gray-500 ml-2 text-xs">{changeLabel}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default StatCard;
