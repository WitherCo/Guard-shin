import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children, title }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gradient-to-br from-black to-gray-900">
      <Sidebar isOpen={sidebarOpen} closeSidebar={() => setSidebarOpen(false)} />
      
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={title} openSidebar={toggleSidebar} />
        
        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-black/30 backdrop-blur-sm p-5 sm:p-6 lg:p-8 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
          <div className="mx-auto container max-w-7xl">
            {children}
          </div>
          
          {/* Footer with witherco.org link */}
          <div className="mt-8 pt-4 border-t border-gray-800 text-center text-xs text-gray-500">
            <a 
              href="https://witherco.org" 
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              witherco.org
            </a>
            <span className="mx-2">•</span>
            <span>© 2025 Guard-shin Bot</span>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
