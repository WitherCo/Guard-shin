import React from 'react';
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Award } from 'lucide-react';

interface FeatureToggleProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  enabled: boolean;
  onToggle: (enabled: boolean) => void;
  isPremium?: boolean;
  comingSoon?: boolean;
}

const FeatureToggle: React.FC<FeatureToggleProps> = ({
  icon,
  title,
  description,
  enabled,
  onToggle,
  isPremium = false,
  comingSoon = false
}) => {
  return (
    <div className={`group flex items-center justify-between px-4 py-4 border rounded-md mb-3 transition-all ${
      enabled 
        ? 'bg-primary/10 border-primary/20' 
        : 'bg-gray-900/30 border-gray-800 hover:bg-gray-900/50'
    }`}>
      <div className="flex items-center">
        <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
          enabled ? 'bg-primary/20 text-primary' : 'bg-gray-800 text-gray-400 group-hover:text-gray-300'
        }`}>
          {icon}
        </div>
        <div className="ml-3">
          <div className="flex items-center">
            <h3 className={`text-sm font-medium ${enabled ? 'text-white' : 'text-gray-300'}`}>{title}</h3>
            {isPremium && (
              <Badge variant="outline" className="ml-2 bg-gradient-to-r from-yellow-400 to-yellow-600 border-0 text-white py-0 px-1.5">
                <Award className="h-3 w-3 mr-1" />
                <span className="text-[10px]">PREMIUM</span>
              </Badge>
            )}
            {comingSoon && (
              <Badge className="ml-2 bg-gray-700 text-white py-0 px-1.5">
                <span className="text-[10px]">SOON</span>
              </Badge>
            )}
          </div>
          <p className="text-xs text-gray-400 mt-0.5 pr-4">{description}</p>
        </div>
      </div>
      <Switch 
        checked={enabled} 
        onCheckedChange={onToggle}
        disabled={comingSoon}
        className={`${comingSoon ? 'opacity-50 cursor-not-allowed' : ''}`}
      />
    </div>
  );
};

export default FeatureToggle;
