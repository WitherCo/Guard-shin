import React from 'react';
import { Link, useLocation } from 'wouter';
import { 
  LayoutDashboard, 
  Server, 
  LineChart, 
  ShieldCheck, 
  AlertTriangle, 
  FileText, 
  UserCheck, 
  AlertOctagon, 
  Settings, 
  Terminal, 
  Database, 
  LogOut,
  Globe,
  MessageSquareText,
  Users,
  Zap,
  BarChart,
  Bell,
  HelpCircle,
  Heart,
  Mail,
  Info
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, closeSidebar }) => {
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  
  // Check if user has premium status (simplified for now)
  const hasPremium = !!user?.premiumType;
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      setLocation('/');
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error logging out",
        variant: "destructive",
      });
    }
  };
  
  const navItems = [
    { group: 'Main', items: [
      { name: 'Dashboard', icon: <LayoutDashboard className="mr-3 h-5 w-5" />, href: '/' },
      { name: 'Servers', icon: <Server className="mr-3 h-5 w-5" />, href: '/servers' },
      { name: 'Analytics', icon: <BarChart className="mr-3 h-5 w-5" />, href: '/analytics' },
    ]},
    { group: 'Moderation', items: [
      { name: 'Auto-Moderation', icon: <ShieldCheck className="mr-3 h-5 w-5" />, href: '/auto-moderation' },
      { name: 'Raid Protection', icon: <AlertTriangle className="mr-3 h-5 w-5" />, href: '/raid-protection' },
      { name: 'Logs', icon: <FileText className="mr-3 h-5 w-5" />, href: '/logs' },
      { name: 'Verification', icon: <UserCheck className="mr-3 h-5 w-5" />, href: '/verification' },
      { name: 'Infractions', icon: <AlertOctagon className="mr-3 h-5 w-5" />, href: '/infractions' },
    ]},
    { group: 'Configuration', items: [
      { name: 'Prefix Settings', icon: <MessageSquareText className="mr-3 h-5 w-5" />, href: '/prefix-settings' },
      { name: 'Welcome Messages', icon: <Bell className="mr-3 h-5 w-5" />, href: '/welcome-messages' },
      { name: 'Contact Us', icon: <Mail className="mr-3 h-5 w-5" />, href: '/webhook' },
      { name: 'Advanced Settings', icon: <Settings className="mr-3 h-5 w-5" />, href: '/advanced-settings' },
    ]},
    { group: 'Resources', items: [
      { name: 'Prefix Commands', icon: <Terminal className="mr-3 h-5 w-5" />, href: '/commands' },
      { name: 'Slash Commands', icon: <Terminal className="mr-3 h-5 w-5" />, href: '/slash-commands' },
      { name: 'Documentation', icon: <HelpCircle className="mr-3 h-5 w-5" />, href: '/documentation' },
      { name: 'About', icon: <Info className="mr-3 h-5 w-5" />, href: '/about' },
      { name: 'Contact Support', icon: <MessageSquareText className="mr-3 h-5 w-5" />, href: '/contact' },
      { name: 'Support Server', icon: <Heart className="mr-3 h-5 w-5" />, href: '/support' },
    ]}
  ];

  return (
    <div 
      className={`flex flex-col w-64 bg-black/90 transition-all duration-300 overflow-hidden fixed inset-y-0 left-0 z-30 lg:static lg:z-auto border-r border-gray-800 ${
        isOpen ? '' : 'transform -translate-x-full lg:transform-none'
      }`}
    >
      <div className="h-16 flex items-center px-4 border-b border-gray-800">
        <div className="flex items-center">
          <div className="h-9 w-9 rounded-md bg-primary flex items-center justify-center text-white font-bold shadow-glow">G</div>
          <span className="ml-3 font-bold text-lg text-white">Guard-shin</span>
        </div>
        <button 
          className="ml-auto lg:hidden text-gray-400 hover:text-white"
          onClick={closeSidebar}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
      </div>
      
      <nav className="flex-1 overflow-y-auto scrollbar-hide py-5 px-3">
        {navItems.map((group, groupIndex) => (
          <div key={groupIndex} className="mb-6">
            <div className="px-2 mb-3">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{group.group}</h3>
            </div>
            <ul className="space-y-1">
              {group.items.map((item, itemIndex) => {
                const isActive = location === item.href;
                return (
                  <li key={itemIndex}>
                    <Link href={item.href}>
                      <div className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-md cursor-pointer transition-all ${
                        isActive 
                          ? 'bg-primary/10 border-l-2 border-primary text-primary pl-[10px]' 
                          : 'text-gray-400 hover:bg-gray-800/40 hover:text-white'
                      }`}>
                        {item.icon}
                        <span>{item.name}</span>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      
      <div className="border-t border-gray-800 p-4">
        <div className="flex items-center">
          <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary to-primary-foreground/70 flex items-center justify-center text-white font-medium">
            {user?.username?.charAt(0) || 'G'}
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">{user?.username || 'Guard-shin User'}</p>
            <p className="text-xs text-gray-500">
              {hasPremium ? 'Premium Member' : 'Free User'}
            </p>
          </div>
          <button 
            onClick={handleLogout}
            className="ml-auto text-gray-400 hover:text-white transition-colors"
            aria-label="Sign out"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
