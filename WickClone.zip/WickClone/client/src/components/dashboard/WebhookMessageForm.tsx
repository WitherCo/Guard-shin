import React from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, MessageSquare, Send, Mail } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { SecurityLoader } from '@/components/ui/security-loader';

// Define the form schema
const webhookFormSchema = z.object({
  webhookUrl: z.string().url({ message: 'Please enter a valid Discord webhook URL' }),
  username: z.string().min(1, { message: 'Username is required' }).max(80),
  message: z.string().min(1, { message: 'Message is required' }).max(2000),
  avatarUrl: z.string().url({ message: 'Please enter a valid avatar URL' }).optional().or(z.literal('')),
  embedEnabled: z.boolean().default(false),
  embedTitle: z.string().max(256).optional(),
  embedDescription: z.string().max(4096).optional(),
  embedColor: z.string().regex(/^#([0-9A-F]{6})$/i, { 
    message: 'Please enter a valid hex color code (e.g., #FF5733)' 
  }).optional().or(z.literal('')),
});

// Define the form values type
type WebhookFormValues = z.infer<typeof webhookFormSchema>;

interface WebhookMessageFormProps {
  defaultWebhookUrl?: string;
}

export function WebhookMessageForm({ defaultWebhookUrl = '' }: WebhookMessageFormProps) {
  const { toast } = useToast();
  
  // Default values for the form with the webhook URL hidden from users
  const defaultValues: Partial<WebhookFormValues> = {
    webhookUrl: defaultWebhookUrl,
    username: 'Discord User',
    message: '',
    avatarUrl: '',
    embedEnabled: true,
    embedTitle: 'Support Request',
    embedDescription: '',
    embedColor: '#5865F2',
  };
  
  // Initialize the form
  const form = useForm<WebhookFormValues>({
    resolver: zodResolver(webhookFormSchema),
    defaultValues,
  });
  
  // Watch the embedEnabled field to conditionally render embed fields
  const embedEnabled = form.watch('embedEnabled');
  
  // Mutation for sending the webhook message
  const mutation = useMutation({
    mutationFn: async (values: WebhookFormValues) => {
      const response = await fetch('/api/webhook/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to send webhook message');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Message sent successfully',
        description: 'Your message has been sent via Discord webhook',
        variant: 'default',
      });
      
      // Reset the message field but keep the other settings
      form.setValue('message', '');
      if (embedEnabled) {
        form.setValue('embedTitle', '');
        form.setValue('embedDescription', '');
      }
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to send message',
        description: error.message || 'An error occurred while sending your webhook message',
        variant: 'destructive',
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (values: WebhookFormValues) => {
    mutation.mutate(values);
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl flex items-center">
          <Mail className="mr-2 h-5 w-5" />
          Contact Support Team
        </CardTitle>
        <CardDescription>
          Send a message directly to our Discord support server
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Hidden webhook URL field */}
            <input type="hidden" name="webhookUrl" value={defaultWebhookUrl} />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your name" {...field} />
                    </FormControl>
                    <FormDescription>
                      How you would like to be addressed
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="avatarUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="your-email@example.com" 
                        type="email"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      So we can reply to your inquiry
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter your message here..." 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Your message content (max 2000 characters)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Hidden embed fields, automatically enabled */}
            <input type="hidden" name="embedEnabled" value="true" />
            <input type="hidden" name="embedTitle" value="Support Request" />
            <input type="hidden" name="embedColor" value="#5865F2" />
            
            <FormField
              control={form.control}
              name="embedDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Details (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional information that might help us assist you..." 
                      className="min-h-[80px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Include any extra details like your Discord username, server name, etc.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={mutation.isPending}
            >
              {mutation.isPending ? (
                <>
                  <SecurityLoader type="scanning" size="icon" className="mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Send Message
                </>
              )}
            </Button>
          </form>
        </Form>
        
        {mutation.isError && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Failed to send message</AlertTitle>
            <AlertDescription>
              {mutation.error instanceof Error ? mutation.error.message : 'An error occurred while sending your webhook message'}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter className="flex justify-between text-xs text-muted-foreground">
        <p>Messages are sent directly to Discord</p>
        <p>Guard-shin Dashboard</p>
      </CardFooter>
    </Card>
  );
}