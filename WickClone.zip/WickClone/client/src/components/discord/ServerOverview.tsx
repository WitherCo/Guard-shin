import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { DataLoader } from '../data-loader';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { 
  Shield,
  Users,
  Bot,
  MessageCircle,
  Clock,
  Activity,
  ChevronUp,
  ChevronDown,
  Award
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { hasServerPremium } from '../../shared/premium';

interface ServerOverviewProps {
  serverId: string;
}

interface ServerStats {
  memberCount: number;
  botCount: number;
  online: number;
  messageCount24h: number;
  commandsUsed24h: number;
  moderationActions24h: number;
  joinedAt: string;
  premiumUntil: string | null;
  premium: boolean;
}

interface ServerDetails {
  id: string;
  name: string;
  icon: string | null;
  owner: {
    id: string;
    username: string;
    avatar: string | null;
  };
  region: string;
  features: string[];
  verificationLevel: number;
}

export default function ServerOverview({ serverId }: ServerOverviewProps) {
  // Fetch server stats
  const { 
    data: stats, 
    isLoading: statsLoading, 
    isError: statsError,
    error: statsErrorData,
    refetch: refetchStats 
  } = useQuery<ServerStats>({
    queryKey: [`/api/discord/guilds/${serverId}/stats`],
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: !!serverId,
  });

  // Fetch server details
  const { 
    data: details, 
    isLoading: detailsLoading, 
    isError: detailsError,
    error: detailsErrorData,
    refetch: refetchDetails 
  } = useQuery<ServerDetails>({
    queryKey: [`/api/discord/guilds/${serverId}`],
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: !!serverId,
  });

  // Get Discord server icon URL
  const getServerIcon = (details?: ServerDetails) => {
    if (details?.icon) {
      return `https://cdn.discordapp.com/icons/${details.id}/${details.icon}.png`;
    }
    return null;
  };

  // Generate server initials for avatar fallback
  const getServerInitials = (name?: string) => {
    if (!name) return "DS";
    
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  // Calculate online percentage
  const getOnlinePercentage = (stats?: ServerStats) => {
    if (!stats || !stats.memberCount || !stats.online) return 0;
    return Math.round((stats.online / stats.memberCount) * 100);
  };

  // Get verification level text
  const getVerificationLevelText = (level?: number) => {
    switch (level) {
      case 0: return "None";
      case 1: return "Low";
      case 2: return "Medium";
      case 3: return "High";
      case 4: return "Very High";
      default: return "Unknown";
    }
  };

  // Format date in a friendly way
  const formatDate = (dateString?: string) => {
    if (!dateString) return "Unknown";
    
    const date = new Date(dateString);
    return format(date, 'MMM d, yyyy');
  };

  // Format "time ago" in a friendly way
  const formatTimeAgo = (dateString?: string) => {
    if (!dateString) return "Unknown";
    
    const date = new Date(dateString);
    return formatDistanceToNow(date, { addSuffix: true });
  };

  const isLoading = statsLoading || detailsLoading;
  const isError = statsError || detailsError;
  const error = statsErrorData || detailsErrorData;
  const refetch = () => {
    refetchStats();
    refetchDetails();
  };

  return (
    <DataLoader
      isLoading={isLoading}
      isError={isError}
      error={error as Error}
      loadingText="Loading server information..."
      errorText="Failed to load server information"
      retry={refetch}
      size="default"
    >
      <div className="grid gap-6">
        {/* Server header */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 border">
                <AvatarImage src={getServerIcon(details) || ''} alt={details?.name} />
                <AvatarFallback className="bg-primary/10 text-primary text-xl">
                  {getServerInitials(details?.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-2xl">{details?.name || "Discord Server"}</CardTitle>
                <CardDescription className="flex items-center gap-2 mt-1">
                  <Users className="h-4 w-4" />
                  {stats?.memberCount || 0} members
                  
                  {stats?.premium && (
                    <>
                      <span className="mx-1">•</span>
                      <Badge variant="default" className="flex items-center gap-1">
                        <Shield className="h-3 w-3" />
                        Premium
                      </Badge>
                    </>
                  )}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Stats grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {/* Members */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Members
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.memberCount || 0}</div>
              <div className="text-xs text-muted-foreground mt-1 mb-3">
                {stats?.online || 0} online • {stats?.botCount || 0} bots
              </div>
              <Progress value={getOnlinePercentage(stats)} className="h-1" />
              <div className="text-xs text-muted-foreground mt-1 flex justify-between">
                <span>{getOnlinePercentage(stats)}% online</span>
                <span className="flex items-center gap-1">
                  <Bot className="h-3 w-3" />
                  {stats?.botCount || 0} bots
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Activity */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activity (24h)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                <div className="text-center">
                  <div className="text-xl font-bold">{stats?.messageCount24h || 0}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    <MessageCircle className="h-3 w-3 inline mr-1" />
                    Messages
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{stats?.commandsUsed24h || 0}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    <span className="text-xs">/</span> Commands
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{stats?.moderationActions24h || 0}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    <Shield className="h-3 w-3 inline mr-1" />
                    Mod Actions
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time info */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Time Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>
                  <div className="text-xs text-muted-foreground">Bot Added</div>
                  <div>{formatDate(stats?.joinedAt)}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatTimeAgo(stats?.joinedAt)}
                  </div>
                </div>
                
                {stats?.premium && stats?.premiumUntil && (
                  <div className="mt-2 pt-2 border-t border-border">
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Award className="h-3 w-3" />
                      Premium Until
                    </div>
                    <div>{formatDate(stats.premiumUntil)}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatTimeAgo(stats.premiumUntil)}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DataLoader>
  );
}