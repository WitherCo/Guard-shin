import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { DataLoader } from '../data-loader';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { SecurityLoader } from '@/components/ui/security-loader';
import { hasServerPremium } from '../../shared/premium';
import { Shield, ShieldAlert, Users, Plus, ArrowRight } from 'lucide-react';

// Discord bot invite URL
const BOT_INVITE_URL = "https://discord.com/oauth2/authorize?client_id=1361873604882731008&permissions=8&scope=bot%20applications.commands";

// Type definitions for Discord server
interface DiscordServer {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number | null;
  ownerId: string;
  joinedAt: Date | null;
  premium: boolean | null;
  premiumTier: string | null;
  premiumExpiresAt: Date | null;
  lastTransactionId: string | null;
}

export default function DiscordServerList() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Fetch Discord servers
  const { data: servers, isLoading, isError, error, refetch } = useQuery<DiscordServer[]>({
    queryKey: ['/api/servers'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Handle server selection
  const handleServerSelect = (serverId: string) => {
    setLocation(`/dashboard/${serverId}`);
  };

  // Get Discord server icon URL
  const getServerIcon = (server: DiscordServer) => {
    if (server.icon) {
      return `https://cdn.discordapp.com/icons/${server.id}/${server.icon}.png`;
    }
    return null;
  };

  // Generate server initials for avatar fallback
  const getServerInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  return (
    <DataLoader
      isLoading={isLoading}
      isError={isError}
      error={error as Error}
      loadingText="Fetching your Discord servers..."
      errorText="Failed to load Discord servers"
      retry={refetch}
      size="lg"
    >
      <div className="grid gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Your Discord Servers</h2>
            <p className="text-muted-foreground">Select a server to manage settings</p>
          </div>
          <Button onClick={() => window.open(BOT_INVITE_URL, '_blank')} className="flex items-center gap-2">
            <Plus size={16} />
            <span>Add to Server</span>
          </Button>
        </div>
        
        <Separator />
        
        {servers && servers.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {servers.map((server) => (
              <Card key={server.id} className="overflow-hidden hover:shadow-md transition-all card-hover-effect">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 border">
                      <AvatarImage src={getServerIcon(server) || ''} alt={server.name} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getServerInitials(server.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 overflow-hidden">
                      <CardTitle className="text-lg truncate">{server.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant={server.premium ? "default" : "outline"} className="flex items-center gap-1">
                          {server.premium ? <Shield size={12} /> : <ShieldAlert size={12} />}
                          {server.premium ? "Premium" : "Free"}
                        </Badge>
                        {server.memberCount && (
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Users size={12} />
                            {server.memberCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 pb-2">
                  <p className="text-sm text-muted-foreground">
                    {hasServerPremium(server as any) 
                      ? "Premium features enabled" 
                      : "Upgrade to unlock premium features"
                    }
                  </p>
                </CardContent>
                <CardFooter className="flex justify-end pt-2">
                  <Button 
                    size="sm" 
                    onClick={() => handleServerSelect(server.id)}
                    className="flex items-center gap-1"
                  >
                    Manage <ArrowRight size={14} />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="bg-card border rounded-lg p-8 text-center">
            <div className="max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-2">No servers found</h3>
              <p className="text-muted-foreground mb-6">
                You don't have any Discord servers with Guard-shin bot yet. Add the bot to your server to get started.
              </p>
              <Button onClick={() => window.open(BOT_INVITE_URL, '_blank')} className="flex items-center gap-2 mx-auto">
                <Plus size={16} />
                <span>Add Guard-shin to a Server</span>
              </Button>
            </div>
          </div>
        )}
      </div>
    </DataLoader>
  );
}