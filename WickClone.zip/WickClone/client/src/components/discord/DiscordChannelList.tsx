import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { DataLoader } from '../data-loader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Hash, 
  Volume2, 
  Users, 
  MessageCircle, 
  Lock, 
  EyeOff, 
  Settings 
} from 'lucide-react';

interface DiscordChannel {
  id: string;
  name: string;
  type: number;
  parentId: string | null;
  position: number;
  permissionOverwrites: any[];
  nsfw: boolean;
}

interface ChannelCategory {
  id: string;
  name: string;
  type: number;
  position: number;
  channels: DiscordChannel[];
}

interface DiscordChannelListProps {
  serverId: string;
  onChannelSelect?: (channelId: string) => void;
}

export default function DiscordChannelList({ serverId, onChannelSelect }: DiscordChannelListProps) {
  // Fetch Discord channels for the server
  const { data: channels, isLoading, isError, error, refetch } = useQuery<DiscordChannel[]>({
    queryKey: [`/api/discord/guilds/${serverId}/channels`],
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: !!serverId,
  });

  // Function to get channel icon based on type
  const getChannelIcon = (type: number) => {
    switch (type) {
      case 0: // Text channel
        return <Hash className="h-4 w-4" />;
      case 2: // Voice channel
        return <Volume2 className="h-4 w-4" />;
      case 4: // Category
        return <Users className="h-4 w-4" />;
      case 5: // Announcement
        return <MessageCircle className="h-4 w-4" />;
      default:
        return <Hash className="h-4 w-4" />;
    }
  };

  // Function to check if channel has restricted permissions
  const isRestrictedChannel = (channel: DiscordChannel) => {
    // Simple check - if there are any permission overwrites, we consider it restricted
    return channel.permissionOverwrites && channel.permissionOverwrites.length > 0;
  };

  // Group channels by category
  const getChannelsByCategory = () => {
    if (!channels) return [];
    
    const categories: ChannelCategory[] = [];
    const uncategorizedChannels: DiscordChannel[] = [];
    
    // Find all categories
    channels.forEach(channel => {
      if (channel.type === 4) { // Category type
        categories.push({
          id: channel.id,
          name: channel.name,
          type: channel.type,
          position: channel.position,
          channels: []
        });
      }
    });
    
    // Sort categories by position
    categories.sort((a, b) => a.position - b.position);
    
    // Assign channels to categories
    channels.forEach(channel => {
      if (channel.type !== 4) { // Not a category
        if (channel.parentId) {
          const category = categories.find(c => c.id === channel.parentId);
          if (category) {
            category.channels.push(channel);
          } else {
            uncategorizedChannels.push(channel);
          }
        } else {
          uncategorizedChannels.push(channel);
        }
      }
    });
    
    // Sort channels within categories by position
    categories.forEach(category => {
      category.channels.sort((a, b) => a.position - b.position);
    });
    
    // Create a special "uncategorized" category if there are uncategorized channels
    if (uncategorizedChannels.length > 0) {
      uncategorizedChannels.sort((a, b) => a.position - b.position);
      categories.push({
        id: 'uncategorized',
        name: 'Uncategorized',
        type: 4,
        position: 9999,
        channels: uncategorizedChannels
      });
    }
    
    return categories;
  };

  // Handle channel selection
  const handleChannelClick = (channelId: string) => {
    if (onChannelSelect) {
      onChannelSelect(channelId);
    }
  };

  return (
    <DataLoader
      isLoading={isLoading}
      isError={isError}
      error={error as Error}
      loadingText="Loading Discord channels..."
      errorText="Failed to load Discord channels"
      retry={refetch}
      size="default"
    >
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-xl flex items-center gap-2">
            <Hash className="h-5 w-5" />
            Discord Channels
          </CardTitle>
        </CardHeader>
        <CardContent>
          {channels && channels.length > 0 ? (
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-6">
                {getChannelsByCategory().map((category) => (
                  <div key={category.id} className="space-y-2">
                    <div className="font-medium text-sm uppercase tracking-wider text-muted-foreground flex items-center">
                      {category.name}
                    </div>
                    <Separator className="my-2" />
                    <div className="space-y-1 pl-2">
                      {category.channels.map((channel) => (
                        <Button
                          key={channel.id}
                          variant="ghost"
                          className="w-full justify-start px-2 py-1 h-auto text-left"
                          onClick={() => handleChannelClick(channel.id)}
                        >
                          <div className="flex items-center gap-2 w-full">
                            <span className="text-muted-foreground">
                              {getChannelIcon(channel.type)}
                            </span>
                            <span className="flex-1 truncate">{channel.name}</span>
                            {channel.nsfw && (
                              <Badge variant="outline" className="text-xs">NSFW</Badge>
                            )}
                            {isRestrictedChannel(channel) && (
                              <Lock className="h-3 w-3 text-muted-foreground" />
                            )}
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-center py-8">
              <EyeOff className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium mb-2">No visible channels</h3>
              <p className="text-muted-foreground text-sm mb-4">
                There are no channels visible or the bot doesn't have access to view channels.
              </p>
              <Button variant="outline" size="sm" className="flex items-center gap-2 mx-auto">
                <Settings size={14} />
                Check Permissions
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </DataLoader>
  );
}