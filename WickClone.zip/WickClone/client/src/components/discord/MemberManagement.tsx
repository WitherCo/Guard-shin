import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DataLoader } from '../data-loader';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import {
  Users,
  Search,
  MoreHorizontal,
  Shield,
  Ban,
  UserMinus,
  UserX,
  MessageSquare,
  Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface DiscordMember {
  id: string;
  username: string;
  discriminator: string;
  avatar: string | null;
  nick: string | null;
  roles: string[];
  joinedAt: string;
  premiumSince: string | null;
  pending: boolean;
  communication_disabled_until: string | null;
  isAdmin: boolean;
  isModerator: boolean;
}

interface MemberManagementProps {
  serverId: string;
}

export default function MemberManagement({ serverId }: MemberManagementProps) {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch server members
  const { 
    data: members, 
    isLoading, 
    isError, 
    error, 
    refetch 
  } = useQuery<DiscordMember[]>({
    queryKey: [`/api/discord/guilds/${serverId}/members`],
    staleTime: 1000 * 60 * 2, // 2 minutes
    enabled: !!serverId,
  });

  // Filter members based on search query
  const filteredMembers = React.useMemo(() => {
    if (!members) return [];
    if (!searchQuery) return members;
    
    const lowerQuery = searchQuery.toLowerCase();
    return members.filter(member => 
      member.username.toLowerCase().includes(lowerQuery) || 
      (member.nick && member.nick.toLowerCase().includes(lowerQuery))
    );
  }, [members, searchQuery]);

  // Get member avatar
  const getMemberAvatar = (member: DiscordMember) => {
    if (member.avatar) {
      return `https://cdn.discordapp.com/avatars/${member.id}/${member.avatar}.png`;
    }
    return null;
  };

  // Get member initials for avatar fallback
  const getMemberInitials = (member: DiscordMember) => {
    return (member.nick || member.username).substring(0, 2).toUpperCase();
  };

  // Format time ago
  const formatTimeAgo = (dateString?: string | null) => {
    if (!dateString) return null;
    
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return null;
    }
  };

  // Handle member actions
  const handleMemberAction = (action: string, memberId: string, username: string) => {
    // Show toast notification for demo purposes
    toast({
      title: `${action} - ${username}`,
      description: `This would ${action.toLowerCase()} the user in a real implementation.`,
    });

    // In a real implementation, we would call the API to perform the action
    console.log(`Action: ${action}, Member ID: ${memberId}`);
  };

  return (
    <DataLoader
      isLoading={isLoading}
      isError={isError}
      error={error as Error}
      loadingText="Loading server members..."
      errorText="Failed to load server members"
      retry={refetch}
      size="lg"
    >
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Server Members
          </CardTitle>
          <CardDescription>
            {members?.length || 0} members in this server
          </CardDescription>
          <div className="relative mt-2">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search members..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[400px]">
            <div className="divide-y divide-border">
              {filteredMembers.length > 0 ? (
                filteredMembers.map((member) => (
                  <div key={member.id} className="flex items-center gap-3 p-4 hover:bg-muted/50">
                    <Avatar className="h-10 w-10 border">
                      <AvatarImage src={getMemberAvatar(member) || ''} alt={member.username} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getMemberInitials(member)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">
                          {member.nick || member.username}
                        </span>
                        
                        {/* Role badges */}
                        {member.isAdmin && (
                          <Badge variant="destructive" className="text-xs">Admin</Badge>
                        )}
                        {member.isModerator && !member.isAdmin && (
                          <Badge variant="default" className="text-xs">Mod</Badge>
                        )}
                        
                        {/* Status indicators */}
                        {member.communication_disabled_until && (
                          <Badge variant="outline" className="text-xs flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Timed out
                          </Badge>
                        )}
                      </div>
                      
                      <div className="text-xs text-muted-foreground truncate">
                        {member.username}
                        {member.discriminator !== '0' ? `#${member.discriminator}` : ''}
                        {member.joinedAt && (
                          <span className="ml-2">• Joined {formatTimeAgo(member.joinedAt)}</span>
                        )}
                      </div>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleMemberAction('Message', member.id, member.username)}
                          className="flex items-center gap-2"
                        >
                          <MessageSquare className="h-4 w-4" />
                          Send Message
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleMemberAction('Timeout', member.id, member.username)}
                          className="flex items-center gap-2"
                        >
                          <Clock className="h-4 w-4" />
                          Timeout
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleMemberAction('Kick', member.id, member.username)}
                          className="flex items-center gap-2 text-amber-500"
                        >
                          <UserMinus className="h-4 w-4" />
                          Kick
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleMemberAction('Ban', member.id, member.username)}
                          className="flex items-center gap-2 text-destructive"
                        >
                          <Ban className="h-4 w-4" />
                          Ban
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center">
                  <UserX className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No members found</h3>
                  <p className="text-muted-foreground text-sm">
                    {members?.length 
                      ? 'No members match your search criteria.' 
                      : 'No members available or the bot doesn\'t have permission to view members.'}
                  </p>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
        <CardFooter className="flex justify-between border-t p-4">
          <div className="text-sm text-muted-foreground">
            Showing {filteredMembers.length} of {members?.length || 0} members
          </div>
          {filteredMembers.length !== members?.length && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setSearchQuery('')}
            >
              Clear search
            </Button>
          )}
        </CardFooter>
      </Card>
    </DataLoader>
  );
}