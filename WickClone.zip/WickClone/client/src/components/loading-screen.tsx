import React, { useEffect, useState } from 'react';
import { Shield, ShieldCheck, ShieldAlert, ShieldOff } from 'lucide-react';
import { LoadingPage } from './loading-page';

interface LoadingScreenProps {
  onComplete?: () => void;
  duration?: number;
  text?: string;
  showProgress?: boolean;
}

export function LoadingScreen({ 
  onComplete, 
  duration = 2500,
  text = "Initializing security protocols...",
  showProgress = true
}: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState<'scan' | 'alert' | 'secure' | 'complete'>('scan');
  
  // Setup the loading animation stages
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    const updateProgress = () => {
      setProgress(prev => {
        const newProgress = prev + 0.5;
        
        // Update the loading stage based on progress
        if (newProgress >= 25 && newProgress < 30) {
          setStage('alert');
        } else if (newProgress >= 45 && stage === 'alert') {
          setStage('scan');
        } else if (newProgress >= 75) {
          setStage('secure');
        } else if (newProgress >= 98) {
          if (onComplete) setTimeout(onComplete, 500);
          setStage('complete');
          return 100;
        }
        
        return Math.min(newProgress, 100);
      });
    };
    
    // Start the progress update interval
    timer = setInterval(updateProgress, duration / 200);
    
    return () => clearInterval(timer);
  }, [duration, onComplete, stage]);
  
  // Render different shield icons based on the current stage
  const renderShield = () => {
    switch(stage) {
      case 'scan':
        return <Shield className="w-16 h-16 text-blue-400 animate-pulse" />;
      case 'alert':
        return <ShieldAlert className="w-16 h-16 text-amber-400 animate-bounce" />;
      case 'secure':
        return <ShieldCheck className="w-16 h-16 text-green-400 animate-shield-pulse" />;
      case 'complete':
        return <ShieldCheck className="w-16 h-16 text-green-500" />;
      default:
        return <ShieldOff className="w-16 h-16 text-gray-400" />;
    }
  };
  
  // Get loading text based on the current stage
  const getLoadingText = () => {
    switch(stage) {
      case 'scan': return "Scanning for threats...";
      case 'alert': return "Threat detected! Analyzing...";
      case 'secure': return "Securing your environment...";
      case 'complete': return "Security protocols activated!";
      default: return text;
    }
  };
  
  // Get progress bar color based on the current stage
  const getProgressColor = () => {
    switch(stage) {
      case 'scan': return "bg-blue-500";
      case 'alert': return "bg-amber-500";
      case 'secure': return "bg-green-500";
      case 'complete': return "bg-green-600";
      default: return "bg-primary";
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 flex flex-col items-center justify-center z-50">
      <div className="text-center max-w-md p-8">
        <div className="mb-6 flex justify-center">
          {renderShield()}
        </div>
        
        <h2 className="text-xl font-semibold mb-2">Guard-shin Bot</h2>
        <p className="text-muted-foreground mb-6">{getLoadingText()}</p>
        
        {showProgress && (
          <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
            <div 
              className={`h-full ${getProgressColor()} transition-all ease-out duration-300`} 
              style={{ width: `${progress}%` }} 
            />
          </div>
        )}

        <div className="mt-4 text-sm text-muted-foreground/60">
          Security protocol {Math.floor(progress)}% complete
        </div>
      </div>
    </div>
  );
}