import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, XCircle, Clock, CreditCard, Gift, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PremiumPlan {
  id: string;
  name: string;
  price: string;
  monthlyPrice?: string;
  yearlyPrice?: string;
  isLifetime: boolean;
  features: string[];
  recommended?: boolean;
}

// Premium plans data
const premiumPlans: PremiumPlan[] = [
  {
    id: 'premium',
    name: 'Premium',
    price: '$9.99/month',
    monthlyPrice: '$9.99',
    yearlyPrice: '$49.99',
    isLifetime: false,
    features: [
      'Custom welcome images',
      'Auto-response system',
      'Raffle system',
      'Server statistics',
      'Advanced verification',
      'Priority support (24h)'
    ]
  },
  {
    id: 'premium-plus',
    name: 'Premium+',
    price: '$19.99/month',
    monthlyPrice: '$19.99',
    yearlyPrice: '$99.99',
    isLifetime: false,
    recommended: true,
    features: [
      'All Premium features',
      'Advanced anti-raid protection',
      'Advanced verification system',
      'Custom role management',
      'Detailed analytics dashboard',
      'Priority support (12h)',
      'Custom auto-mod rules',
      'Advanced logging system'
    ]
  }
];

// Lifetime premium plans
const lifetimePlans: PremiumPlan[] = [
  {
    id: 'lifetime-premium',
    name: 'Lifetime Premium',
    price: '$149.99',
    isLifetime: true,
    features: [
      'All Premium features',
      'Never expires',
      'One-time payment',
      'Free future updates',
      'Transferable license (once per year)'
    ]
  },
  {
    id: 'lifetime-premium-plus',
    name: 'Lifetime Premium+',
    price: '$249.99',
    isLifetime: true,
    recommended: true,
    features: [
      'All Premium+ features',
      'Never expires',
      'One-time payment',
      'Free future updates',
      'Early access to new features',
      'Premium discord role',
      'Transferable license (once per year)',
      'Custom bot command prefix'
    ]
  }
];

export default function PremiumPlans() {
  const { toast } = useToast();
  
  // Check user's premium status
  const { data: premiumStatus, isLoading } = useQuery({
    queryKey: ['/api/discord/user/roles'],
    retry: false,
    refetchOnWindowFocus: false
  });
  
  const isPremium = premiumStatus?.premium || false;
  const currentTier = premiumStatus?.premiumTier || 'free';
  
  const handlePurchase = (plan: PremiumPlan) => {
    // Display instructions modal
    toast({
      title: `${plan.name} Purchase`,
      description: "To purchase, please join our support server and send payment via PayPal or CashApp with your Discord server ID in the notes.",
      duration: 5000,
    });
    
    // Open support server in new tab
    window.open('https://discord.gg/g3rFbaW6gw', '_blank');
  };
  
  return (
    <div className="container mx-auto py-8 space-y-8">
      <div className="text-center space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Guard-shin Premium</h1>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Unlock powerful security and moderation features with Guard-shin Premium.
        </p>
        
        {isPremium && (
          <div className="mt-4 inline-flex items-center gap-2 bg-green-500/10 text-green-500 px-4 py-2 rounded-full">
            <CheckCircle size={18} />
            <span>You currently have {currentTier} subscription</span>
          </div>
        )}
      </div>
      
      <Tabs defaultValue="subscription" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
          <TabsTrigger value="subscription">Monthly Plans</TabsTrigger>
          <TabsTrigger value="lifetime">Lifetime Plans</TabsTrigger>
        </TabsList>
        
        {/* Monthly Subscription Plans */}
        <TabsContent value="subscription" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:gap-8">
            {premiumPlans.map((plan) => (
              <Card 
                key={plan.id} 
                className={`flex flex-col ${plan.recommended ? 'border-primary shadow-lg' : ''}`}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>Monthly or 6-month subscription</CardDescription>
                    </div>
                    {plan.recommended && (
                      <Badge variant="default" className="ml-2">
                        Recommended
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="mt-2 mb-4">
                    <span className="text-3xl font-bold">{plan.monthlyPrice}</span>
                    <span className="text-muted-foreground ml-1">/month</span>
                    <p className="text-sm text-muted-foreground mt-1">
                      or {plan.yearlyPrice} for 6 months
                    </p>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <ul className="space-y-2 my-4">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle size={18} className="text-green-500 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={() => handlePurchase(plan)} 
                    className="w-full" 
                    variant={plan.recommended ? "default" : "outline"}
                  >
                    <CreditCard className="mr-2 h-4 w-4" /> 
                    Get {plan.name}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Lifetime Plans */}
        <TabsContent value="lifetime" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:gap-8">
            {lifetimePlans.map((plan) => (
              <Card 
                key={plan.id} 
                className={`flex flex-col ${plan.recommended ? 'border-primary shadow-lg' : ''}`}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>One-time payment, lifetime access</CardDescription>
                    </div>
                    {plan.recommended && (
                      <Badge variant="default" className="ml-2">
                        Best Value
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="mt-2 mb-4">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground ml-1">one-time</span>
                    <p className="text-sm text-green-500 font-medium mt-1">
                      <Zap size={14} className="inline mr-1" />
                      Never expires
                    </p>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <ul className="space-y-2 my-4">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle size={18} className="text-green-500 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={() => handlePurchase(plan)} 
                    className="w-full" 
                    variant={plan.recommended ? "default" : "outline"}
                  >
                    <Gift className="mr-2 h-4 w-4" /> 
                    Get {plan.name}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="max-w-2xl mx-auto mt-16 text-center">
        <h2 className="text-xl font-semibold mb-4">Payment Information</h2>
        <div className="bg-card p-6 rounded-lg border">
          <p className="mb-4">We accept payments through PayPal and CashApp:</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="p-4 border rounded-lg bg-muted/50">
              <h3 className="font-medium mb-2">PayPal</h3>
              <p className="text-sm mb-2">paypal.me/ChristopherThomas429</p>
              <Button variant="outline" size="sm" onClick={() => window.open('https://paypal.me/ChristopherThomas429', '_blank')}>
                Open PayPal
              </Button>
            </div>
            
            <div className="p-4 border rounded-lg bg-muted/50">
              <h3 className="font-medium mb-2">CashApp</h3>
              <p className="text-sm mb-2">$kingsweets2004</p>
              <Button variant="outline" size="sm" onClick={() => window.open('https://cash.app/$kingsweets2004', '_blank')}>
                Open CashApp
              </Button>
            </div>
          </div>
          
          <div className="text-sm text-muted-foreground space-y-2">
            <p>After payment, please send your transaction details along with your Discord server ID in our support server.</p>
            <p>Your subscription will be activated within 24 hours after payment verification.</p>
            <p>For help with payments, contact support in our <a href="https://discord.gg/g3rFbaW6gw" target="_blank" className="text-primary hover:underline">Discord server</a>.</p>
          </div>
        </div>
      </div>
    </div>
  );
}