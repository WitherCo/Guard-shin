import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { SecurityLoader } from '@/components/ui/security-loader';
import { AlertCircle, RefreshCw, Shield } from 'lucide-react';

interface DataLoaderProps {
  isLoading: boolean;
  isError: boolean;
  error?: Error | null;
  children: React.ReactNode;
  loadingText?: string;
  errorText?: string;
  retry?: () => void;
  emptyStateComponent?: React.ReactNode;
  isEmpty?: boolean;
  size?: 'sm' | 'default' | 'lg';
}

export const DataLoader: React.FC<DataLoaderProps> = ({
  isLoading,
  isError,
  error,
  children,
  loadingText = 'Loading data...',
  errorText = 'Failed to load data',
  retry,
  emptyStateComponent,
  isEmpty = false,
  size = 'default',
}) => {
  // Map our size choices to SecurityLoader size prop
  const getLoaderSize = () => {
    // Return the size directly as it's expected to be compatible with SecurityLoader
    return size;
  };

  // Choose a random security loader type
  const getRandomLoaderType = () => {
    const types = ['scanning', 'shield', 'fingerprint', 'radar'];
    const randomIndex = Math.floor(Math.random() * types.length);
    return types[randomIndex] as any;
  };
  
  if (isLoading) {
    return (
      <div className="w-full py-10 flex flex-col items-center justify-center text-center">
        <SecurityLoader 
          type={getRandomLoaderType()} 
          text={loadingText} 
          size={getLoaderSize()} 
        />
      </div>
    );
  }

  if (isError) {
    return (
      <Card className="border-destructive/50 bg-destructive/5">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center text-center p-4">
            <div className="rounded-full bg-destructive/10 p-3 mb-4">
              <AlertCircle className="h-6 w-6 text-destructive" />
            </div>
            <AlertTitle className="mb-2">{errorText}</AlertTitle>
            <AlertDescription className="text-sm mb-4">
              {error?.message || 'An unexpected error occurred. Please try again.'}
            </AlertDescription>
            {retry && (
              <Button 
                variant="outline" 
                className="mt-2" 
                onClick={retry}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isEmpty && emptyStateComponent) {
    return <>{emptyStateComponent}</>;
  }

  return <>{children}</>;
};