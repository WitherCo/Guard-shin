import React from 'react';
import { SecurityLoader } from '@/components/ui/security-loader';

interface LoadingPageProps {
  message?: string;
  type?: 'shield' | 'scanning' | 'fingerprint' | 'radar';
}

export const LoadingPage: React.FC<LoadingPageProps> = ({ 
  message = 'Loading...', 
  type = 'scanning' 
}) => {
  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center">
      <SecurityLoader type={type} text={message} size="large" />
    </div>
  );
};